package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

import vCampus.common.enums.RepairStatus;

/**
 * 宿舍报修记录。
 */
public class DormRepair implements Serializable {

    private static final long serialVersionUID = 1L;

    private int repairId;

    private String sId;

    private String dormId;

    /**
     * 故障描述。
     */
    private String description;

    private RepairStatus status;

    private Date createTime;

    private Date updateTime;

    public DormRepair() {
    }

    public int getRepairId() {
        return repairId;
    }

    public void setRepairId(int repairId) {
        this.repairId = repairId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getDormId() {
        return dormId;
    }

    public void setDormId(String dormId) {
        this.dormId = dormId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RepairStatus getStatus() {
        return status;
    }

    public void setStatus(RepairStatus status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}