package vCampus.common.vo;

import java.io.Serializable;

/**
 * 课表展示DTO
 * 用于：学生查看个人课表、教师查看授课课表
 */
public class ScheduleDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String courseId;          // 课程号
    private String courseName;        // 课程名
    private String teacherName;       // 教师姓名
    private String classroom;         // 教室
    private String schedule;          // 上课时间（如 "周二1-2节"）
    private int dayOfWeek;            // 星期几（1=周一）
    private String startTime;         // 开始时间（如 "08:00"）
    private String endTime;           // 结束时间（如 "09:35"）
    private String weeks;             // 周次（如 "1-16周"）
    private String semester;          // 学期
    private String offeringId;        // 开课班级ID

    public ScheduleDTO() {}

    // ========== Getter / Setter ==========
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }

    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }

    public int getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(int dayOfWeek) { this.dayOfWeek = dayOfWeek; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public String getWeeks() { return weeks; }
    public void setWeeks(String weeks) { this.weeks = weeks; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getOfferingId() { return offeringId; }
    public void setOfferingId(String offeringId) { this.offeringId = offeringId; }

    // ========== 辅助方法 ==========
    
    public String getTimeRange() {
        return startTime + " - " + endTime;
    }

    @Override
    public String toString() {
        return "ScheduleDTO{" +
                "courseName='" + courseName + '\'' +
                ", teacherName='" + teacherName + '\'' +
                ", classroom='" + classroom + '\'' +
                ", schedule='" + schedule + '\'' +
                '}';
    }
}