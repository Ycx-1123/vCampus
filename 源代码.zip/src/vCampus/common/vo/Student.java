package vCampus.common.vo;

import java.io.Serializable;

public class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    
    //最基本信息
    private String sCard;         // 一卡通账号
    private String sId;           // 学号 / 用户ID
    private String sname;         // 姓名
    private String spassword;     // 登录密码
    private String sgender;       // 性别
    private String sdepartment;   // 院系/部门
    private String sphone;        // 电话号码
    private String semail;        // 电子邮箱
    private String saddress;      // 地址
    private Double sbalance;      // 一卡通余额
    private String sstatus;       // 用户状态
   
    //其他模块需要的信息
    private String clazzid;        // 所属班级编号
    private String enrollYear;     // 入学年份
    private Boolean isLocked;      // 学籍是否锁定
    private Boolean canEdit;	   // 管理员授权：允许学生修改个人信息
    private Double finishedCredit; // 已修完学分
    private Double requiredCredit; // 最低所需学分

    public Student() {
    }

    public Student(String sId, String sname, String spassword, String sgender, String sdepartment, 
                   String sphone, String semail, String saddress, Double sbalance, String sstatus, 
                   String sCard, String clazzid, String enrollYear, Boolean isLocked, 
                   Double finishedCredit, Double requiredCredit) {
        this.sId = sId;
        this.sname = sname;
        this.spassword = spassword;
        this.sgender = sgender;
        this.sdepartment = sdepartment;
        this.sphone = sphone;
        this.semail = semail;
        this.saddress = saddress;
        this.sbalance = sbalance;
        this.sstatus = sstatus;
        this.sCard = sCard;
        this.clazzid = clazzid;
        this.enrollYear = enrollYear;
        this.isLocked = isLocked;
        this.finishedCredit = finishedCredit;
        this.requiredCredit = requiredCredit;
    }

    public String getSId() {
        return sId;
    }

    public void setSId(String sId) {
        this.sId = sId;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSpassword() {
        return spassword;
    }

    public void setSpassword(String spassword) {
        this.spassword = spassword;
    }

    public String getSgender() {
        return sgender;
    }

    public void setSgender(String sgender) {
        this.sgender = sgender;
    }

    public String getSdepartment() {
        return sdepartment;
    }

    public void setSdepartment(String sdepartment) {
        this.sdepartment = sdepartment;
    }

    public String getSphone() {
        return sphone;
    }

    public void setSphone(String sphone) {
        this.sphone = sphone;
    }

    public String getSemail() {
        return semail;
    }

    public void setSemail(String semail) {
        this.semail = semail;
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress;
    }

    public Double getSbalance() {
        return sbalance;
    }

    public void setSbalance(Double sbalance) {
        this.sbalance = sbalance;
    }

    public String getSstatus() {
        return sstatus;
    }

    public void setSstatus(String sstatus) {
        this.sstatus = sstatus;
    }

    public String getSCard() {
        return sCard;
    }

    public void setSCard(String sCard) {
        this.sCard = sCard;
    }

    public String getStuCard() {
        return sCard != null ? sCard : sId;
    }

    public void setStuCard(String stuCard) {
        this.sCard = stuCard;
        this.sId = stuCard;
    }

    public String getClazzid() {
        return clazzid;
    }

    public void setClazzid(String clazzid) {
        this.clazzid = clazzid;
    }

    public String getEnrollYear() {
        return enrollYear;
    }

    public void setEnrollYear(String enrollYear) {
        this.enrollYear = enrollYear;
    }

    public Boolean isLocked() {
        return isLocked;
    }

    public void setLocked(Boolean locked) {
        isLocked = locked;
    }
    
    public boolean isCanEdit() { 
    	return canEdit; 
    }
    
    public void setCanEdit(boolean canEdit) { 
    	this.canEdit = canEdit; 
    }

    public Double getFinishedCredit() {
        return finishedCredit;
    }

    public void setFinishedCredit(Double finishedCredit) {
        this.finishedCredit = finishedCredit;
    }

    public Double getRequiredCredit() {
        return requiredCredit;
    }

    public void setRequiredCredit(Double requiredCredit) {
        this.requiredCredit = requiredCredit;
    }
}