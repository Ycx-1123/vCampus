package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDate;
/**
 * 图书借阅记录实体类，对应后续数据库中的 tbl_borrow_record 表。
 */
public class BorrowRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String STATUS_BORROWED = "BORROWED";
    public static final String STATUS_RETURNED = "RETURNED";
    public static final String STATUS_OVERDUE = "OVERDUE";

    private String recordId;
    private String copyId;
    private String bookId;
    /** 仅用于展示，由查询时从书目表带回。 */
    private String bookName;
    private String readerId;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private int renewCount;
    private int overdueDays;
    private String status;

    public BorrowRecord() {
    }

    public BorrowRecord(String recordId, String copyId, String bookId, String readerId,
            LocalDate borrowDate, LocalDate dueDate) {
        this.recordId = recordId;
        this.copyId = copyId;
        this.bookId = bookId;
        this.readerId = readerId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.status = STATUS_BORROWED;
    }

    public boolean isOverdue(LocalDate currentDate) {
        return returnDate == null && dueDate != null && currentDate.isAfter(dueDate);
    }

    public void returnBook(LocalDate actualReturnDate) {
        this.returnDate = actualReturnDate;
        if (dueDate != null && actualReturnDate != null && actualReturnDate.isAfter(dueDate)) {
            this.overdueDays = (int) (actualReturnDate.toEpochDay() - dueDate.toEpochDay());
        }
        this.status = STATUS_RETURNED;
    }

    /**
     * 归还后仍保留逾期天数，服务端据此设置读者下一个自然月的禁借期限。
     */
    public boolean wasReturnedLate() {
        return returnDate != null && overdueDays > 0;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getCopyId() {
        return copyId;
    }

    public void setCopyId(String copyId) {
        this.copyId = copyId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getReaderId() {
        return readerId;
    }

    public void setReaderId(String readerId) {
        this.readerId = readerId;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public int getRenewCount() {
        return renewCount;
    }

    public void setRenewCount(int renewCount) {
        this.renewCount = renewCount;
    }

    public int getOverdueDays() {
        return overdueDays;
    }

    public void setOverdueDays(int overdueDays) {
        this.overdueDays = overdueDays;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
