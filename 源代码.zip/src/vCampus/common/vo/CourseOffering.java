package vCampus.common.vo;

import java.io.Serializable;

public class CourseOffering implements Serializable {
    private static final long serialVersionUID = 1L;

    private String offeringId;
    private String courseId;
    private String teacherId;
    private String teacherName;
    private String semester;
    private int capacity;
    private int enrolledCount;
    private String schedule;
    private String classroom;
    private String campus;
    private String status;
    private int version;
    private String roundId;      // 新增：所属选课轮次、
    private int roomCapacity;   // ★ 新增：教室座位数（上限）

    // 无参构造
    public CourseOffering() {}

    // 全参构造（在原有基础上加 roundId）
    public CourseOffering(String offeringId, String courseId, String teacherId,
                          String teacherName, String semester, int capacity,
                          int enrolledCount, String schedule, String classroom,
                          String status, int version, String campus, String roundId,int roomCapacity) {
        this.offeringId = offeringId;
        this.courseId = courseId;
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.semester = semester;
        this.capacity = capacity;
        this.enrolledCount = enrolledCount;
        this.schedule = schedule;
        this.classroom = classroom;
        this.status = status;
        this.version = version;
        this.campus = campus;
        this.roundId = roundId;
    }

    // getter / setter
    public String getOfferingId() { return offeringId; }
    public void setOfferingId(String offeringId) { this.offeringId = offeringId; }
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }
    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public int getEnrolledCount() { return enrolledCount; }
    public void setEnrolledCount(int enrolledCount) { this.enrolledCount = enrolledCount; }
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }
    public String getCampus() { return campus; }
    public void setCampus(String campus) { this.campus = campus; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }
    public String getRoundId() { return roundId; }
    public void setRoundId(String roundId) { this.roundId = roundId; }
    public int getRoomCapacity() { return roomCapacity; }
    public void setRoomCapacity(int roomCapacity) { this.roomCapacity = roomCapacity; }
    public boolean isFull() { return enrolledCount >= capacity; }
    public int getRemainingSlots() { return capacity - enrolledCount; }
}