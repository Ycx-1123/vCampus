package vCampus.common.vo;

import java.io.Serializable;

public class Teacher implements Serializable {
    private static final long serialVersionUID = 1L;

    private String teacherCard;      // tcard - 一卡通号（主键）
    private String password;         // tpassword - 密码
    private String teacherName;      // tname - 姓名
    private String teacherNum;       // tId - 教工号
    private String gender;           // tgender - 性别
    private String department;       // tdepartment - 所属学院
    private String title;            // ttitle - 职称
    private String phone;            // tphone - 电话
    private String email;            // temail - 邮箱
    private String address;          // taddress - 地址
    private String office;           // toffice - 办公室
    private double balance;          // tbalance - 余额
    private String status;           // tstatus - 状态

    // ========== 构造方法 ==========

    public Teacher() {}

    public Teacher(String teacherCard, String password, String teacherName, String teacherNum,
                   String gender, String department, String title, String phone,
                   String email, String address, String office, double balance, String status) {
        this.teacherCard = teacherCard;
        this.password = password;
        this.teacherName = teacherName;
        this.teacherNum = teacherNum;
        this.gender = gender;
        this.department = department;
        this.title = title;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.office = office;
        this.balance = balance;
        this.status = status;
    }

    // ========== 原有的 Getter / Setter ==========

    public String getTeacherCard() { return teacherCard; }
    public void setTeacherCard(String teacherCard) { this.teacherCard = teacherCard; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    public String getTeacherNum() { return teacherNum; }
    public void setTeacherNum(String teacherNum) { this.teacherNum = teacherNum; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getOffice() { return office; }
    public void setOffice(String office) { this.office = office; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    
    public void setTeacherId(String teacherId) {
        this.teacherNum = teacherId;
    }
    public void setCardNumber(String cardNumber) {
        this.teacherCard = cardNumber;
    }

    // ========== 🆕 为兼容其他模块（LibraryPanel等）添加的方法 ==========

    /**
     * 获取一卡通号（兼容 LibraryPanel 的调用）
     */
    public String getCardNumber() {
        return this.teacherCard;
    }

    /**
     * 获取教师ID（兼容 LibraryPanel 的调用）
     * 这里返回教工号 teacherNum，因为 teacherId 和 teacherNum 是同一个概念
     */
    public String getTeacherId() {
        return this.teacherNum;
    }

    // ========== 辅助方法 ==========

    public boolean isActive() {
        return "active".equals(status) || status == null;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "teacherCard='" + teacherCard + '\'' +
                ", teacherName='" + teacherName + '\'' +
                ", department='" + department + '\'' +
                ", title='" + title + '\'' +
                '}';
    }
}