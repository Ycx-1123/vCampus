package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

public class BankAccount implements Serializable {
    private static final long serialVersionUID = 1L;
    private String bankCardId;
    private String holderCard;
    private String holderName;
    private String bankPIN;
    private double balance;
    private int status;
    private Date createTime;

    public String getBankCardId() { return bankCardId; }
    public void setBankCardId(String v) { bankCardId = v; }
    public String getHolderCard() { return holderCard; }
    public void setHolderCard(String v) { holderCard = v; }
    public String getHolderName() { return holderName; }
    public void setHolderName(String v) { holderName = v; }
    public String getBankPIN() {return bankPIN;}
    public void setBankPIN(String bankPIN) {this.bankPIN = bankPIN;}
    public double getBalance() { return balance; }
    public void setBalance(double v) { balance = v; }
    public int getStatus() { return status; }
    public void setStatus(int v) { status = v; }
    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date v) { createTime = v; }
}