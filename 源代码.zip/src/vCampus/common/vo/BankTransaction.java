package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

public class BankTransaction implements Serializable {
    private static final long serialVersionUID = 1L;
    private long transactionId;
    private String bankCardId;
    private String transactionType;
    private double amount;
    private String targetId;
    private double balanceAfter;
    private Date transactionTime;
    private String description;

    public long getTransactionId() { return transactionId; }
    public void setTransactionId(long v) { transactionId = v; }
    public String getBankCardId() { return bankCardId; }
    public void setBankCardId(String v) { bankCardId = v; }
    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String v) { transactionType = v; }
    public double getAmount() { return amount; }
    public void setAmount(double v) { amount = v; }
    public String getTargetId() { return targetId; }
    public void setTargetId(String v) { targetId = v; }
    public double getBalanceAfter() { return balanceAfter; }
    public void setBalanceAfter(double v) { balanceAfter = v; }
    public Date getTransactionTime() { return transactionTime; }
    public void setTransactionTime(Date v) { transactionTime = v; }
    public String getDescription() { return description; }
    public void setDescription(String v) { description = v; }
}
