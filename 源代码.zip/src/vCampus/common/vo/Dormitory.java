package vCampus.common.vo;

import java.io.Serializable;

/**
 * 宿舍实体类。
 * 用于保存一个宿舍房间的基本信息和床位使用情况。
 */
public class Dormitory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 宿舍唯一编号。
     */
    private String dormId;

    /**
     * 宿舍楼名称。
     */
    private String building;

    /**
     * 房间号。
     */
    private String roomNumber;

    /**
     * 宿舍性别：
     * MALE - 男寝
     * FEMALE - 女寝
     */
    private String gender;

    /**
     * 宿舍总床位数。
     */
    private int capacity;

    /**
     * 当前已入住人数。
     */
    private int occupied;

    /**
     * 每学期住宿费。
     */
    private double feePerSemester;

    public Dormitory() {
    }

    /**
     * 保留原有构造方法，避免影响项目中原有调用。
     */
    public Dormitory(String dormId,
                     String building,
                     String roomNumber,
                     int capacity,
                     int occupied,
                     double feePerSemester) {

        this.dormId = dormId;
        this.building = building;
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.occupied = occupied;
        this.feePerSemester = feePerSemester;
    }

    /**
     * 新增包含宿舍性别的构造方法。
     */
    public Dormitory(String dormId,
                     String building,
                     String roomNumber,
                     String gender,
                     int capacity,
                     int occupied,
                     double feePerSemester) {

        this.dormId = dormId;
        this.building = building;
        this.roomNumber = roomNumber;
        this.gender = gender;
        this.capacity = capacity;
        this.occupied = occupied;
        this.feePerSemester = feePerSemester;
    }

    public String getDormId() {
        return dormId;
    }

    public void setDormId(String dormId) {
        this.dormId = dormId;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getOccupied() {
        return occupied;
    }

    public void setOccupied(int occupied) {
        this.occupied = occupied;
    }

    public double getFeePerSemester() {
        return feePerSemester;
    }

    public void setFeePerSemester(double feePerSemester) {
        this.feePerSemester = feePerSemester;
    }

    /**
     * 获取当前宿舍剩余床位数。
     */
    public int getRemainingBeds() {
        return capacity - occupied;
    }
}