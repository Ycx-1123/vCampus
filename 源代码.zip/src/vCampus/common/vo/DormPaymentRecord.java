package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

import vCampus.common.enums.PaymentMethod;
import vCampus.common.enums.PaymentStatus;

/**
 * 宿舍缴费流水记录。
 */
public class DormPaymentRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private int paymentId;

    private int billId;

    private String sId;

    /**
     * 本次支付金额。
     */
    private double amount;

    /**
     * 支付方式。
     */
    private PaymentMethod paymentMethod;

    /**
     * 支付状态。
     */
    private PaymentStatus paymentStatus;

    /**
     * 支付流水号。
     */
    private String transactionNumber;

    /**
     * 支付时间。
     */
    private Date paymentTime;

    public DormPaymentRecord() {
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }
}