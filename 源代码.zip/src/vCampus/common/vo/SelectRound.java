package vCampus.common.vo;

import java.io.Serializable;

public class SelectRound implements Serializable {
    private static final long serialVersionUID = 1L;

    private String roundId;
    private String semester;
    private String roundName;
    private String startTime;
    private String endTime;
    private String status;  // open / closed / upcoming

    public SelectRound() {}

    public String getRoundId() { return roundId; }
    public void setRoundId(String roundId) { this.roundId = roundId; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getRoundName() { return roundName; }
    public void setRoundName(String roundName) { this.roundName = roundName; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}