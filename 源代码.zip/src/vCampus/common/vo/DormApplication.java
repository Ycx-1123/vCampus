package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

import vCampus.common.enums.ApplicationStatus;
import vCampus.common.enums.ApplicationType;

/**
 * 调宿、退宿等宿舍业务申请。
 */
public class DormApplication implements Serializable {

    private static final long serialVersionUID = 1L;

    private int applicationId;

    private String sId;

    /**
     * 当前住宿记录编号。
     */
    private int accommodationId;

    /**
     * 申请类型。
     */
    private ApplicationType type;

    private String currentDormId;

    private String currentBedNumber;

    private String targetDormId;

    private String targetBedNumber;

    /**
     * 申请原因。
     */
    private String reason;

    /**
     * 审核状态。
     */
    private ApplicationStatus status;

    private Date submitTime;

    private Date reviewTime;

    /**
     * 审核管理员编号。
     */
    private String reviewerId;

    /**
     * 审核意见。
     */
    private String reviewRemark;

    public DormApplication() {
    }

    public int getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(int applicationId) {
        this.applicationId = applicationId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public int getAccommodationId() {
        return accommodationId;
    }

    public void setAccommodationId(int accommodationId) {
        this.accommodationId = accommodationId;
    }

    public ApplicationType getType() {
        return type;
    }

    public void setType(ApplicationType type) {
        this.type = type;
    }

    public String getCurrentDormId() {
        return currentDormId;
    }

    public void setCurrentDormId(String currentDormId) {
        this.currentDormId = currentDormId;
    }

    public String getCurrentBedNumber() {
        return currentBedNumber;
    }

    public void setCurrentBedNumber(String currentBedNumber) {
        this.currentBedNumber = currentBedNumber;
    }

    public String getTargetDormId() {
        return targetDormId;
    }

    public void setTargetDormId(String targetDormId) {
        this.targetDormId = targetDormId;
    }

    public String getTargetBedNumber() {
        return targetBedNumber;
    }

    public void setTargetBedNumber(String targetBedNumber) {
        this.targetBedNumber = targetBedNumber;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public void setStatus(ApplicationStatus status) {
        this.status = status;
    }

    public Date getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(Date submitTime) {
        this.submitTime = submitTime;
    }

    public Date getReviewTime() {
        return reviewTime;
    }

    public void setReviewTime(Date reviewTime) {
        this.reviewTime = reviewTime;
    }

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public String getReviewRemark() {
        return reviewRemark;
    }

    public void setReviewRemark(String reviewRemark) {
        this.reviewRemark = reviewRemark;
    }

}