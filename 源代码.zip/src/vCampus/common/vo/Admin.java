package vCampus.common.vo;

import java.io.Serializable;

public class Admin implements Serializable {
    private static final long serialVersionUID = 1L;

    private String aCard;        // 工作卡号
    private String aId;          // 管理员账号
    private String aname;        // 姓名
    private String apassword;    // 密码
    private String agender;      // 性别
    private String adepartment;  // 所属部门
    private String aphone;       // 电话
    private String aemail;       // 邮箱
    private Integer astatus;     // 状态 (0=正常, 1=冻结)

    private boolean manageStudent; 
    private boolean manageCourse;  
    private boolean manageLibrary; 
    private boolean manageDorm;    
    private boolean manageShop;    
    private boolean manageBank;
    /** 服务端在登录成功后发放，仅用于图书馆管理员接口。 */
    private String librarySessionToken;

    public String getLibrarySessionToken() { return librarySessionToken; }
    public void setLibrarySessionToken(String token) { librarySessionToken = token; }
    
    public Admin() {
    }

    public Admin(String aId, String aName, String aPassword, String aGender, String aDepartment, String aPhone, String aEmail, String aCard, Integer aStatus) {
       	this.aCard = aCard;
    	    this.aId = aId;
        this.aname = aName;
        this.apassword = aPassword;
        this.agender = aGender;
        this.adepartment = aDepartment;
        this.aphone = aPhone;
        this.aemail = aEmail;
        this.astatus = aStatus;
    }

    public String getAId() {
        return aId;
    }

    public void setAId(String aId) {
        this.aId = aId;
    }

    public String getAName() {
        return aname;
    }

    public void setAName(String aName) {
        this.aname = aName;
    }

    public String getAPassword() {
        return apassword;
    }

    public void setAPassword(String aPassword) {
        this.apassword = aPassword;
    }

    public String getAGender() {
        return agender;
    }

    public void setAGender(String aGender) {
        this.agender = aGender;
    }

    public String getADepartment() {
        return adepartment;
    }

    public void setADepartment(String aDepartment) {
        this.adepartment = aDepartment;
    }

    public String getAPhone() {
        return aphone;
    }

    public void setAPhone(String aPhone) {
        this.aphone = aPhone;
    }

    public String getAEmail() {
        return aemail;
    }

    public void setAEmail(String aEmail) {
        this.aemail = aEmail;
    }

    public String getACard() {
        return aCard;
    }

    public void setACard(String aCard) {
        this.aCard = aCard;
    }

    public Integer getAStatus() {
        return astatus;
    }

    public void setAStatus(Integer aStatus) {
        this.astatus = aStatus;
    }
    public boolean isManageStudent() { return manageStudent; }
    public void setManageStudent(boolean manageStudent) { this.manageStudent = manageStudent; }

    public boolean isManageCourse() { return manageCourse; }
    public void setManageCourse(boolean manageCourse) { this.manageCourse = manageCourse; }

    public boolean isManageLibrary() { return manageLibrary; }
    public void setManageLibrary(boolean manageLibrary) { this.manageLibrary = manageLibrary; }

    public boolean isManageDorm() { return manageDorm; }
    public void setManageDorm(boolean manageDorm) { this.manageDorm = manageDorm; }

    public boolean isManageShop() { return manageShop; }
    public void setManageShop(boolean manageShop) { this.manageShop = manageShop; }

    public boolean isManageBank() { return manageBank; }
    public void setManageBank(boolean manageBank) { this.manageBank = manageBank; }
}