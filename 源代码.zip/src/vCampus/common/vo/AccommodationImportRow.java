package vCampus.common.vo;

import java.io.Serializable;

public class AccommodationImportRow
        implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sId;

    private String dormId;

    private String bedNumber;

    private double fee;


    public AccommodationImportRow() {
    }


    public AccommodationImportRow(
            String sId,
            String dormId,
            String bedNumber,
            double fee) {

        this.sId = sId;
        this.dormId = dormId;
        this.bedNumber = bedNumber;
        this.fee = fee;
    }


    public String getsId() {
        return sId;
    }


    public void setsId(
            String sId) {

        this.sId = sId;
    }


    public String getDormId() {
        return dormId;
    }


    public void setDormId(
            String dormId) {

        this.dormId = dormId;
    }


    public String getBedNumber() {
        return bedNumber;
    }


    public void setBedNumber(
            String bedNumber) {

        this.bedNumber = bedNumber;
    }


    public double getFee() {
        return fee;
    }


    public void setFee(
            double fee) {

        this.fee = fee;
    }
}