package vCampus.common.vo;

import java.io.Serializable;
//培养方案类
public class Program implements Serializable{
	private static final long serialVersionUID=1L;
	
	private String programId;      // 培养方案ID
	private String programName;    // 培养方案名称
	private String major;          // 适用专业
	private String grade;             // 适用年级（入学年份）
	private int totalCreditsRequired; // 毕业要求总学分
	private String semester;       // 适用学期（如 "2025-2026-1"）
	private String status;         // 状态：active / inactive
	private String description;    // 方案描述 
	 
	public Program() {}
	public Program(String programId, String programName, String major, String grade,
             int totalCreditsRequired, String semester, String status, String description) {
        this.programId = programId;
        this.programName = programName;
        this.major = major;
        this.grade = grade;
        this.totalCreditsRequired = totalCreditsRequired;
        this.semester = semester;
        this.status = status;
        this.description = description;
    }
	public String getProgramId() { return programId; }
    public void setProgramId(String programId) { this.programId = programId; }

    public String getProgramName() { return programName; }
    public void setProgramName(String programName) { this.programName = programName; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public int getTotalCreditsRequired() { return totalCreditsRequired; }
    public void setTotalCreditsRequired(int totalCreditsRequired) { this.totalCreditsRequired = totalCreditsRequired; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

}
