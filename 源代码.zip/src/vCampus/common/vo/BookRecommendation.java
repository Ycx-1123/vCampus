package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDateTime;

/** 师生提交的荐书记录，以及管理员查看时使用的采购参考统计。 */
public class BookRecommendation implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String STATUS_PENDING = "PENDING";

    private String recommendationId;
    private String readerCardId;
    private String recommenderType;
    private String bookName;
    private String author;
    private String publisher;
    private String categoryId;
    private String reason;
    private LocalDateTime recommendTime;
    private String status;

    // 仅用于管理员的采购参考列表，不直接存入数据库。
    /** 教师荐书条数，仅用于采购参考展示。 */
    private int teacherRecommendationCount;
    /** 学生荐书条数，仅用于采购参考展示。 */
    private int studentRecommendationCount;
    /** 加权荐书需求：教师每条 2 份，学生每条 1 份。 */
    private int recommendationCount;
    private int activeReservationCount;
    private int referenceScore;
    /** 常规、需求较高、热门采购或紧急采购；仅用于管理员采购页面。 */
    private String demandLevel;
    /** 基于有效预约人数给出的可外借副本增购建议；仅用于管理员采购页面。 */
    private int suggestedAdditionalCopies;

    public String getRecommendationId() { return recommendationId; }
    public void setRecommendationId(String recommendationId) { this.recommendationId = recommendationId; }
    public String getReaderCardId() { return readerCardId; }
    public void setReaderCardId(String readerCardId) { this.readerCardId = readerCardId; }
    public String getRecommenderType() { return recommenderType; }
    public void setRecommenderType(String recommenderType) { this.recommenderType = recommenderType; }
    public String getBookName() { return bookName; }
    public void setBookName(String bookName) { this.bookName = bookName; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public LocalDateTime getRecommendTime() { return recommendTime; }
    public void setRecommendTime(LocalDateTime recommendTime) { this.recommendTime = recommendTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getRecommendationCount() { return recommendationCount; }
    public void setRecommendationCount(int recommendationCount) { this.recommendationCount = recommendationCount; }
    public int getTeacherRecommendationCount() { return teacherRecommendationCount; }
    public void setTeacherRecommendationCount(int teacherRecommendationCount) {
        this.teacherRecommendationCount = teacherRecommendationCount;
    }
    public int getStudentRecommendationCount() { return studentRecommendationCount; }
    public void setStudentRecommendationCount(int studentRecommendationCount) {
        this.studentRecommendationCount = studentRecommendationCount;
    }
    public int getActiveReservationCount() { return activeReservationCount; }
    public void setActiveReservationCount(int activeReservationCount) { this.activeReservationCount = activeReservationCount; }
    public int getReferenceScore() { return referenceScore; }
    public void setReferenceScore(int referenceScore) { this.referenceScore = referenceScore; }
    public String getDemandLevel() { return demandLevel; }
    public void setDemandLevel(String demandLevel) { this.demandLevel = demandLevel; }
    public int getSuggestedAdditionalCopies() { return suggestedAdditionalCopies; }
    public void setSuggestedAdditionalCopies(int suggestedAdditionalCopies) { this.suggestedAdditionalCopies = suggestedAdditionalCopies; }

    /* 兼容旧表中 teacherCardId 的命名。当前页面统一以读者一卡通号展示。 */
    public String getTeacherCardId() { return getReaderCardId(); }
    public void setTeacherCardId(String teacherCardId) { setReaderCardId(teacherCardId); }
}
