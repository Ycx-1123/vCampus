package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 图书馆读者扩展信息。cardId 是学生 sCard 或教师 tCard；readerId 保留用于兼容既有借阅记录。
 */
public class LibraryReader implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String TYPE_STUDENT = "STUDENT";
    public static final String TYPE_TEACHER = "TEACHER";

    private String readerId;
    private String cardId;
    private String readerType;
    private LocalDate borrowingBlockedUntil;

    public LibraryReader() {
    }

    public LibraryReader(String readerId, String readerType) {
        this.readerId = readerId;
        this.cardId = readerId;
        this.readerType = readerType;
    }

    public boolean isBorrowingBlocked(LocalDate borrowDate) {
        return borrowingBlockedUntil != null && !borrowDate.isAfter(borrowingBlockedUntil);
    }

    /**
     * 逾期归还时，设置为从归还日期的下一个自然月起禁止借阅一个自然月。
     */
    public void applyOverduePenalty(LocalDate returnDate) {
        LocalDate nextMonth = returnDate.withDayOfMonth(1).plusMonths(1);
        this.borrowingBlockedUntil = nextMonth.plusMonths(1).minusDays(1);
    }

    public String getReaderId() {
        return readerId;
    }

    public void setReaderId(String readerId) {
        this.readerId = readerId;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getReaderType() {
        return readerType;
    }

    public void setReaderType(String readerType) {
        this.readerType = readerType;
    }

    public LocalDate getBorrowingBlockedUntil() {
        return borrowingBlockedUntil;
    }

    public void setBorrowingBlockedUntil(LocalDate borrowingBlockedUntil) {
        this.borrowingBlockedUntil = borrowingBlockedUntil;
    }
}
