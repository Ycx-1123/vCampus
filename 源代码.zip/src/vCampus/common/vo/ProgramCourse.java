package vCampus.common.vo;

import java.io.Serializable;
//培养方案课程联系类
public class ProgramCourse implements Serializable {
    private static final long serialVersionUID = 1L;

    private int linkId;            // 联系ID（主键）
    private String programId;      // 培养方案ID
    private String courseId;       // 课程编号
    private String courseType;     // 课程类型：required（必修）/ elective（选修）/ limited（限选）
    private String recommendSemester; // 建议修读学期（如 "第3学期"）
    private String prerequisite;   
    private double creditWeight;      // 学分权重

    public ProgramCourse() {}

    public ProgramCourse(String programId, String courseId, String courseType,
                         String recommendSemester, String prerequisite) {
        this.programId = programId;
        this.courseId = courseId;
        this.courseType = courseType;
        this.recommendSemester = recommendSemester;
        this.prerequisite = prerequisite;
        this.creditWeight = 1;
    }

    // Getter 和 Setter
    public int getLinkId() { return linkId; }
    public void setLinkId(int linkId) { this.linkId = linkId; }

    public String getProgramId() { return programId; }
    public void setProgramId(String programId) { this.programId = programId; }

    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }

    public String getCourseType() { return courseType; }
    public void setCourseType(String courseType) { this.courseType = courseType; }

    public String getRecommendSemester() { return recommendSemester; }
    public void setRecommendSemester(String recommendSemester) { this.recommendSemester = recommendSemester; }

    public String getPrerequisite() { return prerequisite; }
    public void setPrerequisite(String prerequisite) { this.prerequisite = prerequisite; }

    public double getCreditWeight() { return creditWeight; }
    public void setCreditWeight(double creditWeight) { this.creditWeight = creditWeight; }

    
    public boolean isRequired() {
        return "required".equals(courseType);
    }

    public boolean isElective() {
        return "elective".equals(courseType);
    }

    public boolean isLimitedElective() {
        return "limited".equals(courseType);
    }

    public String[] getPrerequisiteCourseIds() {//获取先修课程
        if (prerequisite == null || prerequisite.isEmpty()) {
            return new String[0];
        }
        return prerequisite.split(",");
    }

    public boolean hasPrerequisites() {//有无先修课程
        return prerequisite != null && !prerequisite.isEmpty();
    }
}