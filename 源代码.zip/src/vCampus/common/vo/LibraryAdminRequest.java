package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDate;

/** 管理员借阅查询和代办请求。日期范围包含起止两天，空条件表示不限制。 */
public final class LibraryAdminRequest implements Serializable {
    private static final long serialVersionUID = 1L;
    public String sessionToken;
    public String readerId;
    public String bookName;
    public LocalDate fromDate;
    public LocalDate toDate;
    public String copyId;
    public String recordId;
}
