package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 图书预约排队记录。预约针对书目 Book，而不是某一本实体副本 BookCopy。
 */
public class ReservationRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String STATUS_WAITING = "WAITING";
    public static final String STATUS_READY = "READY";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_CANCELLED = "CANCELLED";
    /** 到馆保留期已结束，预约自动失效。 */
    public static final String STATUS_EXPIRED = "EXPIRED";

    private String reservationId;
    private String bookId;
    /** 仅用于展示，由查询时从书目表带回。 */
    private String bookName;
    private String readerId;
    private LocalDateTime reservationTime;
    /** 副本归还并通知该读者到馆取书的时间。 */
    private LocalDateTime readyTime;
    private int queueNumber;
    private String status;

    public ReservationRecord() {
    }

    public ReservationRecord(String reservationId, String bookId, String readerId,
            LocalDateTime reservationTime, int queueNumber) {
        this.reservationId = reservationId;
        this.bookId = bookId;
        this.readerId = readerId;
        this.reservationTime = reservationTime;
        this.queueNumber = queueNumber;
        this.status = STATUS_WAITING;
    }

    public boolean isWaiting() {
        return STATUS_WAITING.equals(status);
    }

    public String getReservationId() {
        return reservationId;
    }

    public void setReservationId(String reservationId) {
        this.reservationId = reservationId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public boolean isReady() {
        return STATUS_READY.equals(status);
    }

    public String getReaderId() {
        return readerId;
    }

    public void setReaderId(String readerId) {
        this.readerId = readerId;
    }

    public LocalDateTime getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(LocalDateTime reservationTime) {
        this.reservationTime = reservationTime;
    }

    public LocalDateTime getReadyTime() {
        return readyTime;
    }

    public void setReadyTime(LocalDateTime readyTime) {
        this.readyTime = readyTime;
    }

    public int getQueueNumber() {
        return queueNumber;
    }

    public void setQueueNumber(int queueNumber) {
        this.queueNumber = queueNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
