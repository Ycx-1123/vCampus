package vCampus.common.vo;

import java.io.Serializable;

//课表
public class Schedule implements Serializable {
    private static final long serialVersionUID = 1L;

    private int scheduleId;        // 排课ID（主键）
    private String courseId;       // 课程编号
    private String classroomId;    // 教室编号
    private int dayOfWeek;         // 星期几（1=周一, 2=周二, ..., 7=周日）
    private String startTime;      // 开始时间（如 "08:00"）
    private String endTime;        // 结束时间（如 "09:35"）
    private int weekStart;         // 起始周（如 1）
    private int weekEnd;           // 结束周（如 16）
    private String semester;       // 学期（如 "2025-2026-1"）

    public Schedule() {}

    public Schedule(String courseId, String classroomId, int dayOfWeek,
                    String startTime, String endTime, int weekStart, int weekEnd, String semester) {
        this.courseId = courseId;
        this.classroomId = classroomId;
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
        this.weekStart = weekStart;
        this.weekEnd = weekEnd;
        this.semester = semester;
    }

   
    public int getScheduleId() { return scheduleId; }
    public void setScheduleId(int scheduleId) { this.scheduleId = scheduleId; }

    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }

    public String getClassroomId() { return classroomId; }
    public void setClassroomId(String classroomId) { this.classroomId = classroomId; }

    public int getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(int dayOfWeek) { this.dayOfWeek = dayOfWeek; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public int getWeekStart() { return weekStart; }
    public void setWeekStart(int weekStart) { this.weekStart = weekStart; }

    public int getWeekEnd() { return weekEnd; }
    public void setWeekEnd(int weekEnd) { this.weekEnd = weekEnd; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    
    public boolean isInWeek(int week) {//本周有无课程
        return week >= weekStart && week <= weekEnd;
    }

    

    public String getDayText() {
        String[] days = {"", "周一", "周二", "周三", "周四", "周五", "周六", "周日"};
        return days[dayOfWeek];
    }
}
