package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

import vCampus.common.enums.FeeStatus;

/**
 * 学生住宿费账单。
 */
public class DormFeeBill implements Serializable {

    private static final long serialVersionUID = 1L;

    private int billId;

    private String sId;

    private int accommodationId;

    /**
     * 学年，例如 2026-2027。
     */
    private String academicYear;

    /**
     * 学期。
     */
    private String semester;

    /**
     * 应缴金额。
     */
    private double amount;

    /**
     * 已缴金额。
     */
    private double paidAmount;

    /**
     * 缴费截止日期。
     */
    private Date dueDate;

    private FeeStatus status;

    private Date createTime;

    public DormFeeBill() {
    }

    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public int getAccommodationId() {
        return accommodationId;
    }

    public void setAccommodationId(int accommodationId) {
        this.accommodationId = accommodationId;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public FeeStatus getStatus() {
        return status;
    }

    public void setStatus(FeeStatus status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 计算当前还需缴纳的金额。
     */
    public double getUnpaidAmount() {
        return amount - paidAmount;
    }
}