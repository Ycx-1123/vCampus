package vCampus.common.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//智能选课结果DTO；用于：一键提交+智能刷新后的返回结果；包含：本次提交结果 + 刷新后的可勾选课程列表
public class SmartSelectResultDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private boolean success;                      // 整体是否成功
    private String message;                       // 结果消息

    // 提交统计
    private int totalCount;                       // 提交总数
    private int successCount;                     // 成功数
    private int failCount;                        // 失败数

    // 刷新结果
    private int refreshedCount;                   // 刷新后可勾选课程数

    // 详细信息
    private List<SelectResultDetail> details;    // 每条选课结果明细
    private List<CourseDisplayDTO> refreshedCourses; // 刷新后的可选课程列表

    public SmartSelectResultDTO() {
        this.details = new ArrayList<>();
        this.refreshedCourses = new ArrayList<>();
    }

    // ========== Getter / Setter ==========
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getSuccessCount() { return successCount; }
    public void setSuccessCount(int successCount) { this.successCount = successCount; }

    public int getFailCount() { return failCount; }
    public void setFailCount(int failCount) { this.failCount = failCount; }

    public int getRefreshedCount() { return refreshedCount; }
    public void setRefreshedCount(int refreshedCount) { this.refreshedCount = refreshedCount; }

    public List<SelectResultDetail> getDetails() { return details; }
    public void setDetails(List<SelectResultDetail> details) { this.details = details; }

    public List<CourseDisplayDTO> getRefreshedCourses() { return refreshedCourses; }
    public void setRefreshedCourses(List<CourseDisplayDTO> refreshedCourses) { this.refreshedCourses = refreshedCourses; }

    // ========== 辅助方法 ==========
    public void addDetail(SelectResultDetail detail) {
        this.details.add(detail);
    }

    public void addRefreshedCourse(CourseDisplayDTO dto) {
        this.refreshedCourses.add(dto);
        this.refreshedCount = this.refreshedCourses.size();
    }

    @Override
    public String toString() {
        return "SmartSelectResultDTO{" +
                "success=" + success +
                ", totalCount=" + totalCount +
                ", successCount=" + successCount +
                ", failCount=" + failCount +
                ", refreshedCount=" + refreshedCount +
                ", message='" + message + '\'' +
                '}';
    }
}
