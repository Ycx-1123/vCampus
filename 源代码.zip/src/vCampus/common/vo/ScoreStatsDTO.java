package vCampus.common.vo;

import java.io.Serializable;

/**
 * 成绩统计DTO
 * 用于：教师查看课程成绩统计
 */
public class ScoreStatsDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private double maxScore;
    private double minScore;
    private double avgScore;
    private double passRate;
    private double excellentRate;
    private int totalStudents;
    private int passCount;
    private int excellentCount;
    private int failCount;

    public ScoreStatsDTO() {}

    public double getMaxScore() { return maxScore; }
    public void setMaxScore(double maxScore) { this.maxScore = maxScore; }

    public double getMinScore() { return minScore; }
    public void setMinScore(double minScore) { this.minScore = minScore; }

    public double getAvgScore() { return avgScore; }
    public void setAvgScore(double avgScore) { this.avgScore = avgScore; }

    public double getPassRate() { return passRate; }
    public void setPassRate(double passRate) { this.passRate = passRate; }

    public double getExcellentRate() { return excellentRate; }
    public void setExcellentRate(double excellentRate) { this.excellentRate = excellentRate; }

    public int getTotalStudents() { return totalStudents; }
    public void setTotalStudents(int totalStudents) { this.totalStudents = totalStudents; }

    public int getPassCount() { return passCount; }
    public void setPassCount(int passCount) { this.passCount = passCount; }

    public int getExcellentCount() { return excellentCount; }
    public void setExcellentCount(int excellentCount) { this.excellentCount = excellentCount; }

    public int getFailCount() { return failCount; }
    public void setFailCount(int failCount) { this.failCount = failCount; }
}
