package vCampus.common.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 批量操作结果DTO
 * 用于：批量录入成绩/批量选课等操作的返回结果
 */
public class BatchResultDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int totalCount;
    private int successCount;
    private int failCount;
    private boolean allSuccess;
    private String message;

    private List<FailDetail> failDetails;

    public BatchResultDTO() {
        this.failDetails = new ArrayList<>();
    }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getSuccessCount() { return successCount; }
    public void setSuccessCount(int successCount) { this.successCount = successCount; }

    public int getFailCount() { return failCount; }
    public void setFailCount(int failCount) { this.failCount = failCount; }

    public boolean isAllSuccess() { return allSuccess; }
    public void setAllSuccess(boolean allSuccess) { this.allSuccess = allSuccess; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public List<FailDetail> getFailDetails() { return failDetails; }
    public void setFailDetails(List<FailDetail> failDetails) { this.failDetails = failDetails; }

    public void addFailDetail(String target, String reason) {
        this.failDetails.add(new FailDetail(target, reason));
        this.failCount = this.failDetails.size();
    }

    public static class FailDetail implements Serializable {
        private static final long serialVersionUID = 1L;

        private String target;
        private String reason;

        public FailDetail() {}

        public FailDetail(String target, String reason) {
            this.target = target;
            this.reason = reason;
        }

        public String getTarget() { return target; }
        public void setTarget(String target) { this.target = target; }

        public String getReason() { return reason; }
        public void setReason(String reason) { this.reason = reason; }
    }
}