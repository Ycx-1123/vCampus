package vCampus.common.vo;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 馆藏实体副本。Book 管理书目信息，BookCopy 管理可被借出或维护的每一本实体书。
 */
public class BookCopy implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String STATUS_AVAILABLE = "AVAILABLE";
    public static final String STATUS_BORROWED = "BORROWED";
    public static final String STATUS_LOST = "LOST";
    public static final String STATUS_DAMAGED = "DAMAGED";
    /** 可外借的开架流通副本。 */
    public static final String CIRCULATION_CIRCULATING = "CIRCULATING";
    /** 保存本、样本书等，仅供馆内阅览。 */
    public static final String CIRCULATION_IN_LIBRARY_ONLY = "IN_LIBRARY_ONLY";

    private String copyId;
    private String bookId;
    private String location;
    private LocalDate acquiredDate;
    private String status;
    private String remark;
    private String circulationType;

    public BookCopy() {
    }

    public BookCopy(String copyId, String bookId, String location, LocalDate acquiredDate) {
        this.copyId = copyId;
        this.bookId = bookId;
        this.location = location;
        this.acquiredDate = acquiredDate;
        this.status = STATUS_AVAILABLE;
        this.circulationType = CIRCULATION_CIRCULATING;
    }

    public boolean isBorrowable() {
        return STATUS_AVAILABLE.equals(status) && !CIRCULATION_IN_LIBRARY_ONLY.equals(circulationType);
    }

    public String getCopyId() {
        return copyId;
    }

    public void setCopyId(String copyId) {
        this.copyId = copyId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getAcquiredDate() {
        return acquiredDate;
    }

    public void setAcquiredDate(LocalDate acquiredDate) {
        this.acquiredDate = acquiredDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCirculationType() {
        return circulationType;
    }

    public void setCirculationType(String circulationType) {
        this.circulationType = circulationType;
    }
}
