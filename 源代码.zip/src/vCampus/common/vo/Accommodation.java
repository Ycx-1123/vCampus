package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

import vCampus.common.enums.StayStatus;

/**
 * 学生住宿记录。
 */
public class Accommodation implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 住宿记录编号。
     */
    private int recordId;

    /**
     * 学生学号。
     */
    private String sId;

    /**
     * 宿舍编号。
     */
    private String dormId;

    /**
     * 床位号。
     */
    private String bedNumber;

    /**
     * 入住时间。
     */
    private Date checkInTime;

    /**
     * 退宿时间。
     */
    private Date checkOutTime;

    /**
     * 当前住宿状态。
     */
    private StayStatus status;

    public Accommodation() {
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getDormId() {
        return dormId;
    }

    public void setDormId(String dormId) {
        this.dormId = dormId;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    public Date getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(Date checkInTime) {
        this.checkInTime = checkInTime;
    }

    public Date getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(Date checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public StayStatus getStatus() {
        return status;
    }

    public void setStatus(StayStatus status) {
        this.status = status;
    }
}