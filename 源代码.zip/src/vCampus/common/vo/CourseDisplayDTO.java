package vCampus.common.vo;

import java.io.Serializable;

public class CourseDisplayDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String courseId;
    private String courseName;
    private double credit;
    private String nature;
    private String department;
    private String offeringId;
    private String classNum;
    private String teacherId;
    private String teacherName;
    private String schedule;
    private String classroom;
    private String semester;
    private int capacity;
    private int enrolledCount;
    private boolean full;
    private boolean selected;
    private String selectType;
    private String status;
    private boolean conflict;
    private Double score;
    private boolean sameCourseConflict;
    private String courseType;  // 课程类别
    private String campus;      // 校区
    private String roundStatus;   // ★ 加这个

    public String getRoundStatus() { return roundStatus; }
    public void setRoundStatus(String roundStatus) { this.roundStatus = roundStatus; }
    // getter和setter
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    
    public double getCredit() { return credit; }
    public void setCredit(double credit) { this.credit = credit; }
    
    public String getNature() { return nature; }
    public void setNature(String nature) { this.nature = nature; }
    
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    
    public String getOfferingId() { return offeringId; }
    public void setOfferingId(String offeringId) { this.offeringId = offeringId; }
    
    public String getClassNum() { return classNum; }
    public void setClassNum(String classNum) { this.classNum = classNum; }
    
    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }
    
    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
    
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    
    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }
    
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    
    public int getEnrolledCount() { return enrolledCount; }
    public void setEnrolledCount(int enrolledCount) { this.enrolledCount = enrolledCount; }
    
    public boolean isFull() { return full; }
    public void setFull(boolean full) { this.full = full; }
    
    public boolean isSelected() { return selected; }
    public void setSelected(boolean selected) { this.selected = selected; }
    
    public String getSelectType() { return selectType; }
    public void setSelectType(String selectType) { this.selectType = selectType; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public boolean isConflict() { return conflict; }
    public void setConflict(boolean conflict) { this.conflict = conflict; }
    
    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }
    
    public boolean isSameCourseConflict() { return sameCourseConflict; }
    public void setSameCourseConflict(boolean sameCourseConflict) { this.sameCourseConflict = sameCourseConflict; }
    
    public String getCourseType() { return courseType; }
    public void setCourseType(String courseType) { this.courseType = courseType; }
    
    public String getCampus() { return campus; }
    public void setCampus(String campus) { this.campus = campus; }
}