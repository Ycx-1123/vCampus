package vCampus.common.vo;

import java.io.Serializable;

/**
 * 批量成绩录入DTO
 * 用于：教师批量录入成绩
 */
public class ScoreEntryDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int selectId;
    private double score;

    public ScoreEntryDTO() {}

    public ScoreEntryDTO(int selectId, double score) {
        this.selectId = selectId;
        this.score = score;
    }

    public int getSelectId() { return selectId; }
    public void setSelectId(int selectId) { this.selectId = selectId; }

    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
}