package vCampus.common.vo;

import java.io.Serializable;
import java.util.Date;

public class SelectRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private int selectId;          // 选课记录ID（主键）
    private String studentId;      // 学号
    private String offeringId;       // 课程编号
    private Date selectTime;       // 选课时间
    private Double score;          // 成绩（未录入时为 null）
    private String status;         // 状态：selected / dropped / completed
    private String selectType;     // 选课类型：first（首修）/ retake（重修）

    public SelectRecord() {}

    public SelectRecord(String studentId, String offeringId, String selectType) {
        this.studentId = studentId;
        this.offeringId = offeringId;
        this.selectTime = new Date();
        this.status = "selected";
        this.selectType = selectType;
        this.score = null;
    }

    // Getter 和 Setter
    public int getSelectId() { return selectId; }
    public void setSelectId(int selectId) { this.selectId = selectId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getOfferingId() { return offeringId; }
    public void setOfferingId(String offeringId) { this.offeringId = offeringId; }

    public Date getSelectTime() { return selectTime; }
    public void setSelectTime(Date selectTime) { this.selectTime = selectTime; }

    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSelectType() { return selectType; }
    public void setSelectType(String selectType) { this.selectType = selectType; }
    
    public boolean isFirstTime() {
        return "first".equals(selectType);
    }

    public boolean isRetake() {
        return "retake".equals(selectType);
    }
}