package vCampus.common.vo;

import java.io.Serializable;

public class Category implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String categoryId;
    private String categoryName;
    private String categoryCode;
    private String description;
    private int sortOrder;
    
    public Category() {}
    
    public Category(String categoryId, String categoryName, String categoryCode, String description, int sortOrder) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.categoryCode = categoryCode;
        this.description = description;
        this.sortOrder = sortOrder;
    }
    
    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }
    
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    
    public String getCategoryCode() { return categoryCode; }
    public void setCategoryCode(String categoryCode) { this.categoryCode = categoryCode; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public int getSortOrder() { return sortOrder; }
    public void setSortOrder(int sortOrder) { this.sortOrder = sortOrder; }
}