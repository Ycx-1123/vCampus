package vCampus.common.vo;

import java.io.Serializable;

//单条选课结果明细,用于：一键提交时返回每门课的处理结果
public class SelectResultDetail implements Serializable {
    private static final long serialVersionUID = 1L;

    private String offeringId;        // 开课班级ID
    private String courseName;        // 课程名
    private int priority;             // 优先级
    private boolean success;          // 是否成功
    private String message;           // 结果消息

    public SelectResultDetail() {}

    public SelectResultDetail(String offeringId, String courseName, int priority, boolean success, String message) {
        this.offeringId = offeringId;
        this.courseName = courseName;
        this.priority = priority;
        this.success = success;
        this.message = message;
    }

    //Getter / Setter
    public String getOfferingId() { return offeringId; }
    public void setOfferingId(String offeringId) { this.offeringId = offeringId; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    @Override
    public String toString() {
        return "SelectResultDetail{" +
                "courseName='" + courseName + '\'' +
                ", success=" + success +
                ", message='" + message + '\'' +
                '}';
    }
}
