package vCampus.common.vo;

import java.io.Serializable;

/**
 * 学生成绩信息DTO
 * 用于：教师查看课程学生名单（含首修/重修标识和成绩）
 */
public class StudentScoreDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int selectId;
    private String studentId;
    private String studentName;
    private String gender;
    private String major;
    private String className;
    private String selectType;      // first / retake
    private Double score;
    private String status;          // selected / completed / dropped

    public StudentScoreDTO() {}

    public int getSelectId() { return selectId; }
    public void setSelectId(int selectId) { this.selectId = selectId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    public String getSelectType() { return selectType; }
    public void setSelectType(String selectType) { this.selectType = selectType; }

    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSelectTypeText() {
        return "first".equals(selectType) ? "首修" : "重修";
    }

    public boolean hasScore() {
        return score != null;
    }

    public boolean isPassed() {
        return score != null && score >= 60;
    }
}
