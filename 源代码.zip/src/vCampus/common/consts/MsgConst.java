package vCampus.common.consts;
//zhishiweileshangchuan
public final class MsgConst {
	//====学籍管理type常量====
	//Department
	public static final String QUERY_ALL_DEPT = "QUERY_ALL_DEPT";
	public static final String QUERY_DEPT_BY_DEPTID = "QUERY_DEPT_BY_DEPTID";
    public static final String ADD_DEPT = "ADD_DEPT";
    public static final String UPDATE_DEPT = "UPDATE_DEPT";
    public static final String DELETE_DEPT = "DELETE_DEPT";
    //Major
    public static final String QUERY_MAJOR_BY_MAJORID = "QUERY_MAJOR_BY_MAJORID";
    public static final String QUERY_MAJOR_BY_DEPTID = "QUERY_MAJOR_BY_DEPTID";
    public static final String QUERY_ALL_MAJOR = "QUERY_ALL_MAJOR";
    public static final String ADD_MAJOR = "ADD_MAJOR";
    public static final String UPDATE_MAJOR = "UPDATE_MAJOR";
    public static final String DELETE_MAJOR = "DELETE_MAJOR";
    //Clazz
    public static final String QUERY_CLAZZ_BY_CLAZZID = "QUERY_CLAZZ_BY_CLAZZID";
    public static final String QUERY_CLAZZ_BY_MAJORID = "QUERY_CLAZZ_BY_MAJORID";
    public static final String QUERY_ALL_CLAZZ = "QUERY_ALL_CLAZZ";
    public static final String ADD_CLAZZ = "ADD_CLAZZ";
    public static final String UPDATE_CLAZZ = "UPDATE_CLAZZ";
    public static final String DELETE_CLAZZ = "DELETE_CLAZZ";
    //Student
    public static final String QUERY_STUDENT_BY_CID = "QUERY_STUDENT_BY_CID";
    public static final String QUERY_STUDENT_BY_SCARD = "QUERY_STUDENT_BY_SCARD";
    public static final String QUERY_ALL_STUDENT = "QUERY_ALL_STUDENT";
    public static final String ADD_STUDENT = "ADD_STUDENT";
    public static final String UPDATE_STUDENT = "UPDATE_STUDENT";
    public static final String DELETE_STUDENT = "DELETE_STUDENT";
    public static final String LOCK_STUDENT = "LOCK_STUDENT";
    public static final String UNLOCK_STUDENT = "UNLOCK_STUDENT";
    public static final String QUERY_PROGRAM_BY_MAJOR_AND_GRADE = "QUERY_PROGRAM_BY_MAJOR_AND_GRADE";
    public static final String ADMIN_IMPORT_STUDENT_EXCEL = "ADMIN_IMPORT_STUDENT_EXCEL";
    public static final String QUERY_COMPLETED_CREDIT = "QUERY_COMPLETED_CREDIT";
    
    //选课模块type常量
    public static final String GET_AVAILABLE_COURSES = "GET_AVAILABLE_COURSES";     // 获取可选课程
    public static final String GET_SELECTED_COURSES = "GET_SELECTED_COURSES";       // 获取已选课程
    public static final String SUBMIT_ALL_COURSES = "SUBMIT_ALL_COURSES";           // 一键提交
    public static final String DROP_COURSE = "DROP_COURSE";                         // 退课
    public static final String GET_OPEN_ROUNDS_FOR_STUDENT = "GET_OPEN_ROUNDS_FOR_STUDENT"; // 获取所有开放的轮次
    // 教师端 - 课程管理
    public static final String TEACHER_GET_MY_COURSES = "TEACHER_GET_MY_COURSES";   // 获取教师课程
    public static final String TEACHER_GET_STUDENTS = "TEACHER_GET_STUDENTS";       // 获取学生名单
    public static final String TEACHER_GET_SCHEDULE = "TEACHER_GET_SCHEDULE";       // 教师课表
    public static final String TEACHER_ENTER_SCORE = "TEACHER_ENTER_SCORE";         // 录入/修改成绩（新增）
    public static final String TEACHER_BATCH_ENTER_SCORE = "TEACHER_BATCH_ENTER_SCORE"; 
    public static final String TEACHER_GET_STATS = "TEACHER_GET_STATS";
    public static final String TEACHER_GET_MY_SEMESTERS = "TEACHER_GET_MY_SEMESTERS"; // 教师获取自己的授课学期列表
    // 管理员端 - 课程管理
    public static final String ADMIN_GET_ALL_COURSES = "ADMIN_GET_ALL_COURSES";     // 获取所有课程
    public static final String ADMIN_ADD_COURSE = "ADMIN_ADD_COURSE";               // 新增课程
    public static final String ADMIN_UPDATE_COURSE = "ADMIN_UPDATE_COURSE";         // 修改课程
    public static final String ADMIN_DELETE_COURSE = "ADMIN_DELETE_COURSE";         // 删除课程
    public static final String ADMIN_GET_COURSE_DETAIL = "ADMIN_GET_COURSE_DETAIL"; // 课程详情
    public static final String ADMIN_QUERY_COURSE_BY_ID = "ADMIN_QUERY_COURSE_BY_ID";       // 按课程号查询课程
    public static final String ADMIN_QUERY_TEACHER_BY_ID = "ADMIN_QUERY_TEACHER_BY_ID";     // 按教师工号查询教师
    public static final String ADMIN_UPDATE_COURSE_AND_OFFERING = "ADMIN_UPDATE_COURSE_AND_OFFERING";  // 修改课程和开课
    public static final String ADMIN_DELETE_OFFERING = "ADMIN_DELETE_OFFERING";                          // 删除开课
 // 管理员端 - 批量新增课程
    public static final String ADMIN_GET_ALL_PROGRAMS = "ADMIN_GET_ALL_PROGRAMS";
    public static final String ADMIN_GET_PROGRAM_COURSES = "ADMIN_GET_PROGRAM_COURSES";
    public static final String ADMIN_BATCH_ADD_COURSE = "ADMIN_BATCH_ADD_COURSE";
    public static final String ADMIN_GET_OFFERING_IDS = "ADMIN_GET_OFFERING_IDS";
    // 管理员端 - 选课管理
    public static final String ADMIN_HELP_SELECT = "ADMIN_HELP_SELECT";             // 帮学生选课
    public static final String ADMIN_HELP_DROP = "ADMIN_HELP_DROP";                 // 帮学生退课
    public static final String ADMIN_GET_SELECT_STATS = "ADMIN_GET_SELECT_STATS";   // 选课统计
    public static final String ADMIN_GET_STUDENT_STATUS = "ADMIN_GET_STUDENT_STATUS"; // 学生选课状态
 // 管理员端 - 选课管理（新增）
    public static final String ADMIN_SEARCH_STUDENTS = "ADMIN_SEARCH_STUDENTS";       // 按关键词搜索学生
    public static final String ADMIN_GET_STUDENT_SELECTED = "ADMIN_GET_STUDENT_SELECTED"; // 获取学生已选课程
    public static final String ADMIN_GET_AVAILABLE_FOR_STUDENT = "ADMIN_GET_AVAILABLE_FOR_STUDENT"; // 获取学生可选课程
    // 管理员端 - 选课设置
    public static final String ADMIN_GET_SELECT_STATUS = "ADMIN_GET_SELECT_STATUS"; // 获取选课状态
    
    public static final String ADMIN_GET_SELECT_HISTORY = "ADMIN_GET_SELECT_HISTORY"; // 选课历史
    public static final String ADMIN_GET_SEMESTERS = "ADMIN_GET_SEMESTERS";         // 获取学期列表
 // 选课轮次相关
    public static final String ADMIN_GET_ALL_ROUNDS = "ADMIN_GET_ALL_ROUNDS";         // 获取所有轮次
    public static final String ADMIN_ADD_ROUND = "ADMIN_ADD_ROUND";                   // 新增轮次
    public static final String ADMIN_CLOSE_ROUND = "ADMIN_CLOSE_ROUND";               // 关闭轮次
    public static final String ADMIN_OPEN_ROUND = "ADMIN_OPEN_ROUND";                 // 开放轮次
    public static final String ADMIN_DELETE_ROUND = "ADMIN_DELETE_ROUND";             // 删除轮次
    public static final String GET_CURRENT_ROUND = "GET_CURRENT_ROUND";               // 获取当前开放的轮次
 // 管理员端 - 课表 Excel 导入导出
    public static final String ADMIN_EXPORT_OFFERING_TEMPLATE = "ADMIN_EXPORT_OFFERING_TEMPLATE";   // 导出模板
    public static final String ADMIN_IMPORT_OFFERING_EXCEL = "ADMIN_IMPORT_OFFERING_EXCEL";         // 导入课表
    public static final String ADMIN_CLONE_ROUND_OFFERINGS = "ADMIN_CLONE_ROUND_OFFERINGS";
    public static final String ADMIN_UPDATE_ROUND = "ADMIN_UPDATE_ROUND";
    public static final String ADMIN_GET_COURSES_BY_IDS = "ADMIN_GET_COURSES_BY_IDS";
    public static final String GET_RETAKE_COURSES_BY_ROUND = "GET_RETAKE_COURSES_BY_ROUND";
    public static final String GET_ALL_COURSES_BY_ROUND = "GET_ALL_COURSES_BY_ROUND";
    // ============================================================
    // 宿舍管理模块 type 常量
    // ============================================================

    // ---------- 学生端：宿舍查询 ----------
    public static final String DORM_QUERY_ALL ="DORM_QUERY_ALL";
    public static final String DORM_QUERY_AVAILABLE ="DORM_QUERY_AVAILABLE";
    public static final String DORM_QUERY_MY ="DORM_QUERY_MY";
    public static final String DORM_QUERY_REMAINING_BEDS ="DORM_QUERY_REMAINING_BEDS";
    public static final String DORM_QUERY_AVAILABLE_BEDS ="DORM_QUERY_AVAILABLE_BEDS";


    // ---------- 学生端：宿舍申请 ----------
    public static final String DORM_APPLY_CHANGE ="DORM_APPLY_CHANGE";
    public static final String DORM_APPLY_CHECKOUT ="DORM_APPLY_CHECKOUT";
    public static final String DORM_QUERY_MY_APPLICATIONS ="DORM_QUERY_MY_APPLICATIONS";
    public static final String DORM_CANCEL_APPLICATION ="DORM_CANCEL_APPLICATION";

    // ---------- 学生端：报修 ----------
    public static final String DORM_SUBMIT_REPAIR ="DORM_SUBMIT_REPAIR";
    public static final String DORM_QUERY_MY_REPAIRS ="DORM_QUERY_MY_REPAIRS";
    public static final String DORM_CANCEL_REPAIR ="DORM_CANCEL_REPAIR";


    // ---------- 学生端：缴费 ----------
    public static final String DORM_QUERY_MY_BILLS ="DORM_QUERY_MY_BILLS";
    public static final String DORM_QUERY_UNPAID_BILLS ="DORM_QUERY_UNPAID_BILLS";
    public static final String DORM_PAY_BILL ="DORM_PAY_BILL";
    public static final String DORM_QUERY_PAYMENT_HISTORY ="DORM_QUERY_PAYMENT_HISTORY";

    // ---------- 管理员端：宿舍维护 ----------
    public static final String DORM_ADMIN_QUERY_ALL ="DORM_ADMIN_QUERY_ALL";
    public static final String DORM_ADMIN_QUERY_AVAILABLE ="DORM_ADMIN_QUERY_AVAILABLE";
    public static final String DORM_ADMIN_ADD ="DORM_ADMIN_ADD";
    public static final String DORM_ADMIN_UPDATE ="DORM_ADMIN_UPDATE";
    public static final String DORM_ADMIN_DELETE ="DORM_ADMIN_DELETE";

    // ---------- 管理员端：住宿管理 ----------
    public static final String DORM_ADMIN_CHECK_IN ="DORM_ADMIN_CHECK_IN";
    public static final String DORM_ADMIN_CHECK_OUT ="DORM_ADMIN_CHECK_OUT";
    public static final String DORM_ADMIN_BATCH_CHECK_IN =
    		"DORM_ADMIN_BATCH_CHECK_IN";
    public static final String DORM_ADMIN_CHANGE ="DORM_ADMIN_CHANGE";
    public static final String DORM_ADMIN_QUERY_STUDENT ="DORM_ADMIN_QUERY_STUDENT";
    public static final String DORM_QUERY_HISTORY ="DORM_QUERY_HISTORY";
    // ---------- 管理员端：申请审核 ----------
    public static final String DORM_ADMIN_QUERY_PENDING_APPLICATIONS ="DORM_ADMIN_QUERY_PENDING_APPLICATIONS";
    public static final String DORM_ADMIN_QUERY_APPLICATIONS_BY_TYPE ="DORM_ADMIN_QUERY_APPLICATIONS_BY_TYPE";
    public static final String DORM_ADMIN_APPROVE_APPLICATION ="DORM_ADMIN_APPROVE_APPLICATION";
    public static final String DORM_ADMIN_REJECT_APPLICATION ="DORM_ADMIN_REJECT_APPLICATION";

    // ---------- 管理员端：报修管理 ----------
    public static final String DORM_ADMIN_QUERY_ALL_REPAIRS ="DORM_ADMIN_QUERY_ALL_REPAIRS";
    public static final String DORM_ADMIN_QUERY_REPAIR_BY_ID ="DORM_ADMIN_QUERY_REPAIR_BY_ID";
    public static final String DORM_ADMIN_UPDATE_REPAIR_STATUS ="DORM_ADMIN_UPDATE_REPAIR_STATUS";

    // ---------- 管理员端：费用管理 ----------
    public static final String DORM_ADMIN_CREATE_BILL ="DORM_ADMIN_CREATE_BILL";
    public static final String DORM_ADMIN_BATCH_CREATE_BILLS ="DORM_ADMIN_BATCH_CREATE_BILLS";
    public static final String DORM_ADMIN_QUERY_ALL_BILLS ="DORM_ADMIN_QUERY_ALL_BILLS";
    public static final String DORM_ADMIN_QUERY_STUDENT_BILLS ="DORM_ADMIN_QUERY_STUDENT_BILLS";
    public static final String DORM_ADMIN_QUERY_UNPAID_BILLS ="DORM_ADMIN_QUERY_UNPAID_BILLS";
    public static final String DORM_ADMIN_QUERY_BILL_BY_ID ="DORM_ADMIN_QUERY_BILL_BY_ID";
    public static final String DORM_ADMIN_ADJUST_BILL ="DORM_ADMIN_ADJUST_BILL";
    public static final String DORM_ADMIN_CANCEL_BILL ="DORM_ADMIN_CANCEL_BILL";
    
    //====图书馆模块 type 常量====
    public static final String QUERY_ALL_BOOKS = "QUERY_ALL_BOOKS";
    public static final String SEARCH_BOOKS = "SEARCH_BOOKS";
    public static final String ADD_BOOK = "ADD_BOOK";
    public static final String UPDATE_BOOK = "UPDATE_BOOK";
    public static final String DELETE_BOOK = "DELETE_BOOK";
    public static final String QUERY_BOOK_CATEGORIES = "QUERY_BOOK_CATEGORIES";
    public static final String ADD_BOOK_CATEGORY = "ADD_BOOK_CATEGORY";
    public static final String UPDATE_BOOK_CATEGORY = "UPDATE_BOOK_CATEGORY";
    public static final String DELETE_BOOK_CATEGORY = "DELETE_BOOK_CATEGORY";
    public static final String QUERY_BOOK_COPIES = "QUERY_BOOK_COPIES";
    public static final String ADD_BOOK_COPY = "ADD_BOOK_COPY";
    public static final String UPDATE_BOOK_COPY = "UPDATE_BOOK_COPY";
    public static final String DELETE_BOOK_COPY = "DELETE_BOOK_COPY";
    public static final String BORROW_BOOK = "BORROW_BOOK";
    public static final String RETURN_BOOK = "RETURN_BOOK";
    public static final String RETURN_DAMAGED_BOOK = "RETURN_DAMAGED_BOOK";
    public static final String RENEW_BOOK = "RENEW_BOOK";
    public static final String RESERVE_BOOK = "RESERVE_BOOK";
    public static final String CANCEL_RESERVATION = "CANCEL_RESERVATION";
    public static final String QUERY_MY_RESERVATIONS = "QUERY_MY_RESERVATIONS";
    public static final String QUERY_RESERVATION_QUEUE = "QUERY_RESERVATION_QUEUE";
    public static final String QUERY_MY_BORROW_RECORDS = "QUERY_MY_BORROW_RECORDS";
    public static final String LIBRARY_ADMIN_QUERY_BORROWS = "LIBRARY_ADMIN_QUERY_BORROWS";
    public static final String LIBRARY_ADMIN_BORROW = "LIBRARY_ADMIN_BORROW";
    public static final String LIBRARY_ADMIN_RETURN = "LIBRARY_ADMIN_RETURN";
    public static final String QUERY_LIBRARY_READER = "QUERY_LIBRARY_READER";
    public static final String CHECK_BORROW_PERMISSION = "CHECK_BORROW_PERMISSION";
    public static final String SUBMIT_BOOK_RECOMMENDATION = "SUBMIT_BOOK_RECOMMENDATION";
    public static final String QUERY_MY_BOOK_RECOMMENDATIONS = "QUERY_MY_BOOK_RECOMMENDATIONS";
    public static final String QUERY_BOOK_PROCUREMENT_REFERENCES = "QUERY_BOOK_PROCUREMENT_REFERENCES";
    
    // ==== 银行模块 ====
    public static final String BANK_OPEN_ACCOUNT = "BANK_OPEN_ACCOUNT";
    public static final String BANK_GET_ACCOUNT = "BANK_GET_ACCOUNT";
    public static final String BANK_DEPOSIT = "BANK_DEPOSIT";
    public static final String BANK_WITHDRAW = "BANK_WITHDRAW";
    public static final String BANK_TRANSFER = "BANK_TRANSFER";
    public static final String BANK_RECHARGE_CAMPUS = "BANK_RECHARGE_CAMPUS";
    public static final String BANK_GET_TRANSACTIONS = "BANK_GET_TRANSACTIONS";
    public static final String BANK_ADMIN_GET_ACCOUNTS = "BANK_ADMIN_GET_ACCOUNTS";
    public static final String BANK_ADMIN_FREEZE = "BANK_ADMIN_FREEZE";
    public static final String BANK_ADMIN_UNFREEZE = "BANK_ADMIN_UNFREEZE";
    public static final String BANK_DORM_PAYMENT = "BANK_DORM_PAYMENT";
    
    
    private MsgConst(){
    }
}