package vCampus.common.enums;

/**
 * 学生住宿状态。
 */
public enum StayStatus {

    /**
     * 当前正在住宿。
     */
    IN,

    /**
     * 已经办理退宿。
     */
    OUT
}