package vCampus.common.enums;

/**
 * 宿舍申请审核状态。
 */
public enum ApplicationStatus {

    /**
     * 等待审核。
     */
    PENDING,

    /**
     * 审核通过。
     */
    APPROVED,

    /**
     * 审核拒绝。
     */
    REJECTED,

    /**
     * 学生主动取消。
     */
    CANCELLED
}