package vCampus.common.enums;

/**
 * 单次支付状态。
 */
public enum PaymentStatus {

    /**
     * 支付处理中。
     */
    PENDING,

    /**
     * 支付成功。
     */
    SUCCESS,

    /**
     * 支付失败。
     */
    FAILED,

    /**
     * 已退款。
     */
    REFUNDED
}