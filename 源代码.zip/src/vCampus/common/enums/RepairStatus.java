package vCampus.common.enums;

/**
 * 宿舍报修处理状态。
 */
public enum RepairStatus {

    /**
     * 待处理。
     */
    PENDING,

    /**
     * 正在处理。
     */
    PROCESSING,

    /**
     * 已完成。
     */
    FINISHED,

    /**
     * 已取消。
     */
    CANCELLED
}