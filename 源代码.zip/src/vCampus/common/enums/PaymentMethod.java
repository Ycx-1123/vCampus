package vCampus.common.enums;

/**
 * 住宿费支付方式。
 */
public enum PaymentMethod {

    /**
     * 虚拟校园银行账户。
     */
    CAMPUS_BANK,

    /**
     * 现金。
     */
    CASH,

    /**
     * 其他方式。
     */
    OTHER
}