package vCampus.common.enums;

/**
 * 宿舍申请类型。
 */
public enum ApplicationType {

    /**
     * 调整宿舍申请。
     */
    CHANGE_DORM,

    /**
     * 在校生退宿申请。
     */
    CHECKOUT_CURRENT,

    /**
     * 毕业生退宿申请。
     */
    CHECKOUT_GRADUATE
}