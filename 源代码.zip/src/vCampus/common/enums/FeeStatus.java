package vCampus.common.enums;

/**
 * 住宿费账单状态。
 */
public enum FeeStatus {

    /**
     * 尚未缴费。
     */
    UNPAID,

    /**
     * 已缴纳部分费用。
     */
    PARTIALLY_PAID,

    /**
     * 已全部缴清。
     */
    PAID,

    /**
     * 已超过缴费期限。
     */
    OVERDUE,

    /**
     * 账单已作废。
     */
    CANCELLED
}