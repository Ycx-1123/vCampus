package vCampus.common.shop;

import java.io.Serializable;

/**
 * 用户账户信息（用于支付）
 */
public class UserAccount implements Serializable {
    private String userId;
    private double cardBalance;   // 校园卡余额
    private double bankBalance;   // 银行卡余额
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
//	public double getCardBalance() {
//		return cardBalance;
//	}
//	public void setCardBalance(double cardBalance) {
//		this.cardBalance = cardBalance;
//	}
//	public double getBankBalance() {
//		return bankBalance;
//	}
//	public void setBankBalance(double bankBalance) {
//		this.bankBalance = bankBalance;
//	}

    // 构造、getter/setter
    
}