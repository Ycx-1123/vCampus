package vCampus.common.shop;

import java.io.Serializable;

/**
 * 订单明细实体类（对应数据库表 tblOrderItem）
 */
public class OrderItem implements Serializable {

    private static final long serialVersionUID = 1L;

    private long id;          // 明细行编号
    private long orderId;     // 所属订单ID
    private int productId;   // 商品ID
    private int quantity;    // 购买数量
    private double unitPrice;// 下单时的单价（快照）

    // 无参构造
    public OrderItem() {}

    

    public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public long getOrderId() {
		return orderId;
	}



	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}



	public int getProductId() {
		return productId;
	}



	public void setProductId(int productId) {
		this.productId = productId;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public double getUnitPrice() {
		return unitPrice;
	}



	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	// 计算小计金额（非数据库字段，逻辑辅助方法）
    public double calcSubtotal() {
        return this.quantity * this.unitPrice;
    }
}