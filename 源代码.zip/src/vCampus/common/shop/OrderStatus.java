package vCampus.common.shop;

/**
 * 订单状态枚举
 * @author mxpan
 */
public enum OrderStatus {
    /** 已创建（待支付） */
    CREATED,
    /** 已支付 */
    PAID,
    /** 已取消 */
    CANCELLED,
    /** 已完成（已收货/已关闭） */
    FINISHED
}

