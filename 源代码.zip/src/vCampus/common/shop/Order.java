package vCampus.common.shop;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单实体类（对应数据库表 tblOrder）
 * 用于客户端与服务器端之间的网络传输。
 * 
 * @author mxpan
 * @version 1.0
 */
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 订单编号（对应数据库自动编号） */
    private long id;

    /** 下单用户的登录名（关联 tblUser 的 uId） */
    private String userId;

    /** 订单总金额 */
    private double totalAmount;

    /** 订单状态（枚举） */
    private OrderStatus status;

    /** 下单时间 */
    private Date createTime;

    // ========== 构造方法 ==========

    /** 无参构造（必须，用于反序列化） */
    public Order() {
    }

    /** 全参构造（方便创建测试数据） */
    public Order(long id, String userId, double totalAmount, OrderStatus status, Date createTime) {
        this.id = id;
        this.userId = userId;
        this.totalAmount = totalAmount;
        this.status = status;
        this.createTime = createTime;
    }

    // ========== Getter 和 Setter ==========
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    // ========== 辅助方法（便于调试） ==========

    @Override
    public String toString() {
        return "Order [id=" + id + ", userId=" + userId + ", totalAmount=" + totalAmount 
                + ", status=" + status + ", createTime=" + createTime + "]";
    }
}