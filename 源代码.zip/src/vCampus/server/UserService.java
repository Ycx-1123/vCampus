package vCampus.server;

import vCampus.server.dao.UserDao;

/**
 * 用户及账户相关的业务逻辑层。
 * 负责处理登录验证、密码修改等跨角色的账户操作。
 */
public class UserService {

    private final UserDao userDao = new UserDao();

    /**
     * 修改用户密码
     * 
     * @param role   角色类型 ("Student", "Teacher", "Admin")
     * @param cardId 对应的卡号/学号/工号
     * @param newPassword 新密码
     * @return 是否修改成功
     */
    
    public boolean updatePassword(String role, String cardId, String newPassword) {
        // 1. 基础参数校验
        if (role == null || cardId == null || newPassword == null) {
            return false;
        }
        
        if (newPassword.trim().isEmpty() || cardId.trim().isEmpty()) {
            return false;
        }

        // 2. 调用 UserDao 执行更新
        return userDao.updatePassword(role, cardId, newPassword.trim());
    }
}