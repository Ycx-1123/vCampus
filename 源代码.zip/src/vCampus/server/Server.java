package vCampus.server;

import java.io.ObjectInputStream;
import java.util.concurrent.ConcurrentHashMap; 
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.logging.*;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.shop.Order;
import vCampus.common.shop.OrderItem;
import vCampus.common.shop.Product;
import vCampus.common.vo.Book;
import vCampus.common.vo.BookCategory;
import vCampus.common.vo.BookCopy;
import vCampus.common.vo.BookRecommendation;
import vCampus.common.vo.BorrowRecord;
import vCampus.common.vo.Admin;
import vCampus.common.vo.LibraryAdminRequest;
import vCampus.common.vo.LibraryReader;
import vCampus.common.vo.ReservationRecord;
import vCampus.common.vo.Student;
import vCampus.common.vo.BankAccount;
import vCampus.server.service.LibraryService;
import vCampus.server.handler.StudentHandler;
import vCampus.server.dao.UserDao;
import vCampus.server.handler.DormHandler;
import vCampus.server.ShopServerSrvImpl;
import vCampus.server.service.RoundAutoScheduler;

public class Server {
    private static final int PORT = 8888;
    
    // ===== 初始化日志记录器 (Initialize Logger) =====
    private static final Logger logger = Logger.getLogger("vCampusServer");
    // ===== 维护当前在线用户的会话池 (一卡通号 -> 登录时间戳) (Session pool for active users) =====
    private static final ConcurrentHashMap<String, Long> activeUsers = new ConcurrentHashMap<>();
    
    static {
        try {
            // 参数 true 表示追加写入，不会覆盖之前的日志 (Append mode: true)
            FileHandler fileHandler = new FileHandler("server_operations.log", true);
            fileHandler.setFormatter(new SimpleFormatter()); // 使用简单易读的纯文本格式
            logger.addHandler(fileHandler);
            logger.info("服务端日志系统初始化完成...");
        } catch (Exception e) {
            System.err.println("日志文件创建失败: " + e.getMessage());
        }
    }
    
    private static final LibraryService LIBRARY_SERVICE = new LibraryService();
    private static final vCampus.server.service.LibraryAdminService LIBRARY_ADMIN_SERVICE = new vCampus.server.service.LibraryAdminService();
    private static final StudentHandler STUDENT_HANDLER = new StudentHandler();
    private static final ShopServerSrvImpl SHOP_SERVICE = new ShopServerSrvImpl();
    private static final vCampus.server.service.BankService BANK_SERVICE = new vCampus.server.service.BankService();

    public static void main(String[] args) {
        RoundAutoScheduler.start();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("服务端启动成功，正在监听端口 " + PORT + "...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("检测到新客户端连接：" + socket.getInetAddress());
                new Thread(new ClientHandler(socket)).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {
                Object reqObj = in.readObject();
                Message response = new Message();

                if (reqObj instanceof Message) {
                    Message request = (Message) reqObj;
                    Object data = request.getData();
                    response.setType(request.getType());
                    
                    String reqType = request.getType();
                    String senderId = request.getSenderId();

                    // ==========================================
                    // ★ 全局会话互斥拦截器 (Global Session Interceptor)
                    // ==========================================
                    // 如果不是登录操作，且携带了 senderId，则校验在线状态 
                    // (Check active status if it's not a LOGIN request and has a senderId)
                    if (!"LOGIN".equals(reqType) && senderId != null) {
                        if (!activeUsers.containsKey(senderId)) {
                            // 账号不在池中，强制下线 (Account not in pool, force logout)
                            response.setSuccess(false);
                            response.setResponseMsg("FORCE_LOGOUT");
                            out.writeObject(response);
                            out.flush();
                            return; // 拦截请求，直接返回 (Intercept and return directly)
                        } else {
                            // 刷新活跃时间 (Refresh active heartbeat)
                            activeUsers.put(senderId, System.currentTimeMillis());
                        }
                    }

                    // ==========================================
                    // 业务分发逻辑 (Business Logic Routing)
                    // ==========================================
                    
                    // ★ 正常下线请求 (Normal logout request)
                    if ("LOGOUT".equals(reqType)) {
                        if (senderId != null) {
                            activeUsers.remove(senderId);
                            logger.info("【登出】一卡通号[" + senderId + "] 正常下线。");
                        }
                        response.setSuccess(true);
                    }
                    else if (handleLibraryRequest(request, response)) {
                        // 图书馆请求处理完毕
                    } else if (isCourseRequest(reqType)) {
                        vCampus.server.handler.CourseHandler courseHandler = new vCampus.server.handler.CourseHandler(socket, in, out);
                        courseHandler.handleRequest(request, response);
                    } 
                    // 学籍管理模块 (Student Registration Module)
                    else if (isStudentRequest(reqType)) {
                        response = new vCampus.server.handler.StudentHandler().handle(request);
                    } else if (isClazzRequest(reqType)) {
                        response = new vCampus.server.handler.ClazzHandler().handle(request);
                    } else if (isMajorRequest(reqType)) {
                        response = new vCampus.server.handler.MajorHandler().handle(request);
                    } else if (isDepartmentRequest(reqType)) {
                        response = new vCampus.server.handler.DepartmentHandler().handle(request);
                    }
                    // 宿舍管理模块 (Dormitory Management Module)
                    else if (isDormRequest(reqType)) {
                        DormHandler dormHandler = new DormHandler();
                        response = dormHandler.handle(request);
                    }
                    // 商店模块 (Shop Module)
                    else if (isShopRequest(reqType)) {
                        handleShopRequest(request, response);
                    } 
                    // 银行模块 (Bank Module)
                    else if (isBankRequest(reqType)) {
                        handleBankRequest(request, response);
                    }
                    // 处理发送验证码前的用户信息校验及获取邮箱
                    else if ("VERIFY_USER_INFO".equals(reqType)) {
                        Student inputStu = (Student) data;
                        UserDao userDao = new UserDao();
                        String email = userDao.verifyUserInfoAndGetEmail(inputStu.getSCard(), inputStu.getSphone());

                        if (email != null && !email.trim().isEmpty()) {
                            response.setSuccess(true);
                            response.setData(email); 
                            response.setResponseMsg("身份验证通过！验证码将发送至：" + email);
                        } else if (email != null) {
                            response.setSuccess(false);
                            response.setResponseMsg("身份验证通过，但未查找到绑定的邮箱信息，请联系管理员处理。");
                        } else {
                            response.setSuccess(false);
                            response.setResponseMsg("验证失败：您输入的一卡通号与手机号不匹配或账号不存在，请仔细核对。");
                        }
                    }
                    // 处理重置密码操作
                    else if ("RESET_PASSWORD".equals(reqType)) {
                        Student inputStu = (Student) data;
                        UserDao userDao = new UserDao();
                        boolean isSuccess = userDao.autoVerifyAndResetPassword(inputStu.getSCard(), inputStu.getSphone(), inputStu.getSpassword());
                        response.setSuccess(isSuccess);
                        response.setResponseMsg(isSuccess ? "密码修改成功！请妥善保管您的新密码。" : "密码修改失败：系统发生异常或身份校验已过期。");
                        
                        // ★ 如果修改成功，将该账号强制踢出在线池 (Force kick out if password is reset successfully)
                        if (isSuccess) {
                            activeUsers.remove(inputStu.getSCard());
                            logger.info("【安全事件】用户[" + inputStu.getSCard() + "] 修改了密码，已清除其登录会话状态。");
                        }
                    } 
                    // 处理登录操作 (LOGIN)
                    else if ("LOGIN".equals(reqType) || data instanceof Student) { // 兼容旧逻辑
                        Student inputStu = (Student) data;
                        
                        // ★ 互斥登录校验 (Mutual exclusion login check)
                        if (activeUsers.containsKey(inputStu.getSCard())) {
                            response.setData(null);
                            response.setSuccess(false);
                            response.setResponseMsg("该账号已在其他终端登录，不允许重复登录！");
                            logger.warning("【登录拦截】账号[" + inputStu.getSCard() + "] 尝试重复登录被拒绝。");
                        } else {
                            UserDao userDao = new UserDao();
                            Object dbUser = userDao.checkLogin(inputStu.getSCard(), inputStu.getSpassword());

                            if (dbUser != null) {
                                if (dbUser instanceof Admin) {
                                    LIBRARY_ADMIN_SERVICE.onAuthenticatedLogin((Admin) dbUser);
                                }
                                response.setData(dbUser);
                                response.setSuccess(true);
                                response.setResponseMsg("登录成功");
                                
                                // ★ 加入在线池并输出详细日志 (Add to active pool and log)
                                activeUsers.put(inputStu.getSCard(), System.currentTimeMillis());
                                logger.info("【系统登录】一卡通号[" + inputStu.getSCard() + "] 成功进入系统。");
                            } else {
                                response.setData(null);
                                response.setSuccess(false);
                                response.setResponseMsg("账号或密码错误");
                                logger.info("【登录失败】账号[" + inputStu.getSCard() + "] 尝试登录，密码错误。");
                            }
                        }
                    } else {
                        response.setSuccess(false);
                        response.setResponseMsg("无法识别的请求类型");
                    }
                } else {
                    response.setSuccess(false);
                    response.setResponseMsg("请求数据格式错误");
                }

                out.writeObject(response);
                out.flush();

            } catch (Exception e) {
                System.err.println("Communication interrupted: " + e.getMessage());
            }
        }
    }

    private static boolean isShopRequest(String type) {
        if (type == null)
            return false;
        switch (type) {
        case "GET_ALL_PRODUCTS":
        case "GET_SHOP_BALANCE":
        case "SUBMIT_ORDER":
        case "GET_ORDERS":
        case "ADD_PRODUCT":
        case "ADD_STOCK":
        case "DELETE_PRODUCT":
            return true;
        default:
            return false;
        }
    }

    private static void handleShopRequest(Message request, Message response) {
        String type = request.getType();
        response.setSuccess(true);
        try {
            if ("GET_ALL_PRODUCTS".equals(type)) {
                List<Product> products = SHOP_SERVICE.getAllProducts();
                response.setData(products);
                response.setResponseMsg("获取商品成功，共 " + products.size() + " 件");
            } else if ("GET_SHOP_BALANCE".equals(type)) {
                Map<String, Object> params = (Map<String, Object>) request.getData();
                String userId = (String) params.get("userId");
                String payMethod = (String) params.get("payMethod");
                double balance = SHOP_SERVICE.getBalance(userId, payMethod);
                boolean success = balance >= 0;
                response.setSuccess(success);
                response.setData(balance);
                response.setResponseMsg(success ? "获取余额成功" : "未查询到账户余额");
            } else if ("SUBMIT_ORDER".equals(type)) {
                Map<String, Object> params = (Map<String, Object>) request.getData();
                String userId = (String) params.get("userId");
                List<OrderItem> items = (List<OrderItem>) params.get("items");
                String payMethod = (String) params.get("payMethod");
                String bankPIN = (String) params.get("bankPIN");
                Order order;

                if (payMethod == null || payMethod.trim().isEmpty()) {
                    order = SHOP_SERVICE.submitOrder(userId, items);
                } else {
                    Object totalObj = params.get("totalAmount");
                    double totalAmount = totalObj instanceof Number ? ((Number) totalObj).doubleValue() : 0;
                    if ("BANK".equalsIgnoreCase(payMethod)) {
                        boolean pinCorrect = BANK_SERVICE.verifyPIN(userId, bankPIN);
                        if (!pinCorrect) {
                            response.setSuccess(false);
                            response.setData(null);
                            response.setResponseMsg("银行卡密码错误，请重新输入。");
                            return;
                        }
                    }
                    order = SHOP_SERVICE.submitOrderWithPayment(userId, items, payMethod, totalAmount, bankPIN);
                }
                boolean success = order != null;
                response.setSuccess(success);
                response.setData(order);
                response.setResponseMsg(success ? "下单成功！" : "下单失败（库存不足或余额不够）");
            } else if ("GET_ORDERS".equals(type)) {
                String userId = (String) request.getData();
                List<Order> orders = SHOP_SERVICE.getOrdersByUser(userId);
                response.setData(orders);
                response.setResponseMsg("获取订单成功，共 " + orders.size() + " 条");
            } else if ("ADD_PRODUCT".equals(type)) {
                Product product = (Product) request.getData();
                boolean success = SHOP_SERVICE.addProduct(product);
                response.setSuccess(success);
                response.setResponseMsg(success ? "商品上架成功！" : "上架失败，请检查输入");
            } else if ("ADD_STOCK".equals(type)) {
                Map<String, Object> params = (Map<String, Object>) request.getData();
                int productId = (int) params.get("productId");
                int amount = (int) params.get("amount");
                boolean success = SHOP_SERVICE.updateStock(productId, amount);
                response.setSuccess(success);
                response.setResponseMsg(success ? "库存增加成功！" : "增加库存失败");
            } else if ("DELETE_PRODUCT".equals(type)) {
                int productId = (int) request.getData();
                boolean success = SHOP_SERVICE.deleteProduct(productId);
                response.setSuccess(success);
                response.setResponseMsg(success ? "商品下架成功！" : "下架失败，可能商品不存在");
            } else {
                response.setSuccess(false);
                response.setResponseMsg("未知商店请求类型: " + type);
            }
        } catch (Exception e) {
            System.err.println("处理商店请求异常: " + e.getMessage());
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("服务器处理商店请求异常: " + e.getMessage());
        }
    }

    private static boolean isStudentRequest(String type) {
        if (type == null)
            return false;
        switch (type) {
        case MsgConst.QUERY_STUDENT_BY_SCARD:
        case MsgConst.QUERY_STUDENT_BY_CID:
        case MsgConst.QUERY_ALL_STUDENT:
        case MsgConst.ADD_STUDENT:
        case MsgConst.UPDATE_STUDENT:
        case MsgConst.DELETE_STUDENT:
        case MsgConst.LOCK_STUDENT:
        case MsgConst.UNLOCK_STUDENT:
        case MsgConst.ADMIN_IMPORT_STUDENT_EXCEL:
        case MsgConst.QUERY_PROGRAM_BY_MAJOR_AND_GRADE:
        case MsgConst.QUERY_COMPLETED_CREDIT: 
            return true;
        default:
            return false;
        }
    }
    
    private static boolean isDepartmentRequest(String type) {
        if (type == null) return false;
        switch (type) {
            case MsgConst.QUERY_ALL_DEPT:
            case MsgConst.QUERY_DEPT_BY_DEPTID:
            case MsgConst.ADD_DEPT:
            case MsgConst.UPDATE_DEPT:
            case MsgConst.DELETE_DEPT:
                return true;
            default:
                return false;
        }
    }

    private static boolean isMajorRequest(String type) {
        if (type == null) return false;
        switch (type) {
            case MsgConst.QUERY_MAJOR_BY_MAJORID:
            case MsgConst.QUERY_MAJOR_BY_DEPTID:
            case MsgConst.QUERY_ALL_MAJOR:
            case MsgConst.ADD_MAJOR:
            case MsgConst.UPDATE_MAJOR:
            case MsgConst.DELETE_MAJOR:
                return true;
            default:
                return false;
        }
    }

    private static boolean isClazzRequest(String type) {
        if (type == null) return false;
        switch (type) {
            case MsgConst.QUERY_CLAZZ_BY_CLAZZID:
            case MsgConst.QUERY_CLAZZ_BY_MAJORID:
            case MsgConst.QUERY_ALL_CLAZZ:
            case MsgConst.ADD_CLAZZ:
            case MsgConst.UPDATE_CLAZZ:
            case MsgConst.DELETE_CLAZZ:
                return true;
            default:
                return false;
        }
    }

    private static boolean isDormRequest(String type) {
        return type != null && type.startsWith("DORM_");
    }

    private static boolean isCourseRequest(String type) {
        if (type == null)
            return false;
        switch (type) {
        case MsgConst.GET_AVAILABLE_COURSES:
        case MsgConst.GET_SELECTED_COURSES:
        case MsgConst.SUBMIT_ALL_COURSES:
        case MsgConst.DROP_COURSE:
        case MsgConst.TEACHER_GET_MY_COURSES:
        case MsgConst.TEACHER_GET_STUDENTS:
        case MsgConst.TEACHER_GET_SCHEDULE:
        case MsgConst.TEACHER_ENTER_SCORE: 
        case MsgConst.TEACHER_BATCH_ENTER_SCORE: 
        case MsgConst.TEACHER_GET_STATS:
        case MsgConst.ADMIN_GET_ALL_COURSES:
        case MsgConst.ADMIN_ADD_COURSE:
        case MsgConst.ADMIN_UPDATE_COURSE:
        case MsgConst.ADMIN_DELETE_COURSE:
        case MsgConst.ADMIN_GET_COURSE_DETAIL:
        case MsgConst.ADMIN_HELP_SELECT:
        case MsgConst.ADMIN_HELP_DROP:
        case MsgConst.ADMIN_GET_SELECT_STATS:
        case MsgConst.ADMIN_GET_STUDENT_STATUS:
        case MsgConst.ADMIN_GET_SELECT_STATUS:
        case MsgConst.ADMIN_GET_SELECT_HISTORY:
        case MsgConst.ADMIN_GET_SEMESTERS:
        case MsgConst.ADMIN_QUERY_COURSE_BY_ID:
        case MsgConst.ADMIN_QUERY_TEACHER_BY_ID:
        case MsgConst.ADMIN_SEARCH_STUDENTS:
        case MsgConst.ADMIN_GET_AVAILABLE_FOR_STUDENT:
        case MsgConst.ADMIN_GET_ALL_ROUNDS:
        case MsgConst.ADMIN_ADD_ROUND:
        case MsgConst.ADMIN_CLOSE_ROUND:
        case MsgConst.ADMIN_OPEN_ROUND:
        case MsgConst.ADMIN_DELETE_ROUND:
        case MsgConst.GET_CURRENT_ROUND:
        case MsgConst.ADMIN_UPDATE_COURSE_AND_OFFERING:
        case MsgConst.ADMIN_DELETE_OFFERING:
        case MsgConst.TEACHER_GET_MY_SEMESTERS:
        case MsgConst.ADMIN_GET_ALL_PROGRAMS:
        case MsgConst.ADMIN_GET_PROGRAM_COURSES:
        case MsgConst.ADMIN_BATCH_ADD_COURSE:
        case MsgConst.ADMIN_GET_OFFERING_IDS:
        case MsgConst.ADMIN_EXPORT_OFFERING_TEMPLATE:
        case MsgConst.ADMIN_IMPORT_OFFERING_EXCEL:
        case MsgConst.ADMIN_CLONE_ROUND_OFFERINGS:
        case MsgConst.ADMIN_UPDATE_ROUND:
        case MsgConst.ADMIN_GET_COURSES_BY_IDS:
        case MsgConst.GET_RETAKE_COURSES_BY_ROUND:
        case MsgConst.GET_ALL_COURSES_BY_ROUND:
            return true;
        default:
            return false;
        }
    }

    private static boolean handleLibraryRequest(Message request, Message response) {
        String type = request.getType();
        Object data = request.getData();
        if (type == null) {
            return false;
        }

        switch (type) {
        case MsgConst.LIBRARY_ADMIN_QUERY_BORROWS:
        case MsgConst.LIBRARY_ADMIN_BORROW:
        case MsgConst.LIBRARY_ADMIN_RETURN:
            if (!requireData(data, LibraryAdminRequest.class, response, "管理员借阅请求"))
                return true;
            LibraryAdminRequest adminRequest = (LibraryAdminRequest) data;
            try {
                if (MsgConst.LIBRARY_ADMIN_QUERY_BORROWS.equals(type)) {
                    setSuccess(response, LIBRARY_ADMIN_SERVICE.search(adminRequest), "查询全部借阅记录成功");
                } else if (MsgConst.LIBRARY_ADMIN_BORROW.equals(type)) {
                    setResult(response, LIBRARY_ADMIN_SERVICE.borrow(adminRequest), "为用户借阅图书");
                } else {
                    setResult(response, LIBRARY_ADMIN_SERVICE.returnBook(adminRequest), "为用户归还图书");
                }
            } catch (java.sql.SQLException e) {
                response.setSuccess(false);
                response.setResponseMsg(e.getMessage());
            }
            return true;
        case MsgConst.QUERY_ALL_BOOKS:
            setSuccess(response, LIBRARY_SERVICE.getAllBooks(), "查询图书成功");
            return true;
        case MsgConst.SEARCH_BOOKS:
            if (!requireData(data, String.class, response, "检索关键字"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.searchBooks((String) data), "检索图书成功");
            return true;
        case MsgConst.ADD_BOOK:
            if (!requireData(data, Book.class, response, "图书信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.addBook((Book) data), "新增图书");
            return true;
        case MsgConst.UPDATE_BOOK:
            if (!requireData(data, Book.class, response, "图书信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.updateBook((Book) data), "修改图书");
            return true;
        case MsgConst.DELETE_BOOK:
            if (!requireData(data, String.class, response, "图书编号"))
                return true;
            setResult(response, LIBRARY_SERVICE.deleteBook((String) data), "删除图书");
            return true;
        case MsgConst.QUERY_BOOK_CATEGORIES:
            setSuccess(response, LIBRARY_SERVICE.getAllBookCategories(), "查询图书分类成功");
            return true;
        case MsgConst.ADD_BOOK_CATEGORY:
            if (!requireData(data, BookCategory.class, response, "分类信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.addBookCategory((BookCategory) data), "新增图书分类");
            return true;
        case MsgConst.UPDATE_BOOK_CATEGORY:
            if (!requireData(data, BookCategory.class, response, "分类信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.updateBookCategory((BookCategory) data), "修改图书分类");
            return true;
        case MsgConst.DELETE_BOOK_CATEGORY:
            if (!requireData(data, String.class, response, "分类编号"))
                return true;
            setResult(response, LIBRARY_SERVICE.deleteBookCategory((String) data), "删除图书分类");
            return true;
        case MsgConst.QUERY_BOOK_COPIES:
            if (!requireData(data, String.class, response, "图书编号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getBookCopies((String) data), "查询馆藏副本成功");
            return true;
        case MsgConst.ADD_BOOK_COPY:
            if (!requireData(data, BookCopy.class, response, "副本信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.addBookCopy((BookCopy) data), "新增馆藏副本");
            return true;
        case MsgConst.UPDATE_BOOK_COPY:
            if (!requireData(data, BookCopy.class, response, "副本信息"))
                return true;
            setResult(response, LIBRARY_SERVICE.updateBookCopy((BookCopy) data), "修改馆藏副本");
            return true;
        case MsgConst.DELETE_BOOK_COPY:
            if (!requireData(data, String.class, response, "副本编号"))
                return true;
            setResult(response, LIBRARY_SERVICE.deleteBookCopy((String) data), "删除馆藏副本");
            return true;
        case MsgConst.BORROW_BOOK:
            if (!requireData(data, BorrowRecord.class, response, "借阅信息"))
                return true;
            BorrowRecord borrowRecord = (BorrowRecord) data;
            boolean borrowed = LIBRARY_SERVICE.borrowBook(borrowRecord.getCopyId(), borrowRecord.getReaderId(),
                    borrowRecord.getBorrowDate(), borrowRecord.getDueDate());
            setLibraryResult(response, borrowed, "借阅图书");
            return true;
        case MsgConst.RETURN_BOOK:
            if (!requireData(data, BorrowRecord.class, response, "归还信息"))
                return true;
            BorrowRecord returnRecord = (BorrowRecord) data;
            boolean returned = LIBRARY_SERVICE.returnBook(returnRecord.getRecordId(), returnRecord.getReturnDate());
            setLibraryResult(response, returned, "归还图书");
            return true;
        case MsgConst.RETURN_DAMAGED_BOOK:
            if (!requireData(data, BorrowRecord.class, response, "损坏归还信息"))
                return true;
            BorrowRecord damagedReturnRecord = (BorrowRecord) data;
            boolean damagedReturned = LIBRARY_SERVICE.returnDamagedBook(damagedReturnRecord.getRecordId(),
                    damagedReturnRecord.getReturnDate());
            setLibraryResult(response, damagedReturned, "归还并登记损坏");
            return true;
        case MsgConst.RENEW_BOOK:
            if (!requireData(data, BorrowRecord.class, response, "续借信息"))
                return true;
            BorrowRecord renewRecord = (BorrowRecord) data;
            boolean renewed = LIBRARY_SERVICE.renewBook(renewRecord.getRecordId(), renewRecord.getDueDate());
            setLibraryResult(response, renewed, "续借图书");
            return true;
        case MsgConst.RESERVE_BOOK:
            if (!requireData(data, ReservationRecord.class, response, "预约信息"))
                return true;
            ReservationRecord reservation = (ReservationRecord) data;
            boolean reserved = LIBRARY_SERVICE.reserveBook(reservation.getBookId(), reservation.getReaderId(),
                    reservation.getReservationTime());
            setLibraryResult(response, reserved, "预约图书");
            return true;
        case MsgConst.CANCEL_RESERVATION:
            if (!requireData(data, String.class, response, "预约编号"))
                return true;
            setResult(response, LIBRARY_SERVICE.cancelReservation((String) data), "取消预约");
            return true;
        case MsgConst.QUERY_MY_RESERVATIONS:
            if (!requireData(data, String.class, response, "读者编号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getReservationsByReader((String) data), "查询预约记录成功");
            return true;
        case MsgConst.QUERY_RESERVATION_QUEUE:
            if (!requireData(data, String.class, response, "图书编号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getWaitingReservations((String) data), "查询预约队列成功");
            return true;
        case MsgConst.QUERY_MY_BORROW_RECORDS:
            if (!requireData(data, String.class, response, "读者编号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getBorrowRecordsByReader((String) data), "查询借阅记录成功");
            return true;
        case MsgConst.QUERY_LIBRARY_READER:
            if (!requireData(data, String.class, response, "读者编号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getLibraryReader((String) data), "查询读者成功");
            return true;
        case MsgConst.CHECK_BORROW_PERMISSION:
            if (!requireData(data, LibraryReader.class, response, "读者信息"))
                return true;
            LibraryReader reader = (LibraryReader) data;
            boolean canBorrow = LIBRARY_SERVICE.canBorrow(reader.getReaderId(), LocalDate.now());
            setResult(response, canBorrow, "检查借阅资格");
            return true;
        case MsgConst.SUBMIT_BOOK_RECOMMENDATION:
            if (!requireData(data, BookRecommendation.class, response, "荐书信息"))
                return true;
            boolean recommended = LIBRARY_SERVICE.submitBookRecommendation((BookRecommendation) data);
            setLibraryResult(response, recommended, "提交荐书");
            return true;
        case MsgConst.QUERY_MY_BOOK_RECOMMENDATIONS:
            if (!requireData(data, String.class, response, "教师一卡通号"))
                return true;
            setSuccess(response, LIBRARY_SERVICE.getRecommendationsByTeacherCardId((String) data), "查询荐书记录成功");
            return true;
        case MsgConst.QUERY_BOOK_PROCUREMENT_REFERENCES:
            setSuccess(response, LIBRARY_SERVICE.getProcurementReferences(), "查询荐书采购参考成功");
            return true;
        default:
            return false;
        }
    }

    private static boolean isBankRequest(String type) {
        if (type == null)
            return false;
        return type.startsWith("BANK_");
    }

    @SuppressWarnings("unchecked")
    private static void handleBankRequest(Message request, Message response) {
        String type = request.getType();
        Object data = request.getData();
        String senderId = request.getSenderId(); // ★ 获取操作人 ID 用于日志记录 (Get sender ID for logging)
        
        try {
            if ("BANK_GET_ACCOUNT".equals(type)) {
                BankAccount a = BANK_SERVICE.getAccount((String) data);
                response.setSuccess(a != null);
                response.setData(a);
                response.setResponseMsg(a == null ? "尚未开通银行卡" : "查询成功");
            } else if ("BANK_OPEN_ACCOUNT".equals(type)) {
                Map<String, Object> p = (Map<String, Object>) data;
                BankAccount a = BANK_SERVICE.openAccount((String) p.get("holderCard"), (String) p.get("holderName"),
                        (String) p.get("bankPIN"));
                response.setSuccess(a != null);
                response.setData(a);
                response.setResponseMsg(a == null ? "开户失败，账户可能已存在" : "开户成功");
                if (a != null) logger.info("【银行开户】用户[" + senderId + "] 成功开通银行账户。");
            } else if ("BANK_GET_TRANSACTIONS".equals(type)) {
                List<?> list = BANK_SERVICE.getTransactions((String) data);
                response.setSuccess(true);
                response.setData(list);
                response.setResponseMsg("流水查询成功");
            } else if ("BANK_DEPOSIT".equals(type) || "BANK_WITHDRAW".equals(type)
                    || "BANK_RECHARGE_CAMPUS".equals(type)) {
                Map<String, Object> p = (Map<String, Object>) data;
                String card = (String) p.get("holderCard");
                String bankPIN = (String) p.get("bankPIN");
                double amount = ((Number) p.get("amount")).doubleValue();
                BankAccount bankAccount = BANK_SERVICE.getAccount(card);
                if (bankAccount == null) {
                    response.setSuccess(false);
                    response.setResponseMsg("尚未开通银行卡");
                } else if (bankAccount.getStatus() != 1) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡账户已被冻结，暂时无法进行此操作。");
                } else if (!BANK_SERVICE.verifyPIN(card, bankPIN)) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡密码错误，请重新输入。");
                } else {
                    boolean ok;
                    if ("BANK_DEPOSIT".equals(type)) {
                        ok = BANK_SERVICE.deposit(card, amount, bankPIN);
                        if(ok) logger.info("【银行流水-存款】成功! 操作人[" + senderId + "] 存入 " + amount + " 元。");
                    } else if ("BANK_WITHDRAW".equals(type)) {
                        ok = BANK_SERVICE.withdraw(card, amount, bankPIN);
                        if(ok) logger.info("【银行流水-取款】成功! 操作人[" + senderId + "] 取出 " + amount + " 元。");
                    } else {
                        ok = BANK_SERVICE.rechargeCampus(card, amount, bankPIN);
                        if(ok) logger.info("【银行流水-一卡通充值】成功! 操作人[" + senderId + "] 充值 " + amount + " 元。");
                    }
                    response.setSuccess(ok);
                    response.setResponseMsg(ok ? "操作成功" : "操作失败，请检查账户状态和余额");
                }
            } else if ("BANK_DORM_PAYMENT".equals(type)) {
                Map<String, Object> p = (Map<String, Object>) data;
                String card = (String) p.get("holderCard");
                String bankPIN = (String) p.get("bankPIN");
                double amount = ((Number) p.get("amount")).doubleValue();
                int billId = ((Number) p.get("billId")).intValue();
                BankAccount bankAccount = BANK_SERVICE.getAccount(card);
                if (bankAccount == null) {
                    response.setSuccess(false);
                    response.setResponseMsg("尚未开通银行卡");
                } else if (bankAccount.getStatus() != 1) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡账户已被冻结，暂时无法进行此操作。");
                } else if (!BANK_SERVICE.verifyPIN(card, bankPIN)) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡密码错误，请重新输入。");
                } else {
                    boolean ok = BANK_SERVICE.payDorm(card, amount, bankPIN, billId);
                    response.setSuccess(ok);
                    response.setResponseMsg(ok ? "宿舍缴费成功" : "宿舍缴费失败，请检查银行卡余额和账户状态");
                    if (ok) logger.info("【银行流水-宿舍缴费】成功! 操作人[" + senderId + "] 支付 " + amount + " 元，账单ID: " + billId);
                }
            } else if ("BANK_TRANSFER".equals(type)) {
                Map<String, Object> p = (Map<String, Object>) data;
                String card = (String) p.get("holderCard");
                String bankPIN = (String) p.get("bankPIN");
                BankAccount bankAccount = BANK_SERVICE.getAccount(card);
                if (bankAccount == null) {
                    response.setSuccess(false);
                    response.setResponseMsg("尚未开通银行卡");
                } else if (bankAccount.getStatus() != 1) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡账户已被冻结，暂时无法进行此操作。");
                } else if (!BANK_SERVICE.verifyPIN(card, bankPIN)) {
                    response.setSuccess(false);
                    response.setResponseMsg("银行卡密码错误，请重新输入。");
                } else {
                    String targetCard = (String) p.get("targetBankCard");
                    double amount = ((Number) p.get("amount")).doubleValue();
                    boolean ok = BANK_SERVICE.transfer(card, targetCard, amount, bankPIN);
                    response.setSuccess(ok);
                    response.setResponseMsg(ok ? "转账成功" : "转账失败，请检查收款账户、余额或账户状态");
                    if (ok) logger.info("【银行流水-转账】成功! 操作人[" + senderId + "] 向账户[" + targetCard + "] 转账 " + amount + " 元。");
                }
            } else if ("BANK_ADMIN_GET_ACCOUNTS".equals(type)) {
                List<BankAccount> list = BANK_SERVICE.getAllAccounts((String) data);
                response.setSuccess(true);
                response.setData(list);
                response.setResponseMsg("账户查询成功");
            } else if ("BANK_ADMIN_FREEZE".equals(type) || "BANK_ADMIN_UNFREEZE".equals(type)) {
                Map<String, Object> p = (Map<String, Object>) data;
                int status = "BANK_ADMIN_UNFREEZE".equals(type) ? 1 : 0;
                String adminCard = (String) p.get("adminCard");
                String targetBankCardId = (String) p.get("bankCardId");
                boolean ok = BANK_SERVICE.setStatus(adminCard, targetBankCardId, status);
                response.setSuccess(ok);
                response.setResponseMsg(ok ? "账户状态更新成功" : "操作失败");
                if (ok) logger.info("【银行管理】管理员[" + adminCard + "] " + (status == 1 ? "解冻" : "冻结") + "了账户: " + targetBankCardId);
            } else {
                response.setSuccess(false);
                response.setResponseMsg("未知银行请求：" + type);
            }
        } catch (Exception e) {
            response.setSuccess(false);
            response.setResponseMsg("银行模块处理异常：" + e.getMessage());
            logger.warning("【银行模块异常】" + e.getMessage());
        }
    }

    private static boolean requireData(Object data, Class<?> expectedType, Message response, String dataName) {
        if (!expectedType.isInstance(data)) {
            response.setSuccess(false);
            response.setResponseMsg(dataName + "格式错误");
            return false;
        }
        return true;
    }

    private static void setSuccess(Message response, Object data, String message) {
        response.setData(data);
        response.setSuccess(true);
        response.setResponseMsg(message);
    }

    private static void setResult(Message response, boolean success, String operation) {
        response.setSuccess(success);
        response.setResponseMsg(success ? operation + "成功" : operation + "失败，请检查输入或当前状态");
    }

    private static void setLibraryResult(Message response, boolean success, String operation) {
        response.setSuccess(success);
        if (success) {
            response.setResponseMsg(operation + "成功");
            return;
        }
        String reason = LIBRARY_SERVICE.takeFailureReason();
        response.setResponseMsg(reason == null || reason.trim().isEmpty() ? operation + "失败，请检查输入或当前状态" : reason);
    }
}