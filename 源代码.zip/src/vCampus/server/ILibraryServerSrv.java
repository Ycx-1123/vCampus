package vCampus.server;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import vCampus.common.vo.Book;
import vCampus.common.vo.BookCategory;
import vCampus.common.vo.BookCopy;
import vCampus.common.vo.BookRecommendation;
import vCampus.common.vo.BorrowRecord;
import vCampus.common.vo.LibraryReader;
import vCampus.common.vo.ReservationRecord;

/**
 * 图书馆模块服务契约。具体实现由服务端调用 DAO 完成。
 */
public interface ILibraryServerSrv {
    List<Book> getAllBooks();

    List<Book> searchBooks(String keyword);

    Book findBookById(String bookId);

    boolean addBook(Book book);

    boolean updateBook(Book book);

    boolean deleteBook(String bookId);

    List<BookCategory> getAllBookCategories();

    boolean addBookCategory(BookCategory category);

    boolean updateBookCategory(BookCategory category);

    boolean deleteBookCategory(String categoryId);

    List<BookCopy> getBookCopies(String bookId);

    boolean addBookCopy(BookCopy copy);

    boolean updateBookCopy(BookCopy copy);

    boolean deleteBookCopy(String copyId);

    /** 借阅对象为实体副本；服务端需同时检查禁借状态和该书目的预约队列。 */
    boolean borrowBook(String copyId, String readerId, LocalDate borrowDate, LocalDate dueDate);

    boolean returnBook(String recordId, LocalDate returnDate);

    /** 同一书目存在等待预约时，本方法必须拒绝续借。 */
    boolean renewBook(String recordId, LocalDate newDueDate);

    boolean reserveBook(String bookId, String readerId, LocalDateTime reservationTime);

    boolean cancelReservation(String reservationId);

    List<ReservationRecord> getReservationsByReader(String readerId);

    List<ReservationRecord> getWaitingReservations(String bookId);

    LibraryReader getLibraryReader(String readerId);

    boolean canBorrow(String readerId, LocalDate borrowDate);

    List<BorrowRecord> getBorrowRecordsByReader(String readerId);

    List<BorrowRecord> getActiveBorrowRecords();

    /** 只有教师可提交荐书；采购参考按教师荐书 70% 与有效预约需求 30% 计算。 */
    boolean submitBookRecommendation(BookRecommendation recommendation);

    List<BookRecommendation> getRecommendationsByTeacherCardId(String teacherCardId);

    List<BookRecommendation> getProcurementReferences();
}
