package vCampus.server.handler;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.vo.Department;
import vCampus.server.service.DepartmentService;

import java.util.List;

public class DepartmentHandler {

    private DepartmentService deptService = new DepartmentService();

    public Message handle(Message msg) {
        Message resp = new Message();
        String type = msg.getType();

        try {
            switch (type) {
                case MsgConst.QUERY_ALL_DEPT:
                    List<Department> list = deptService.findAllDepartment();
                    resp.setSuccess(true);
                    resp.setData(list);
                    resp.setResponseMsg("查询全部院系成功");
                    break;
                    
                case MsgConst.QUERY_DEPT_BY_DEPTID:
                	String cid = (String) msg.getData();
                    Department oneDept = deptService.findDepartmentById(cid);
                    resp.setSuccess(true);
                    resp.setData(oneDept);
                    resp.setResponseMsg(oneDept != null ? "查询院系成功" : "未找到该院系");
                    break;

                case MsgConst.ADD_DEPT:
                    Department addDept = (Department) msg.getData();
                    boolean addOk = deptService.addDepartment(addDept);
                    resp.setSuccess(addOk);
                    if(addOk){
                        resp.setResponseMsg("添加院系成功");
                    }else{
                        resp.setResponseMsg("添加失败：该院系编号已存在");
                    }
                    break;

                case MsgConst.UPDATE_DEPT:
                    Department updateDept = (Department) msg.getData();
                    boolean updateOk = deptService.updateDepartment(updateDept);
                    resp.setSuccess(updateOk);
                    resp.setResponseMsg(updateOk ? "修改院系成功" : "修改院系失败");
                    break;

                case MsgConst.DELETE_DEPT:
                    String deptId = (String) msg.getData();
                    boolean delOk = deptService.deleteDepartment(deptId);
                    resp.setSuccess(delOk);
                    if(delOk){
                        resp.setResponseMsg("删除院系成功");
                    }else{
                        resp.setResponseMsg("删除失败：院系下存在专业，禁止删除");
                    }
                    break;

                default:
                    resp.setSuccess(false);
                    resp.setResponseMsg("DepartmentHandler：未知指令");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.setSuccess(false);
            resp.setResponseMsg("院系服务异常："+e.getMessage());
        }
        return resp;
    }
}
