package vCampus.server.handler;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.vo.Major;
import vCampus.server.service.MajorService;

import java.util.List;

public class MajorHandler {

    private MajorService majorService = new MajorService();

    public Message handle(Message msg) {
        Message resp = new Message();
        String type = msg.getType();

        try {
            switch (type) {
                case MsgConst.QUERY_ALL_MAJOR:
                    List<Major> majorList = majorService.findAllMajor();
                    resp.setSuccess(true);
                    resp.setData(majorList);
                    resp.setResponseMsg("查询全部专业成功");
                    break;

                case MsgConst.QUERY_MAJOR_BY_MAJORID:
                    String mid = (String) msg.getData();
                    Major oneMajor = majorService.findMajorById(mid);
                    resp.setSuccess(true);
                    resp.setData(oneMajor);
                    resp.setResponseMsg(oneMajor != null ? "查询专业成功" : "未找到该专业");
                    break;

                case MsgConst.QUERY_MAJOR_BY_DEPTID:
                    String deptId = (String) msg.getData();
                    List<Major> majorUnderDept = majorService.findMajorByDeptId(deptId);
                    resp.setSuccess(true);
                    resp.setData(majorUnderDept);
                    resp.setResponseMsg("根据院系编号查询专业成功");
                    break;

                case MsgConst.ADD_MAJOR:
                    Major addMajor = (Major) msg.getData();
                    boolean addOk = majorService.addMajor(addMajor);
                    resp.setSuccess(addOk);
                    if (addOk) {
                        resp.setResponseMsg("添加专业成功");
                    } else {
                        resp.setResponseMsg("添加失败：专业编号已存在，或所属院系不存在");
                    }
                    break;

                case MsgConst.UPDATE_MAJOR:
                    Major updateMajor = (Major) msg.getData();
                    boolean updateOk = majorService.updateMajor(updateMajor);
                    resp.setSuccess(updateOk);
                    if (updateOk) {
                        resp.setResponseMsg("修改专业成功");
                    } else {
                        resp.setResponseMsg("修改失败：所属院系不存在");
                    }
                    break;

                case MsgConst.DELETE_MAJOR:
                    String majorId = (String) msg.getData();
                    boolean delOk = majorService.deleteMajor(majorId);
                    resp.setSuccess(delOk);
                    if (delOk) {
                        resp.setResponseMsg("删除专业成功");
                    } else {
                        resp.setResponseMsg("删除失败：该专业下还有班级，禁止删除");
                    }
                    break;

                default:
                    resp.setSuccess(false);
                    resp.setResponseMsg("MajorHandler：未知指令");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.setSuccess(false);
            resp.setResponseMsg("专业服务异常：" + e.getMessage());
        }
        return resp;
    }
}
