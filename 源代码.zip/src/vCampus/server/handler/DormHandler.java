package vCampus.server.handler;

import java.util.Date;
import java.util.List;
import java.util.Map;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.enums.ApplicationType;
import vCampus.common.enums.PaymentMethod;
import vCampus.common.enums.RepairStatus;
import vCampus.common.vo.Accommodation;
import vCampus.common.vo.AccommodationImportRow;
import vCampus.common.vo.DormFeeBill;
import vCampus.common.vo.DormRepair;
import vCampus.common.vo.Dormitory;
import vCampus.server.service.AdminAccommodationService;
import vCampus.server.service.AdminAccommodationServiceImpl;
import vCampus.server.service.AdminApplicationService;
import vCampus.server.service.AdminApplicationServiceImpl;
import vCampus.server.service.AdminDormitoryService;
import vCampus.server.service.AdminDormitoryServiceImpl;
import vCampus.server.service.AdminFeeService;
import vCampus.server.service.AdminFeeServiceImpl;
import vCampus.server.service.AdminRepairService;
import vCampus.server.service.AdminRepairServiceImpl;
import vCampus.server.service.StudentApplicationService;
import vCampus.server.service.StudentApplicationServiceImpl;
import vCampus.server.service.StudentDormService;
import vCampus.server.service.StudentDormServiceImpl;
import vCampus.server.service.StudentPaymentService;
import vCampus.server.service.StudentPaymentServiceImpl;
import vCampus.server.service.StudentRepairService;
import vCampus.server.service.StudentRepairServiceImpl;

public class DormHandler {

    private StudentDormService studentDormService;
    private StudentApplicationService studentApplicationService;
    private StudentRepairService studentRepairService;
    private StudentPaymentService studentPaymentService;

    private AdminDormitoryService adminDormitoryService;
    private AdminAccommodationService adminAccommodationService;
    private AdminApplicationService adminApplicationService;
    private AdminRepairService adminRepairService;
    private AdminFeeService adminFeeService;


    public DormHandler() {

        studentDormService =
                new StudentDormServiceImpl();

        studentApplicationService =
                new StudentApplicationServiceImpl();

        studentRepairService =
                new StudentRepairServiceImpl();

        studentPaymentService =
                new StudentPaymentServiceImpl();


        adminDormitoryService =
                new AdminDormitoryServiceImpl();

        adminAccommodationService =
                new AdminAccommodationServiceImpl();

        adminApplicationService =
                new AdminApplicationServiceImpl();

        adminRepairService =
                new AdminRepairServiceImpl();

        adminFeeService =
                new AdminFeeServiceImpl();
    }


    public Message handle(Message msg) {

        Message resp = new Message();

        if (msg == null || msg.getType() == null) {

            resp.setSuccess(false);
            resp.setResponseMsg("宿舍请求不能为空");

            return resp;
        }


        String type = msg.getType();

        resp.setType(type);


        try {

            switch (type) {

            // =================================================
            // 学生端：宿舍查询
            // =================================================

            case MsgConst.DORM_QUERY_ALL:

                ok(
                    resp,
                    studentDormService.queryAllDorm(),
                    "查询全部宿舍成功"
                );

                break;


            case MsgConst.DORM_QUERY_AVAILABLE:

                ok(
                    resp,
                    studentDormService.queryAvailableDorm(),
                    "查询可用宿舍成功"
                );

                break;


            case MsgConst.DORM_QUERY_MY: {

                String sId =
                        str(msg.getData());

                Accommodation acc =
                        studentDormService.queryMyDorm(sId);

                resp.setSuccess(
                        acc != null
                );

                resp.setData(acc);

                resp.setResponseMsg(
                        acc != null
                        ? "查询住宿成功"
                        : "当前没有住宿记录"
                );

                break;
            }


            case MsgConst.DORM_QUERY_REMAINING_BEDS: {

                int remaining =
                        studentDormService.getRemainingBeds(
                                str(msg.getData())
                        );

                resp.setSuccess(
                        remaining >= 0
                );

                resp.setData(remaining);

                resp.setResponseMsg(
                        remaining >= 0
                        ? "查询剩余床位成功"
                        : "宿舍不存在"
                );

                break;
            }


            case MsgConst.DORM_QUERY_AVAILABLE_BEDS: {

                List<String> beds =
                        studentDormService.queryAvailableBeds(
                                str(msg.getData())
                        );

                ok(
                    resp,
                    beds,
                    "查询可用床位成功"
                );

                break;
            }


            // =================================================
            // 学生端：调宿/退宿申请
            // =================================================

            case MsgConst.DORM_APPLY_CHANGE: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        studentApplicationService.applyDormChange(
                                str(p.get("sId")),
                                str(p.get("targetDormId")),
                                str(p.get("targetBedNumber")),
                                str(p.get("reason"))
                        );

                bool(
                    resp,
                    result,
                    "调宿申请提交成功",
                    "调宿申请提交失败"
                );

                break;
            }


            case MsgConst.DORM_APPLY_CHECKOUT: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        studentApplicationService.applyCheckout(
                                str(p.get("sId")),
                                (ApplicationType)
                                        p.get("applicationType"),
                                str(p.get("reason"))
                        );

                bool(
                    resp,
                    result,
                    "退宿申请提交成功",
                    "退宿申请提交失败"
                );

                break;
            }


            case MsgConst.DORM_QUERY_MY_APPLICATIONS:

                ok(
                    resp,
                    studentApplicationService
                            .queryMyApplications(
                                    str(msg.getData())
                            ),
                    "查询申请成功"
                );

                break;


            case MsgConst.DORM_CANCEL_APPLICATION: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        studentApplicationService
                                .cancelApplication(
                                        str(p.get("sId")),
                                        integer(
                                                p.get(
                                                    "applicationId"
                                                )
                                        )
                                );

                bool(
                    resp,
                    result,
                    "申请取消成功",
                    "申请取消失败"
                );

                break;
            }


            // =================================================
            // 学生端：报修
            // =================================================

            case MsgConst.DORM_SUBMIT_REPAIR: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        studentRepairService.submitRepair(
                                str(p.get("sId")),
                                str(p.get("dormId")),
                                str(p.get("description"))
                        );

                bool(
                    resp,
                    result,
                    "报修提交成功",
                    "报修提交失败"
                );

                break;
            }


            case MsgConst.DORM_QUERY_MY_REPAIRS:

                ok(
                    resp,
                    studentRepairService.queryMyRepairs(
                            str(msg.getData())
                    ),
                    "查询报修记录成功"
                );

                break;


            case MsgConst.DORM_CANCEL_REPAIR: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        studentRepairService.cancelRepair(
                                str(p.get("sId")),
                                integer(
                                    p.get("repairId")
                                )
                        );

                bool(
                    resp,
                    result,
                    "报修取消成功",
                    "报修取消失败"
                );

                break;
            }


            // =================================================
            // 学生端：住宿费
            // =================================================

            case MsgConst.DORM_QUERY_MY_BILLS:

                ok(
                    resp,
                    studentPaymentService.queryMyBills(
                            str(msg.getData())
                    ),
                    "查询住宿费账单成功"
                );

                break;


            case MsgConst.DORM_QUERY_UNPAID_BILLS:

                ok(
                    resp,
                    studentPaymentService.queryUnpaidBills(
                            str(msg.getData())
                    ),
                    "查询未缴账单成功"
                );

                break;


            case MsgConst.DORM_PAY_BILL: {

                Map<String, Object> p =
                        map(msg.getData());

                String result =
                        studentPaymentService.payBill(
                                str(p.get("sId")),
                                integer(p.get("billId")),
                                decimal(p.get("amount")),
                                (PaymentMethod)
                                        p.get("paymentMethod"),
                                str(p.get("bankPIN"))
                        );

                resp.setSuccess(
                        "缴费成功".equals(result)
                );

                resp.setData(result);

                resp.setResponseMsg(result);

                break;
            }


            case MsgConst.DORM_QUERY_PAYMENT_HISTORY:

                ok(
                    resp,
                    studentPaymentService
                            .queryPaymentHistory(
                                    str(msg.getData())
                            ),
                    "查询缴费历史成功"
                );

                break;


            // =================================================
            // 管理员端：宿舍管理
            // =================================================

            case MsgConst.DORM_ADMIN_QUERY_ALL:

                ok(
                    resp,
                    adminDormitoryService.queryAllDorm(),
                    "查询全部宿舍成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_AVAILABLE:

                ok(
                    resp,
                    adminDormitoryService.queryAvailableDorm(),
                    "查询可用宿舍成功"
                );

                break;


            case MsgConst.DORM_ADMIN_ADD: {

                boolean result =
                        adminDormitoryService.addDorm(
                                (Dormitory)
                                    msg.getData()
                        );

                bool(
                    resp,
                    result,
                    "新增宿舍成功",
                    "新增宿舍失败"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_UPDATE: {

                boolean result =
                        adminDormitoryService.updateDorm(
                                (Dormitory)
                                    msg.getData()
                        );

                bool(
                    resp,
                    result,
                    "修改宿舍成功",
                    "修改宿舍失败"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_DELETE: {

                boolean result =
                        adminDormitoryService.deleteDorm(
                                str(msg.getData())
                        );

                bool(
                    resp,
                    result,
                    "删除宿舍成功",
                    "删除宿舍失败"
                );

                break;
            }


            // =================================================
            // 管理员端：入住 / 批量入住 / 退宿 / 调宿
            // =================================================

            case MsgConst.DORM_ADMIN_CHECK_IN: {

                Map<String, Object> p =
                        map(msg.getData());

                String result =
                        adminAccommodationService.checkIn(
                                str(p.get("sId")),
                                str(p.get("dormId")),
                                str(p.get("bedNumber"))
                        );

                textResult(
                        resp,
                        result
                );

                break;
            }


            case MsgConst.DORM_ADMIN_BATCH_CHECK_IN: {

                Map<String, Object> p =
                        map(msg.getData());

                @SuppressWarnings("unchecked")
                List<AccommodationImportRow> rows =
                        (List<AccommodationImportRow>)
                                p.get("rows");

                String academicYear =
                        str(p.get("academicYear"));

                String semester =
                        str(p.get("semester"));

                Date dueDate =
                        (Date) p.get("dueDate");


                String result =
                        adminAccommodationService.batchCheckIn(
                                rows,
                                academicYear,
                                semester,
                                dueDate
                        );


                resp.setSuccess(
                        result != null
                        && result.startsWith(
                                "批量导入完成"
                        )
                );

                resp.setData(result);

                resp.setResponseMsg(result);

                break;
            }


            case MsgConst.DORM_ADMIN_CHECK_OUT: {

                String result =
                        adminAccommodationService
                                .executeCheckOut(
                                        str(msg.getData())
                                );

                textResult(
                        resp,
                        result
                );

                break;
            }


            case MsgConst.DORM_ADMIN_CHANGE: {

                Map<String, Object> p =
                        map(msg.getData());

                String result =
                        adminAccommodationService
                                .executeDormChange(
                                        str(p.get("sId")),
                                        str(p.get("newDormId")),
                                        str(
                                            p.get(
                                                "newBedNumber"
                                            )
                                        )
                                );

                textResult(
                        resp,
                        result
                );

                break;
            }


            case MsgConst.DORM_ADMIN_QUERY_STUDENT: {

                Accommodation acc =
                        adminAccommodationService
                                .queryStudentDorm(
                                        str(msg.getData())
                                );

                resp.setSuccess(
                        acc != null
                );

                resp.setData(acc);

                resp.setResponseMsg(
                        acc != null
                        ? "查询学生住宿成功"
                        : "未找到住宿记录"
                );

                break;
            }


            case MsgConst.DORM_QUERY_HISTORY: {

                String sId =
                        str(msg.getData());

                ok(
                    resp,
                    adminAccommodationService
                            .queryHistory(sId),
                    "查询住宿历史成功"
                );

                break;
            }


            // =================================================
            // 管理员端：申请审核
            // =================================================

            case MsgConst.DORM_ADMIN_QUERY_PENDING_APPLICATIONS:

                ok(
                    resp,
                    adminApplicationService
                            .queryPendingApplications(),
                    "查询待审核申请成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_APPLICATIONS_BY_TYPE:

                ok(
                    resp,
                    adminApplicationService
                            .queryApplicationsByType(
                                (ApplicationType)
                                    msg.getData()
                            ),
                    "查询申请成功"
                );

                break;


            case MsgConst.DORM_ADMIN_APPROVE_APPLICATION: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        adminApplicationService
                                .approveApplication(
                                    integer(
                                        p.get("applicationId")
                                    ),
                                    str(
                                        p.get("adminId")
                                    ),
                                    nullableString(
                                        p.get("remark")
                                    )
                                );

                bool(
                    resp,
                    result,
                    "申请审核通过",
                    "申请审核失败"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_REJECT_APPLICATION: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        adminApplicationService
                                .rejectApplication(
                                    integer(
                                        p.get("applicationId")
                                    ),
                                    str(
                                        p.get("adminId")
                                    ),
                                    nullableString(
                                        p.get("remark")
                                    )
                                );

                bool(
                    resp,
                    result,
                    "申请已拒绝",
                    "申请拒绝失败"
                );

                break;
            }


            // =================================================
            // 管理员端：报修管理
            // =================================================

            case MsgConst.DORM_ADMIN_QUERY_ALL_REPAIRS:

                ok(
                    resp,
                    adminRepairService.queryAllRepairs(),
                    "查询全部报修成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_REPAIR_BY_ID: {

                DormRepair repair =
                        adminRepairService.queryRepairById(
                                integer(msg.getData())
                        );

                resp.setSuccess(
                        repair != null
                );

                resp.setData(repair);

                resp.setResponseMsg(
                        repair != null
                        ? "查询报修成功"
                        : "报修记录不存在"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_UPDATE_REPAIR_STATUS: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        adminRepairService
                                .updateRepairStatus(
                                    integer(
                                        p.get("repairId")
                                    ),
                                    (RepairStatus)
                                        p.get("status")
                                );

                bool(
                    resp,
                    result,
                    "报修状态修改成功",
                    "报修状态修改失败"
                );

                break;
            }


            // =================================================
            // 管理员端：费用管理
            // =================================================

            case MsgConst.DORM_ADMIN_CREATE_BILL: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        adminFeeService.createBill(
                                str(p.get("sId")),
                                integer(
                                    p.get("accommodationId")
                                ),
                                str(p.get("academicYear")),
                                str(p.get("semester")),
                                decimal(p.get("amount")),
                                (Date) p.get("dueDate")
                        );

                bool(
                    resp,
                    result,
                    "账单创建成功",
                    "账单创建失败"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_BATCH_CREATE_BILLS: {

                @SuppressWarnings("unchecked")
                List<DormFeeBill> bills =
                        (List<DormFeeBill>)
                            msg.getData();

                int count =
                        adminFeeService
                                .batchCreateBills(bills);

                resp.setSuccess(
                        count > 0
                );

                resp.setData(count);

                resp.setResponseMsg(
                        "成功创建"
                        + count
                        + "张账单"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_QUERY_ALL_BILLS:

                ok(
                    resp,
                    adminFeeService.queryAllBills(),
                    "查询全部账单成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_STUDENT_BILLS:

                ok(
                    resp,
                    adminFeeService.queryStudentBills(
                            str(msg.getData())
                    ),
                    "查询学生账单成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_UNPAID_BILLS:

                ok(
                    resp,
                    adminFeeService.queryUnpaidBills(),
                    "查询未缴账单成功"
                );

                break;


            case MsgConst.DORM_ADMIN_QUERY_BILL_BY_ID: {

                DormFeeBill bill =
                        adminFeeService.queryBillById(
                                integer(msg.getData())
                        );

                resp.setSuccess(
                        bill != null
                );

                resp.setData(bill);

                resp.setResponseMsg(
                        bill != null
                        ? "查询账单成功"
                        : "账单不存在"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_ADJUST_BILL: {

                Map<String, Object> p =
                        map(msg.getData());

                boolean result =
                        adminFeeService.adjustBill(
                                integer(p.get("billId")),
                                decimal(p.get("amount"))
                        );

                bool(
                    resp,
                    result,
                    "账单金额调整成功",
                    "账单金额调整失败"
                );

                break;
            }


            case MsgConst.DORM_ADMIN_CANCEL_BILL: {

                boolean result =
                        adminFeeService.cancelBill(
                                integer(msg.getData())
                        );

                bool(
                    resp,
                    result,
                    "账单取消成功",
                    "账单取消失败"
                );

                break;
            }


            default:

                resp.setSuccess(false);

                resp.setResponseMsg(
                        "DormHandler：未知请求类型"
                );

                break;
            }


        } catch (Exception e) {

            e.printStackTrace();

            resp.setSuccess(false);

            resp.setResponseMsg(
                    "宿舍服务异常："
                    + e.getMessage()
            );
        }


        return resp;
    }


    // =============================================================
    // 响应辅助
    // =============================================================

    private void ok(
            Message resp,
            Object data,
            String message) {

        resp.setSuccess(true);

        resp.setData(data);

        resp.setResponseMsg(message);
    }


    private void bool(
            Message resp,
            boolean result,
            String successMsg,
            String failMsg) {

        resp.setSuccess(result);

        resp.setResponseMsg(
                result
                ? successMsg
                : failMsg
        );
    }


    private void textResult(
            Message resp,
            String result) {

        resp.setSuccess(
                result != null
                && result.contains("成功")
        );

        resp.setData(result);

        resp.setResponseMsg(result);
    }


    // =============================================================
    // 参数解析辅助
    // =============================================================

    @SuppressWarnings("unchecked")
    private Map<String, Object> map(
            Object value) {

        if (!(value instanceof Map)) {

            throw new IllegalArgumentException(
                    "请求参数格式错误"
            );
        }

        return (Map<String, Object>) value;
    }


    private String str(
            Object value) {

        if (!(value instanceof String)) {

            throw new IllegalArgumentException(
                    "字符串参数格式错误"
            );
        }

        return ((String) value).trim();
    }


    private String nullableString(
            Object value) {

        if (value == null) {

            return null;
        }

        return str(value);
    }


    private int integer(
            Object value) {

        if (!(value instanceof Number)) {

            throw new IllegalArgumentException(
                    "整数参数格式错误"
            );
        }

        return ((Number) value).intValue();
    }


    private double decimal(
            Object value) {

        if (!(value instanceof Number)) {

            throw new IllegalArgumentException(
                    "金额参数格式错误"
            );
        }

        return ((Number) value).doubleValue();
    }
}