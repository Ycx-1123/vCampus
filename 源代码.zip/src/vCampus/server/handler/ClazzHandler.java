package vCampus.server.handler;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.vo.Clazz;
import vCampus.server.service.ClazzService;

import java.util.List;

public class ClazzHandler {

    private ClazzService clazzService = new ClazzService();

    public Message handle(Message msg) {
        Message resp = new Message();
        String type = msg.getType();

        try {
            switch (type) {
                case MsgConst.QUERY_CLAZZ_BY_CLAZZID:
                    String cid = (String) msg.getData();
                    Clazz oneClazz = clazzService.findClazzById(cid);
                    resp.setSuccess(true);
                    resp.setData(oneClazz);
                    resp.setResponseMsg(oneClazz != null ? "查询班级成功" : "未找到该班级");
                    break;

                case MsgConst.QUERY_CLAZZ_BY_MAJORID:
                    String majorId = (String) msg.getData();
                    List<Clazz> clazzList = clazzService.findClazzByMajorId(majorId);
                    resp.setSuccess(true);
                    resp.setData(clazzList);
                    resp.setResponseMsg("根据专业编号查询班级成功");
                    break;
                    
                case MsgConst.QUERY_ALL_CLAZZ:
                	List<Clazz> list = clazzService.findAllClazz();
                    resp.setSuccess(true);
                    resp.setData(list);
                    resp.setResponseMsg("查询全部专业成功");
                    break;

                case MsgConst.ADD_CLAZZ:
                    Clazz addClazz = (Clazz) msg.getData();
                    boolean addOk = clazzService.addClazz(addClazz);
                    resp.setSuccess(addOk);
                    if (addOk) {
                        resp.setResponseMsg("添加班级成功");
                    } else {
                        resp.setResponseMsg("添加失败：班级编号已存在，或所属专业不存在");
                    }
                    break;

                case MsgConst.UPDATE_CLAZZ:
                    Clazz updateClazz = (Clazz) msg.getData();
                    boolean updateOk = clazzService.updateClazz(updateClazz);
                    resp.setSuccess(updateOk);
                    if (updateOk) {
                        resp.setResponseMsg("修改班级成功");
                    } else {
                        resp.setResponseMsg("修改失败：所属专业不存在");
                    }
                    break;

                case MsgConst.DELETE_CLAZZ:
                    String clazzId = (String) msg.getData();
                    boolean delOk = clazzService.deleteClazz(clazzId);
                    resp.setSuccess(delOk);
                    if (delOk) {
                        resp.setResponseMsg("删除班级成功");
                    } else {
                        resp.setResponseMsg("删除失败：班级下还有学生，禁止删除");
                    }
                    break;

                default:
                    resp.setSuccess(false);
                    resp.setResponseMsg("ClazzHandler：未知指令");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.setSuccess(false);
            resp.setResponseMsg("班级服务异常：" + e.getMessage());
        }
        return resp;
    }
}
