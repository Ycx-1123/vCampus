package vCampus.server.handler;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.vo.*;
import vCampus.server.service.StudentSelectService;
import vCampus.server.service.TeacherCourseService;
import vCampus.server.service.AdminCourseService;
import vCampus.server.service.AdminSelectService;
import vCampus.server.service.AdminRoundService;
//zhishiweileshangchuan
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 课程相关请求处理器
 * 负责：学生选课、教师课程管理、管理员课程管理
 */
public class CourseHandler {

    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    // ========== Service 实例 ==========
    private StudentSelectService studentService = new StudentSelectService();
    private TeacherCourseService teacherService = new TeacherCourseService();
    private AdminCourseService adminCourseService = new AdminCourseService();   // 课程 + 开课 + Excel
    private AdminSelectService adminSelectService = new AdminSelectService();   // 选课
    private AdminRoundService adminRoundService = new AdminRoundService();      // 轮次 + 培养方案

    private String currentUserId;
    private String currentUserRole;

    public CourseHandler(Socket socket, ObjectInputStream in, ObjectOutputStream out) {
        this.socket = socket;
        this.in = in;
        this.out = out;
    }

    public void handleRequest(Message request, Message response) throws Exception {
    	String type = request.getType();
        System.out.println("[CourseHandler] 处理请求: " + type);

        // ============================================================
        // 一、学生端 - 选课
        // ============================================================
        if (MsgConst.GET_AVAILABLE_COURSES.equals(type)) {
            handleGetAvailableCourses(request, response);
        } else if (MsgConst.GET_SELECTED_COURSES.equals(type)) {
            handleGetSelectedCourses(request, response);
        } else if (MsgConst.SUBMIT_ALL_COURSES.equals(type)) {
            handleSubmitAllCourses(request, response);
        } else if (MsgConst.DROP_COURSE.equals(type)) {
            handleDropCourse(request, response);
        

        // ============================================================
        // 二、教师端 - 课程管理
        // ============================================================
        } else if (MsgConst.TEACHER_GET_MY_COURSES.equals(type)) {
            handleTeacherGetMyCourses(request, response);
        } else if (MsgConst.TEACHER_GET_STUDENTS.equals(type)) {
            handleTeacherGetStudents(request, response);
        } else if (MsgConst.TEACHER_GET_SCHEDULE.equals(type)) {
            handleTeacherGetSchedule(request, response);
        } else if (MsgConst.TEACHER_ENTER_SCORE.equals(type)) {
            handleTeacherEnterScore(request, response);
        } else if (MsgConst.TEACHER_BATCH_ENTER_SCORE.equals(type)) {
            handleTeacherBatchEnterScore(request, response);
        } else if (MsgConst.TEACHER_GET_STATS.equals(type)) {
            handleTeacherGetStats(request, response);
        } else if (MsgConst.TEACHER_GET_MY_SEMESTERS.equals(type)) {
            handleTeacherGetMySemesters(request, response);

        // ============================================================
        // 三、管理员端 - 课程管理
        // ============================================================
        } else if (MsgConst.ADMIN_GET_ALL_COURSES.equals(type)) {
            handleAdminGetAllCourses(request, response);
        } else if (MsgConst.ADMIN_ADD_COURSE.equals(type)) {
            handleAdminAddCourse(request, response);
        } else if (MsgConst.ADMIN_UPDATE_COURSE.equals(type)) {
            handleAdminUpdateCourse(request, response);
        } else if (MsgConst.ADMIN_DELETE_COURSE.equals(type)) {
            handleAdminDeleteCourse(request, response);
        } else if (MsgConst.ADMIN_GET_COURSE_DETAIL.equals(type)) {
            handleAdminGetCourseDetail(request, response);
        } else if (MsgConst.ADMIN_QUERY_COURSE_BY_ID.equals(type)) {
            handleAdminQueryCourseById(request, response);
        } else if (MsgConst.ADMIN_QUERY_TEACHER_BY_ID.equals(type)) {
            handleAdminQueryTeacherById(request, response);
        } else if (MsgConst.ADMIN_UPDATE_COURSE_AND_OFFERING.equals(type)) {
            handleAdminUpdateCourseAndOffering(request, response);
        } else if (MsgConst.ADMIN_DELETE_OFFERING.equals(type)) {
            handleAdminDeleteOffering(request, response);
        } else if (MsgConst.ADMIN_EXPORT_OFFERING_TEMPLATE.equals(type)) {
            handleAdminExportOfferingTemplate(request, response);
        } else if (MsgConst.ADMIN_IMPORT_OFFERING_EXCEL.equals(type)) {
            handleAdminImportOfferingExcel(request, response);
        } else if (MsgConst.ADMIN_CLONE_ROUND_OFFERINGS.equals(type)) {
            handleAdminCloneRoundOfferings(request, response);

        // ============================================================
        // 四、管理员端 - 培养方案
        // ============================================================
        } else if (MsgConst.ADMIN_GET_ALL_PROGRAMS.equals(type)) {
            handleAdminGetAllPrograms(request, response);
        } else if (MsgConst.ADMIN_GET_PROGRAM_COURSES.equals(type)) {
            handleAdminGetProgramCourses(request, response);
        } else if (MsgConst.ADMIN_BATCH_ADD_COURSE.equals(type)) {
            handleAdminBatchAddCourse(request, response);
        } else if (MsgConst.ADMIN_GET_OFFERING_IDS.equals(type)) {
            handleAdminGetOfferingIds(request, response);

        // ============================================================
        // 五、管理员端 - 选课管理
        // ============================================================
        } else if (MsgConst.ADMIN_HELP_SELECT.equals(type)) {
            handleAdminHelpSelect(request, response);
        } else if (MsgConst.ADMIN_HELP_DROP.equals(type)) {
            handleAdminHelpDrop(request, response);
        } else if (MsgConst.ADMIN_GET_SELECT_STATS.equals(type)) {
            handleAdminGetSelectStats(request, response);
        } else if (MsgConst.ADMIN_GET_STUDENT_STATUS.equals(type)) {
            handleAdminGetStudentStatus(request, response);
        } else if (MsgConst.ADMIN_SEARCH_STUDENTS.equals(type)) {
            handleAdminSearchStudents(request, response);
        } else if (MsgConst.ADMIN_GET_AVAILABLE_FOR_STUDENT.equals(type)) {
            handleAdminGetAvailableForStudent(request, response);

        // ============================================================
        // 六、管理员端 - 选课设置 / 轮次
        // ============================================================
        } else if (MsgConst.ADMIN_GET_SELECT_STATUS.equals(type)) {
            handleAdminGetSelectStatus(request, response);
        } else if (MsgConst.ADMIN_GET_SELECT_HISTORY.equals(type)) {
            handleAdminGetSelectHistory(request, response);
        } else if (MsgConst.ADMIN_GET_SEMESTERS.equals(type)) {
            handleAdminGetSemesters(request, response);
        } else if (MsgConst.ADMIN_GET_ALL_ROUNDS.equals(type)) {
            handleAdminGetAllRounds(request, response);
        } else if (MsgConst.ADMIN_ADD_ROUND.equals(type)) {
            handleAdminAddRound(request, response);
        } else if (MsgConst.ADMIN_CLOSE_ROUND.equals(type)) {
            handleAdminCloseRound(request, response);
        } else if (MsgConst.ADMIN_OPEN_ROUND.equals(type)) {
            handleAdminOpenRound(request, response);
        } else if (MsgConst.ADMIN_DELETE_ROUND.equals(type)) {
            handleAdminDeleteRound(request, response);
        } else if (MsgConst.GET_CURRENT_ROUND.equals(type)) {
            handleGetCurrentRound(request, response);
        } else if (MsgConst.ADMIN_UPDATE_ROUND.equals(type)) {
            handleAdminUpdateRound(request, response);
        } else if (MsgConst.ADMIN_GET_COURSES_BY_IDS.equals(type)) {
            handleAdminGetCoursesByIds(request, response);
        } else if (MsgConst.GET_RETAKE_COURSES_BY_ROUND.equals(type)) {
            handleGetRetakeCoursesByRound(request, response);
        } else if (MsgConst.GET_ALL_COURSES_BY_ROUND.equals(type)) {
            handleGetAllCoursesByRound(request, response);
        
        } else {
            response.setSuccess(false);
            response.setResponseMsg("[CourseHandler] 未知请求类型: " + type);
        }
    }

    // ============================================================
    // 一、学生端 - 选课处理
    // ============================================================

    @SuppressWarnings("unchecked")
    private void handleGetAvailableCourses(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String studentId = (String) params.get("studentId");
            String roundId = (String) params.get("roundId");
            String campus = (String) params.get("campus");

            if (roundId == null || roundId.isEmpty()) {
                response.setSuccess(false);
                response.setResponseMsg("未指定选课轮次");
                return;
            }

            List<CourseDisplayDTO> courses = studentService.getAvailableCoursesByRound(studentId, roundId, campus);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程列表失败: " + e.getMessage());
        }
    }

    private void handleGetSelectedCourses(Message request, Message response) {
        try {
            String studentId = (String) request.getData();
            String semester = getCurrentSemester();

            List<CourseDisplayDTO> courses = studentService.getMySelectedCourses(studentId, semester);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取已选课程失败: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleSubmitAllCourses(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String studentId = (String) params.get("studentId");
            List<String> offeringIds = (List<String>) params.get("offeringIds");
            String semester = (String) params.get("semester");

            if (semester == null || semester.isEmpty()) {
                semester = getCurrentSemester();
            }

            SmartSelectResultDTO result = studentService.submitAllCourses(studentId, offeringIds, semester);
            response.setSuccess(true);
            response.setData(result);
            response.setResponseMsg(result.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("提交选课失败: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleDropCourse(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String studentId = params.get("studentId");
            String offeringId = params.get("offeringId");

            String result = studentService.dropCourse(studentId, offeringId);
            response.setSuccess(result.contains("成功"));
            response.setData(result);
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("退课失败: " + e.getMessage());
        }
    }

    

    // ============================================================
    // 二、教师端 - 课程管理
    // ============================================================

    @SuppressWarnings("unchecked")
    private void handleTeacherGetMyCourses(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String teacherId = params.get("teacherId");
            String semester = params.get("semester");

            if (teacherId == null || teacherId.isEmpty()) {
                response.setSuccess(false);
                response.setResponseMsg("教师ID为空");
                return;
            }
            if (semester == null || semester.isEmpty()) {
                semester = getCurrentSemester();
            }

            List<CourseDisplayDTO> courses = teacherService.getMyCourses(teacherId, semester);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程列表失败: " + e.getMessage());
        }
    }

    private void handleTeacherGetStudents(Message request, Message response) {
        try {
            String offeringId = (String) request.getData();
            List<StudentScoreDTO> students = teacherService.getCourseStudents(offeringId);
            response.setSuccess(true);
            response.setData(students);
            response.setResponseMsg("获取成功，共 " + students.size() + " 名学生");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取学生名单失败: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleTeacherGetSchedule(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String teacherId = params.get("teacherId");
            String semester = params.get("semester");
            if (semester == null || semester.isEmpty()) semester = getCurrentSemester();

            List<ScheduleDTO> schedules = teacherService.getMyTeachingSchedule(teacherId, semester);
            response.setSuccess(true);
            response.setData(schedules);
            response.setResponseMsg("获取成功");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课表失败: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleTeacherEnterScore(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String offeringId = (String) params.get("offeringId");
            String studentId = (String) params.get("studentId");
            double score = ((Number) params.get("score")).doubleValue();

            String result = teacherService.enterScore(offeringId, studentId, score);
            response.setSuccess(result.contains("成功"));
            response.setData(result);
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("成绩保存失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleTeacherBatchEnterScore(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String offeringId = (String) params.get("offeringId");
            List<Map<String, Object>> scoreList = (List<Map<String, Object>>) params.get("scoreList");

            Map<String, Object> result = teacherService.batchEnterScores(offeringId, scoreList);
            response.setSuccess(true);
            response.setData(result);
            response.setResponseMsg("批量录入完成");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("批量录入失败：" + e.getMessage());
        }
    }

    private void handleTeacherGetStats(Message request, Message response) {
        try {
            String offeringId = (String) request.getData();
            Map<String, Object> stats = teacherService.getScoreStatistics(offeringId);
            response.setSuccess(true);
            response.setData(stats);
            response.setResponseMsg("获取统计成功");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取统计失败：" + e.getMessage());
        }
    }

    private void handleTeacherGetMySemesters(Message request, Message response) {
        try {
            String teacherId = (String) request.getData();
            List<String> semesters = teacherService.getMySemesters(teacherId);
            response.setSuccess(true);
            response.setData(semesters);
            response.setResponseMsg("获取成功，共 " + semesters.size() + " 个学期");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取学期列表失败：" + e.getMessage());
        }
    }

    // ============================================================
    // 三、管理员端 - 课程管理
    // ============================================================

    @SuppressWarnings("unchecked")
    private void handleAdminGetAllCourses(Message request, Message response) {
        try {
            String keyword = null;
            String roundId = null;

            if (request.getData() instanceof String) {
                keyword = (String) request.getData();
            } else if (request.getData() instanceof Map) {
                Map<String, Object> params = (Map<String, Object>) request.getData();
                keyword = (String) params.get("keyword");
                roundId = (String) params.get("roundId");
            }

            List<Map<String, Object>> courses;
            if (keyword != null && !keyword.trim().isEmpty()) {
                courses = adminCourseService.searchCourses(keyword.trim(), roundId);
            } else {
                courses = adminCourseService.getAllCoursesWithOffering(roundId);
            }

            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 条记录");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程列表失败：" + e.getMessage());
        }
    }

    private void handleAdminGetCourseDetail(Message request, Message response) {
        try {
            String offeringId = (String) request.getData();
            Map<String, Object> result = adminCourseService.getCourseDetailByOfferingId(offeringId);

            if (result != null && Boolean.TRUE.equals(result.get("success"))) {
                response.setSuccess(true);
                response.setData(result.get("data"));
                response.setResponseMsg("获取课程详情成功");
            } else {
                response.setSuccess(false);
                response.setResponseMsg(result != null ? (String) result.get("message") : "获取课程详情失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程详情失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminAddCourse(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            Course course = (Course) params.get("course");
            CourseOffering offering = (CourseOffering) params.get("offering");

            String result = adminCourseService.addCourseAndOffering(course, offering);
            response.setSuccess("新增成功".equals(result));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("新增失败：" + e.getMessage());
        }
    }

    private void handleAdminUpdateCourse(Message request, Message response) {
        try {
            Course course = (Course) request.getData();
            boolean success = adminCourseService.updateCourse(course);
            response.setSuccess(success);
            response.setResponseMsg(success ? "更新课程成功" : "更新课程失败");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("更新课程失败：" + e.getMessage());
        }
    }

    private void handleAdminDeleteCourse(Message request, Message response) {
        try {
            String courseId = (String) request.getData();
            String result = adminCourseService.deleteCourse(courseId);
            response.setSuccess(result.contains("成功"));
            response.setData(result);
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("删除课程失败：" + e.getMessage());
        }
    }

    private void handleAdminQueryCourseById(Message request, Message response) {
        try {
            String courseId = (String) request.getData();
            Course course = adminCourseService.getCourseById(courseId);
            response.setSuccess(true);
            response.setData(course);
            response.setResponseMsg(course != null ? "课程已存在" : "课程不存在");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("查询失败：" + e.getMessage());
        }
    }

    private void handleAdminQueryTeacherById(Message request, Message response) {
        try {
            String teacherId = (String) request.getData();
            Teacher teacher = adminRoundService.getTeacherById(teacherId);
            response.setSuccess(true);
            response.setData(teacher);
            response.setResponseMsg(teacher != null ? "教师已存在" : "教师不存在");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("查询失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminUpdateCourseAndOffering(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            Course course = (Course) params.get("course");
            CourseOffering offering = (CourseOffering) params.get("offering");
            String result = adminCourseService.updateCourseAndOffering(course, offering);
            response.setSuccess("修改成功".equals(result));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("修改失败：" + e.getMessage());
        }
    }

    private void handleAdminDeleteOffering(Message request, Message response) {
        try {
            String offeringId = (String) request.getData();
            String result = adminCourseService.deleteOffering(offeringId);
            response.setSuccess("删除成功".equals(result));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("删除失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminExportOfferingTemplate(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String roundId = (String) params.get("roundId");
            byte[] bytes = adminCourseService.exportOfferingTemplate(roundId);
            response.setSuccess(true);
            response.setData(bytes);
            response.setResponseMsg("导出成功");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("导出失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminImportOfferingExcel(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            byte[] fileBytes = (byte[]) params.get("fileBytes");
            String fileName = (String) params.get("fileName");

            if (fileBytes == null || fileBytes.length == 0) {
                response.setSuccess(false);
                response.setResponseMsg("文件为空");
                return;
            }

            Map<String, Object> result = adminCourseService.importOfferingExcel(fileBytes, fileName);
            response.setSuccess(Boolean.TRUE.equals(result.get("success")));
            response.setData(result);
            response.setResponseMsg((String) result.getOrDefault("message", "导入完成"));
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("导入失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminCloneRoundOfferings(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String sourceRoundId = (String) params.get("sourceRoundId");
            String targetRoundId = (String) params.get("targetRoundId");

            Map<String, Object> result = adminCourseService.cloneRoundOfferings(sourceRoundId, targetRoundId);
            response.setSuccess(Boolean.TRUE.equals(result.get("success")));
            response.setData(result);
            response.setResponseMsg((String) result.getOrDefault("message", "复制完成"));
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("复制失败：" + e.getMessage());
        }
    }

    // ============================================================
    // 四、管理员端 - 培养方案
    // ============================================================

    private void handleAdminGetAllPrograms(Message request, Message response) {
        try {
            List<Program> list = adminRoundService.getAllActivePrograms();
            response.setSuccess(true);
            response.setData(list);
            response.setResponseMsg("获取成功，共 " + list.size() + " 个培养方案");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取培养方案失败：" + e.getMessage());
        }
    }

    private void handleAdminGetProgramCourses(Message request, Message response) {
        try {
            String programId = (String) request.getData();
            List<ProgramCourse> list = adminRoundService.getProgramCourses(programId);
            response.setSuccess(true);
            response.setData(list);
            response.setResponseMsg("获取成功，共 " + list.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取培养方案课程失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminBatchAddCourse(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String programId = (String) params.get("programId");
            String semester = (String) params.get("semester");
            String roundId = (String) params.get("roundId");

            Map<String, Integer> classCountMap = new HashMap<>();
            Object ccm = params.get("classCountMap");
            if (ccm instanceof Map) {
                for (Map.Entry<?, ?> e : ((Map<?, ?>) ccm).entrySet()) {
                    try {
                        classCountMap.put(String.valueOf(e.getKey()),
                                Integer.parseInt(String.valueOf(e.getValue())));
                    } catch (NumberFormatException ignore) { }
                }
            }

            Map<String, Object> result = adminRoundService.batchAddCourseByProgram(
                    programId, semester, roundId, classCountMap);
            response.setSuccess(Boolean.TRUE.equals(result.get("success")));
            response.setData(result);
            response.setResponseMsg((String) result.getOrDefault("message", "批量新增完成"));
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("批量新增失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminGetOfferingIds(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String courseId = (String) params.get("courseId");
            String semester = (String) params.get("semester");
            List<String> list = adminRoundService.getOfferingIdsByCourseAndSemester(courseId, semester);
            response.setSuccess(true);
            response.setData(list);
            response.setResponseMsg("获取成功，共 " + list.size() + " 条");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取 offeringId 列表失败：" + e.getMessage());
        }
    }

    // ============================================================
    // 五、管理员端 - 选课管理
    // ============================================================

    @SuppressWarnings("unchecked")
    private void handleAdminHelpSelect(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String studentId = params.get("studentId");
            String offeringId = params.get("offeringId");
            String result = adminSelectService.adminSelectCourseForce(studentId, offeringId);
            response.setSuccess(result.contains("成功"));
            response.setData(result);
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("帮学生选课失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminHelpDrop(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String studentId = params.get("studentId");
            String offeringId = params.get("offeringId");
            String result = adminSelectService.adminDropCourse(studentId, offeringId);
            response.setSuccess(result.contains("成功"));
            response.setData(result);
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("帮学生退课失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminGetStudentStatus(Message request, Message response) {
        try {
            String studentId;
            String roundId = null;
            Object data = request.getData();
            if (data instanceof String) {
                studentId = (String) data;
            } else if (data instanceof Map) {
                Map<String, Object> params = (Map<String, Object>) data;
                studentId = (String) params.get("studentId");
                roundId = (String) params.get("roundId");
            } else {
                response.setSuccess(false);
                response.setResponseMsg("请求参数格式错误");
                return;
            }

            List<Map<String, Object>> courses = adminSelectService.getStudentSelectedCourses(studentId, roundId);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取学生选课状态失败：" + e.getMessage());
        }
    }

    private void handleAdminGetSelectStats(Message request, Message response) {
        try {
            String semester = request.getData() != null ? (String) request.getData() : adminRoundService.getCurrentSemester();
            List<Map<String, Object>> history = adminRoundService.getSelectHistory(semester);
            Map<String, Object> stats = new HashMap<>();
            stats.put("semester", semester);
            stats.put("totalCourses", history.size());
            stats.put("details", history);
            response.setSuccess(true);
            response.setData(stats);
            response.setResponseMsg("获取统计成功");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取选课统计失败：" + e.getMessage());
        }
    }

    private void handleAdminSearchStudents(Message request, Message response) {
        try {
            String keyword = (String) request.getData();
            List<Map<String, Object>> students = adminSelectService.searchStudents(keyword);
            response.setSuccess(true);
            response.setData(students);
            response.setResponseMsg("获取成功，共 " + students.size() + " 名学生");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("搜索学生失败：" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleAdminGetAvailableForStudent(Message request, Message response) {
        try {
            Map<String, String> params = (Map<String, String>) request.getData();
            String studentId = params.get("studentId");
            String roundId = params.get("roundId");

            List<Map<String, Object>> courses = adminSelectService.getStudentAvailableCourses(studentId, roundId);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取可选课程失败：" + e.getMessage());
        }
    }

    // ============================================================
    // 六、管理员端 - 选课设置 / 轮次
    // ============================================================

    private void handleAdminGetSelectStatus(Message request, Message response) {
        try {
            Map<String, Object> status = adminRoundService.getSelectStatus();
            response.setSuccess(true);
            response.setData(status);
            response.setResponseMsg("获取选课状态成功");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取选课状态失败：" + e.getMessage());
        }
    }

    
    private void handleAdminGetSelectHistory(Message request, Message response) {
        try {
            String semester = request.getData() != null ? (String) request.getData() : adminRoundService.getCurrentSemester();
            List<Map<String, Object>> history = adminRoundService.getSelectHistory(semester);
            response.setSuccess(true);
            response.setData(history);
            response.setResponseMsg("获取成功，共 " + history.size() + " 条记录");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取选课历史失败：" + e.getMessage());
        }
    }

    private void handleAdminGetSemesters(Message request, Message response) {
        try {
            List<String> semesters = adminRoundService.getSemesters();
            response.setSuccess(true);
            response.setData(semesters);
            response.setResponseMsg("获取成功，共 " + semesters.size() + " 个学期");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取学期列表失败：" + e.getMessage());
        }
    }

    private void handleAdminGetAllRounds(Message request, Message response) {
        try {
            List<SelectRound> rounds = adminRoundService.getAllRounds();
            response.setSuccess(true);
            response.setData(rounds);
            response.setResponseMsg("获取成功，共 " + rounds.size() + " 个轮次");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取轮次失败：" + e.getMessage());
        }
    }

    private void handleAdminAddRound(Message request, Message response) {
        try {
            SelectRound round = (SelectRound) request.getData();
            String result = adminRoundService.addRound(round);
            response.setSuccess(result.contains("成功"));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("新增轮次失败：" + e.getMessage());
        }
    }

    private void handleAdminCloseRound(Message request, Message response) {
        try {
            String roundId = (String) request.getData();
            String result = adminRoundService.closeRound(roundId);
            response.setSuccess(result.contains("成功"));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("关闭轮次失败：" + e.getMessage());
        }
    }

    private void handleAdminOpenRound(Message request, Message response) {
        try {
            String roundId = (String) request.getData();
            String result = adminRoundService.openRound(roundId);
            response.setSuccess(result.contains("成功"));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("开放轮次失败：" + e.getMessage());
        }
    }

    private void handleAdminDeleteRound(Message request, Message response) {
        try {
            String roundId = (String) request.getData();
            String result = adminRoundService.deleteRound(roundId);
            response.setSuccess(result.contains("成功"));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("删除轮次失败：" + e.getMessage());
        }
    }

    private void handleGetCurrentRound(Message request, Message response) {
        try {
            SelectRound round = adminRoundService.getCurrentOpenRound();
            response.setSuccess(true);
            response.setData(round);
            response.setResponseMsg(round != null ? "当前有开放的轮次" : "当前无开放轮次");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取当前轮次失败：" + e.getMessage());
        }
    }

    // ============================================================
    // 辅助方法
    // ============================================================

    private String getCurrentSemester() {
        try {
            SelectRound round = adminRoundService.getCurrentOpenRound();
            if (round != null && round.getSemester() != null && !round.getSemester().isEmpty()) {
                return round.getSemester();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "2025-2026-1";
    }
    private void handleAdminUpdateRound(Message request, Message response) {
        try {
            SelectRound round = (SelectRound) request.getData();
            String result = adminRoundService.updateRound(round);
            response.setSuccess(result.contains("成功"));
            response.setResponseMsg(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("修改轮次失败：" + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    private void handleAdminGetCoursesByIds(Message request, Message response) {
        try {
            List<String> courseIds = (List<String>) request.getData();
            List<Course> list = adminCourseService.getCoursesByIds(courseIds);
            response.setSuccess(true);
            response.setData(list);
            response.setResponseMsg("获取成功，共 " + list.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程失败：" + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    private void handleGetRetakeCoursesByRound(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String studentId = (String) params.get("studentId");
            String roundId = (String) params.get("roundId");
            String campus = (String) params.get("campus");

            if (roundId == null || roundId.isEmpty()) {
                response.setSuccess(false);
                response.setResponseMsg("未指定选课轮次");
                return;
            }

            List<CourseDisplayDTO> courses = studentService.getRetakeCoursesByRound(studentId, roundId, campus);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门重修课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取重修课程失败: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void handleGetAllCoursesByRound(Message request, Message response) {
        try {
            Map<String, Object> params = (Map<String, Object>) request.getData();
            String studentId = (String) params.get("studentId");
            String roundId = (String) params.get("roundId");
            String campus = (String) params.get("campus");

            if (roundId == null || roundId.isEmpty()) {
                response.setSuccess(false);
                response.setResponseMsg("未指定选课轮次");
                return;
            }

            List<CourseDisplayDTO> courses = studentService.getAllCoursesByRound(studentId, roundId, campus);
            response.setSuccess(true);
            response.setData(courses);
            response.setResponseMsg("获取成功，共 " + courses.size() + " 门课程");
        } catch (Exception e) {
            e.printStackTrace();
            response.setSuccess(false);
            response.setResponseMsg("获取课程列表失败: " + e.getMessage());
        }
    }
}