package vCampus.server.handler;

import java.util.List;
import java.util.Map;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.common.vo.Student;
import vCampus.common.vo.Program;
import vCampus.server.service.StudentService;
import vCampus.server.dao.ProgramDao;
import vCampus.server.StudentExcelImporter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import vCampus.server.service.CreditService;



public class StudentHandler {

    private StudentService studentService;
    private ProgramDao programDao;

    public StudentHandler() {
        studentService = new StudentService();
        programDao = new ProgramDao();
    }

    public Message handle(Message msg) {
        Message resp = new Message();
        String type = msg.getType();

        switch (type) {

        case MsgConst.QUERY_STUDENT_BY_SCARD: {
            System.out.println("====服务端收到【一卡通查询学生】请求====");
            String sCard = (String) msg.getData();
            System.out.println("收到一卡通号 = " + sCard);
            Student stu = studentService.findStudentBySCard(sCard);
            System.out.println("Dao查询返回的学生对象：" + stu);
            resp.setSuccess(stu != null);
            resp.setData(stu);
            if (stu != null) {
                resp.setResponseMsg("查询学生成功");
            } else {
                resp.setResponseMsg("未找到该学生");
            }
            break;
        }

        case MsgConst.QUERY_STUDENT_BY_CID: {
            String clazzId = (String) msg.getData();
            List<Student> list = studentService.findStudentByClazzId(clazzId);
            resp.setSuccess(true);
            resp.setData(list);
            resp.setResponseMsg("班级学生列表查询成功");
            break;
        }

        case MsgConst.QUERY_ALL_STUDENT: {
            List<Student> list = studentService.findAllStudent();
            resp.setSuccess(true);
            resp.setData(list);
            resp.setResponseMsg("全部学生列表查询成功");
            break;
        }

        case MsgConst.ADD_STUDENT: {
            Student newStu = (Student) msg.getData();
            boolean ok = studentService.addStudent(newStu);
            resp.setSuccess(ok);
            if (ok) {
                resp.setResponseMsg("新增学生成功");
            } else {
                resp.setResponseMsg("新增失败，学号重复或信息不全");
            }
            break;
        }

        case MsgConst.UPDATE_STUDENT: {
            Student updateStu = (Student) msg.getData();
            boolean ok = studentService.updateStudent(updateStu);
            resp.setSuccess(ok);
            if (ok) {
                resp.setResponseMsg("学生信息修改成功");
            } else {
                resp.setResponseMsg("修改失败，学籍已锁定或学生不存在");
            }
            break;
        }

        case MsgConst.DELETE_STUDENT: {
            String sCard = (String) msg.getData();
            boolean ok = studentService.deleteStudent(sCard);
            if (ok) {
                resp.setSuccess(true);
                resp.setResponseMsg("删除成功");
            } else {
                resp.setSuccess(false);
                resp.setResponseMsg("删除失败：该学生不存在或数据库异常");
            }
            break;
        }
        
        case MsgConst.LOCK_STUDENT: {
            String sCard = (String) msg.getData();
            boolean ok = studentService.lockStudent(sCard);
            resp.setSuccess(ok);
            resp.setResponseMsg(ok ? "学籍锁定成功" : "学籍锁定失败，学生不存在");
            break;
        }

        case MsgConst.UNLOCK_STUDENT: {
            String sCard = (String) msg.getData();
            boolean ok = studentService.unlockStudent(sCard);
            resp.setSuccess(ok);
            resp.setResponseMsg(ok ? "学籍解锁成功" : "学籍解锁失败，学生不存在");
            break;
        }

        case MsgConst.QUERY_PROGRAM_BY_MAJOR_AND_GRADE: {
            @SuppressWarnings("unchecked")
            Map<String, String> params = (Map<String, String>) msg.getData();
            String major = params.get("major");
            String grade = params.get("grade");
            try {
                Program program = programDao.getProgramByMajorAndGrade(major, grade);
                if (program != null) {
                    resp.setSuccess(true);
                    resp.setData(program.getTotalCreditsRequired());
                    resp.setResponseMsg("查询成功");
                } else {
                    resp.setSuccess(false);
                    resp.setResponseMsg("未找到匹配的培养方案");
                }
            } catch (Exception e) {
                e.printStackTrace();
                resp.setSuccess(false);
                resp.setResponseMsg("查询培养方案失败：" + e.getMessage());
            }
            break;
        }
        
        case MsgConst.ADMIN_IMPORT_STUDENT_EXCEL: {
            try {
                // 1. 取出客户端上传的Excel字节数组
                @SuppressWarnings("unchecked")
                Map<String, Object> params = (Map<String, Object>) msg.getData();
                byte[] fileBytes = (byte[]) params.get("fileBytes");

                // 2. 解析Excel得到学生列表
                List<Student> studentList = StudentExcelImporter.parse(fileBytes);

                int totalRows = studentList.size();
                int successCount = 0;
                List<String> errors = new ArrayList<>();

                // 3. 逐行调用入库，复用已有 addStudent（自带默认密码兜底）
                for (int i = 0; i < studentList.size(); i++) {
                    Student stu = studentList.get(i);
                    boolean ok = studentService.addStudent(stu);
                    if (ok) {
                        successCount++;
                    } else {
                        // Excel行号 = 索引+2（第1行表头+索引偏移）
                        errors.add("第" + (i + 2) + "行导入失败（一卡通号重复或信息不全）");
                    }
                }

                // 4. 封装返回结果
                Map<String, Object> result = new HashMap<>();
                result.put("totalRows", totalRows);
                result.put("successCount", successCount);
                result.put("failCount", errors.size());
                result.put("errors", errors);

                resp.setSuccess(true);
                resp.setData(result);
                resp.setResponseMsg("导入完成");

            } catch (Exception e) {
                e.printStackTrace();
                resp.setSuccess(false);
                resp.setResponseMsg("Excel解析失败：" + e.getMessage());
            }
            break;
        }
        
        case MsgConst.QUERY_COMPLETED_CREDIT: {
            // 取客户端参数
            Map<String, String> param = (Map<String, String>) msg.getData();
            String studentId = param.get("studentId");
            String semester  = param.get("semester");

            // 调用 CreditService 统计
            CreditService creditService = new CreditService();
            Map<String, Object> data = creditService.calcCompletedCredit(studentId, semester);

            // 写回响应
            resp.setSuccess(true);
            resp.setData(data);
            resp.setResponseMsg("统计完成");
            break;
        }

        default:
            resp.setSuccess(false);
            resp.setResponseMsg("【学籍模块】未知请求类型");
            System.out.println("【警告：未匹配到分支！收到消息类型：" + msg.getType() + "】");
            break;
        }
        return resp;
    }
}