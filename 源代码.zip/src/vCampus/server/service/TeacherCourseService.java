package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.util.*;

/**
 * 教师端课程管理业务服务
 * 功能：查看课程列表、查看学生名单、查看课表
 */
public class TeacherCourseService {

    private CourseDao courseDao = new CourseDao();
    private CourseOfferingDao offeringDao = new CourseOfferingDao();
    private SelectDao selectDao = new SelectDao();
    private SelectRoundDao roundDao = new SelectRoundDao();
    // ============================================================
    // 一、获取教师课程列表
    // ============================================================

    public List<CourseDisplayDTO> getMyCourses(String teacherId, String semester) {
        List<CourseDisplayDTO> result = new ArrayList<>();
        try {
            List<CourseOffering> offerings = offeringDao.getOfferingsByTeacherAndSemester(teacherId, semester);
            for (CourseOffering offering : offerings) {
                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                CourseDisplayDTO dto = new CourseDisplayDTO();
                dto.setCourseId(course.getCourseId());
                dto.setCourseName(course.getCourseName());
                dto.setCredit(course.getCredit());
                dto.setOfferingId(offering.getOfferingId());
                dto.setClassNum(extractClassNum(offering.getOfferingId()));
                dto.setTeacherName(offering.getTeacherName());
                dto.setSchedule(offering.getSchedule());
                dto.setClassroom(offering.getClassroom());
                dto.setCampus(offering.getCampus());
                dto.setSemester(offering.getSemester());
                dto.setCapacity(offering.getCapacity());
                dto.setEnrolledCount(offering.getEnrolledCount());
                dto.setFull(offering.getEnrolledCount() >= offering.getCapacity());
                dto.setStatus(offering.getStatus());

                // ★ 加这一段：填入该开课所属轮次的状态
                SelectRound round = roundDao.getRoundById(offering.getRoundId());
                if (round != null) {
                    dto.setRoundStatus(round.getStatus());
                } else {
                    dto.setRoundStatus("closed");   // 查不到按已结束处理，允许查看
                }

                result.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    // ============================================================
    // 二、查看课程学生名单（只读）
    // ============================================================

    public List<StudentScoreDTO> getCourseStudents(String offeringId) {
        try {
            CourseOffering offering = offeringDao.getOfferingById(offeringId);
            if (offering == null) return new ArrayList<>();
            SelectRound round = roundDao.getRoundById(offering.getRoundId());
            if (round != null && "open".equals(round.getStatus())) {
                return new ArrayList<>();   // 轮次开放中，不给看名单
            }
            return selectDao.getStudentsByOfferingId(offeringId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public List<StudentScoreDTO> getCourseStudentsWithFilter(String offeringId, String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getCourseStudents(offeringId);
        }
        try {
            return selectDao.searchStudentsByOfferingId(offeringId, keyword.trim());
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
 // 三、成绩管理
    // ============================================================

    /**
     * 录入/修改单个成绩
     * @param offeringId 开课班级ID
     * @param studentId 学生学号
     * @param score 成绩
     * @return 操作结果消息
     */
    public String enterScore(String offeringId, String studentId, double score) {
        if (score < 0 || score > 100) {
            return "成绩必须在 0-100 之间";
        }
        try {
            // 查询选课记录
            SelectRecord record = selectDao.getByStudentAndOffering(studentId, offeringId);
            if (record == null) {
                return "该学生未选此课程";
            }
            if (!"selected".equals(record.getStatus())) {
                return "该学生已退课，无法录入成绩";
            }
            // 更新成绩（直接使用 selectId）
            selectDao.updateScore(record.getSelectId(), score);
            return "成绩保存成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "成绩保存失败：" + e.getMessage();
        }
    }

    /**
     * 批量录入成绩
     * @param offeringId 开课班级ID
     * @param scoreList 成绩列表，每项包含 studentId, studentName, score
     * @return 批量操作结果
     */
    public Map<String, Object> batchEnterScores(String offeringId, List<Map<String, Object>> scoreList) {
        Map<String, Object> result = new HashMap<>();
        int successCount = 0;
        int failCount = 0;
        List<String> errors = new ArrayList<>();

        for (Map<String, Object> item : scoreList) {
            String studentId = (String) item.get("studentId");
            String studentName = (String) item.get("studentName");
            double score = ((Number) item.get("score")).doubleValue();

            try {
                if (score < 0 || score > 100) {
                    failCount++;
                    errors.add(studentName + ": 成绩超出范围(0-100)");
                    continue;
                }
                
                // 查询选课记录
                SelectRecord record = selectDao.getByStudentAndOffering(studentId, offeringId);
                if (record == null) {
                    failCount++;
                    errors.add(studentName + ": 未选此课程");
                    continue;
                }
                if (!"selected".equals(record.getStatus())) {
                    failCount++;
                    errors.add(studentName + ": 已退课，无法录入成绩");
                    continue;
                }
                
                // 更新成绩
                selectDao.updateScore(record.getSelectId(), score);
                successCount++;
            } catch (SQLException e) {
                failCount++;
                errors.add(studentName + ": " + e.getMessage());
                e.printStackTrace();
            }
        }

        result.put("successCount", successCount);
        result.put("failCount", failCount);
        result.put("errors", errors);
        return result;
    }

    /**
     * 获取某门课程的成绩统计信息
     * @param offeringId 开课班级ID
     * @return 成绩统计结果
     */
    public Map<String, Object> getScoreStatistics(String offeringId) {
        Map<String, Object> stats = new HashMap<>();
        try {
            List<StudentScoreDTO> students = selectDao.getStudentsByOfferingId(offeringId);
            int total = students.size();
            int scoredCount = 0;
            double sum = 0;
            double maxScore = 0;
            double minScore = 100;
            int passCount = 0;
            int excellentCount = 0;
            int failCount = 0;

            for (StudentScoreDTO s : students) {
                Double score = s.getScore();
                if (score != null) {
                    scoredCount++;
                    sum += score;
                    if (score > maxScore) maxScore = score;
                    if (score < minScore) minScore = score;
                    if (score >= 60) passCount++;
                    if (score >= 90) excellentCount++;
                    if (score < 60) failCount++;
                }
            }

            stats.put("totalStudents", total);
            stats.put("scoredCount", scoredCount);
            stats.put("unscoredCount", total - scoredCount);
            stats.put("avgScore", scoredCount > 0 ? Math.round(sum / scoredCount * 100) / 100.0 : 0);
            stats.put("maxScore", scoredCount > 0 ? maxScore : 0);
            stats.put("minScore", scoredCount > 0 ? minScore : 0);
            stats.put("passCount", passCount);
            stats.put("excellentCount", excellentCount);
            stats.put("failCount", failCount);
            stats.put("passRate", scoredCount > 0 ? Math.round((double) passCount / scoredCount * 10000) / 100.0 : 0);
            stats.put("excellentRate", scoredCount > 0 ? Math.round((double) excellentCount / scoredCount * 10000) / 100.0 : 0);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stats;
    }
    // ============================================================
    // 三、教师课表
    // ============================================================

    public List<ScheduleDTO> getMyTeachingSchedule(String teacherId, String semester) {
        List<ScheduleDTO> result = new ArrayList<>();
        try {
            List<CourseOffering> offerings = offeringDao.getOfferingsByTeacherAndSemester(teacherId, semester);
            for (CourseOffering offering : offerings) {
                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                ScheduleDTO dto = new ScheduleDTO();
                dto.setCourseId(course.getCourseId());
                dto.setCourseName(course.getCourseName());
                dto.setTeacherName(offering.getTeacherName());
                dto.setClassroom(offering.getClassroom());
                dto.setSchedule(offering.getSchedule());
                dto.setOfferingId(offering.getOfferingId());

                result.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
    /**
     * 获取教师所有授课学期列表
     */
    public List<String> getMySemesters(String teacherId) {
        List<String> semesters = new ArrayList<>();
        try {
            List<CourseOffering> offerings = offeringDao.getOfferingsByTeacherId(teacherId);
            Set<String> set = new LinkedHashSet<>();
            for (CourseOffering offering : offerings) {
                if (offering.getSemester() != null && !offering.getSemester().isEmpty()) {
                    set.add(offering.getSemester());
                }
            }

            // 把当前开放轮次的学期也加进来（可选）
            SelectRound current = roundDao.getCurrentOpenRound();
            if (current != null && current.getSemester() != null && !current.getSemester().isEmpty()) {
                set.add(current.getSemester());
            }

            // 把所有轮次的学期也加进来（可选，如果你希望"所有学期"都出现在下拉里）
            for (SelectRound r : roundDao.getAllRounds()) {
                if (r.getSemester() != null && !r.getSemester().isEmpty()) {
                    set.add(r.getSemester());
                }
            }

            semesters.addAll(set);
            Collections.sort(semesters, Collections.reverseOrder());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return semesters;
    }
    // ============================================================
    // 辅助方法
    // ============================================================

    private String extractClassNum(String offeringId) {
        if (offeringId == null) return "01";
        int idx = offeringId.lastIndexOf("-");
        if (idx > 0 && idx < offeringId.length() - 1) {
            return offeringId.substring(idx + 1);
        }
        if (offeringId.length() >= 2) {
            String suffix = offeringId.substring(offeringId.length() - 2);
            if (suffix.matches("\\d{2}")) {
                return suffix;
            }
        }
        return "01";
    }
}