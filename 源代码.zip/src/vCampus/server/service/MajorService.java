package vCampus.server.service;

import java.util.List;
import vCampus.common.vo.Department;
import vCampus.common.vo.Major;
import vCampus.common.vo.Clazz;
import vCampus.server.dao.MajorDao;

public class MajorService {
	private MajorDao majorDao = new MajorDao();
	
	public List<Major> findAllMajor() {
		return majorDao.findAll();
	}
	
	public Major findMajorById(String majorid) {
		return majorDao.findById(majorid);
	}
	
	public List<Major> findMajorByDeptId(String deptid) {
		return majorDao.findByDeptId(deptid);
	}
	
	public boolean addMajor(Major major) {
		Major exist = majorDao.findById(major.getMajorid());
		if(exist != null){
			return false;
		}

		DepartmentService deptService = new DepartmentService();
		Department dept = deptService.findDepartmentById(major.getDeptid());
		if(dept == null){
			return false;
		}
		return majorDao.add(major);
	}
	
	public boolean updateMajor(Major major) {
		DepartmentService deptService = new DepartmentService();
		Department dept = deptService.findDepartmentById(major.getDeptid());
		if(dept == null){
			return false;
		}
		return majorDao.update(major);
	}
	
	public boolean deleteMajor(String majorid) {
		ClazzService clazzService = new ClazzService();
		List<Clazz> clazzListUnderMajor = clazzService.findClazzByMajorId(majorid);
		if(!clazzListUnderMajor.isEmpty()){
			return false;
		}
		return majorDao.delete(majorid);
	}
}
