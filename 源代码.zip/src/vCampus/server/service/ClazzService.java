package vCampus.server.service;

import java.util.List;
import vCampus.common.vo.Clazz;
import vCampus.common.vo.Major;
import vCampus.common.vo.Student;
import vCampus.server.dao.ClazzDao;

public class ClazzService {
	private ClazzDao clazzDao = new ClazzDao();
	
	public List<Clazz> findAllClazz(){
		return clazzDao.findAll();
	}
	
	public Clazz findClazzById(String clazzid) {
		return clazzDao.findById(clazzid);
	}
	
	public List<Clazz> findClazzByMajorId(String majorid) {
		return clazzDao.findByMajorId(majorid);
	}
	
	public boolean addClazz(Clazz clazz) {
		Clazz exist = clazzDao.findById(clazz.getClazzid());
		if(exist != null) {
			return false;
		}

		MajorService majorService = new MajorService();
		Major major = majorService.findMajorById(clazz.getMajorid());
		if(major == null) {
			return false;
		}
		return clazzDao.add(clazz);
	}
	
	public boolean updateClazz(Clazz clazz) {
		MajorService majorService = new MajorService();
		Major major = majorService.findMajorById(clazz.getMajorid());
		if(major == null) {
			return false;
		}
		return clazzDao.update(clazz);
	}
	
	public boolean deleteClazz(String clazzid) {
		StudentService studentService = new StudentService();
        List<Student> studentList = studentService.findStudentByClazzId(clazzid);
        if(!studentList.isEmpty()){
            return false;
        }
        return clazzDao.delete(clazzid);
    }
}
