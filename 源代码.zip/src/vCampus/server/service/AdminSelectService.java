package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.util.*;

public class AdminSelectService {

    private CourseDao courseDao = new CourseDao();
    private CourseOfferingDao offeringDao = new CourseOfferingDao();
    private SelectDao selectDao = new SelectDao();
    private StudentDao studentDao = new StudentDao();
    private SelectRoundDao roundDao = new SelectRoundDao();

    // ============================================================
    // 一、学生选课查询
    // ============================================================

    public List<Map<String, Object>> getStudentSelectedCourses(String studentId, String roundId) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            roundId = resolveRoundId(roundId);
            if (roundId == null) return result;
            Set<String> roundOfferingIds = new HashSet<>();
            for (CourseOffering o : offeringDao.getOfferingsByRoundId(roundId)) {
                roundOfferingIds.add(o.getOfferingId());
            }
            for (SelectRecord record : selectDao.getByStudentId(studentId)) {
                if (!roundOfferingIds.contains(record.getOfferingId())) continue;
                CourseOffering offering = offeringDao.getOfferingById(record.getOfferingId());
                if (offering == null) continue;
                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                Map<String, Object> row = new HashMap<>();
                row.put("offeringId", offering.getOfferingId());
                row.put("courseId", course.getCourseId());
                row.put("courseName", course.getCourseName());
                row.put("teacherName", offering.getTeacherName());
                row.put("schedule", offering.getSchedule());
                row.put("selectType", record.getSelectType());
                row.put("status", record.getStatus());
                row.put("score", record.getScore());
                result.add(row);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    public List<Map<String, Object>> getStudentAvailableCourses(String studentId, String roundId) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            roundId = resolveRoundId(roundId);
            if (roundId == null) return result;
            Set<String> selectedIds = new HashSet<>();
            for (SelectRecord r : selectDao.getByStudentId(studentId)) {
                if ("selected".equals(r.getStatus())) selectedIds.add(r.getOfferingId());
            }
            for (CourseOffering offering : offeringDao.getOfferingsByRoundId(roundId)) {
                if (selectedIds.contains(offering.getOfferingId())) continue;
                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                Map<String, Object> row = new HashMap<>();
                row.put("offeringId", offering.getOfferingId());
                row.put("courseId", course.getCourseId());
                row.put("courseName", course.getCourseName());
                row.put("teacherName", offering.getTeacherName());
                row.put("capacity", offering.getCapacity());
                row.put("enrolledCount", offering.getEnrolledCount());
                row.put("roomCapacity", offering.getRoomCapacity());
                row.put("schedule", offering.getSchedule());
                row.put("classroom", offering.getClassroom());
                result.add(row);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    // ============================================================
    // 二、帮选 / 帮退
    // ============================================================

    /**
     * 管理员帮学生选课：无视时间冲突、名额，但受教室容量上限约束；超原容量时自动扩容
     */
    /**
     * 管理员帮学生选课：无视时间冲突、关闭状态，但受教室容量上限约束；
     * 超原容量时自动扩容；最后按实际记录数重算 enrolledCount。
     */
    public String adminSelectCourseForce(String studentId, String offeringId) {
        try {
            if (studentDao.findBySCard(studentId) == null) return "学生不存在";
            if (selectDao.existsSelectRecord(studentId, offeringId)) return "该学生已选此课程";

            CourseOffering offering = offeringDao.getOfferingById(offeringId);
            if (offering == null) return "开课班级不存在";

            String semester = offering.getSemester();

            // 同课限制：只检查同一学期内的已选
            for (SelectRecord r : selectDao.getByStudentId(studentId)) {
                if (!"selected".equals(r.getStatus())) continue;
                CourseOffering existing = offeringDao.getOfferingById(r.getOfferingId());
                if (existing == null) continue;
                if (!semester.equals(existing.getSemester())) continue;   // 跨学期跳过
                if (existing.getCourseId().equals(offering.getCourseId())) {
                    return "该学生在本学期已选同一课程的其他教学班";
                }
            }

            // 教室容量上限
            int roomCap = offering.getRoomCapacity() > 0 ? offering.getRoomCapacity() : offering.getCapacity();
            if (offering.getEnrolledCount() >= roomCap) {
                return "教室座位已满（" + offering.getEnrolledCount() + "/" + roomCap + "），无法再选";
            }

            // 先插选课记录（若失败，enrolledCount 不会误加）
            SelectRecord record = new SelectRecord();
            record.setStudentId(studentId);
            record.setOfferingId(offeringId);
            record.setSelectTime(new Date());
            record.setStatus("selected");
            record.setSelectType("first");
            selectDao.insertSelectRecord(record);

            // 自动扩容（在插记录之后）
            if (offering.getEnrolledCount() >= offering.getCapacity()) {
                int newCap = Math.min(offering.getCapacity() + 1, roomCap);
                offeringDao.updateCapacity(offeringId, newCap);
            }

            // 按实际记录数重算 enrolledCount 和 status
            offeringDao.recalcEnrolledCount(offeringId);

            return "选课成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "选课失败：" + e.getMessage();
        }
    }

    

    public String adminDropCourse(String studentId, String offeringId) {
        try {
            if (!selectDao.existsSelectRecord(studentId, offeringId)) return "该学生未选此课程";

            // 先删选课记录
            selectDao.deleteSelectRecord(studentId, offeringId);

            // 按实际记录数重算 enrolledCount 和 status
            offeringDao.recalcEnrolledCount(offeringId);

            return "退课成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "退课失败：" + e.getMessage();
        }
    }

    public List<Map<String, Object>> searchStudents(String keyword) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            for (Student s : studentDao.searchStudents(keyword)) {
                Map<String, Object> row = new HashMap<>();
                row.put("studentId", s.getSCard());
                row.put("studentName", s.getSname());
                row.put("gender", s.getSgender());
                row.put("classId", s.getClazzid());
                result.add(row);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    // ============================================================
    // 辅助
    // ============================================================

    private String resolveRoundId(String roundId) {
        if (roundId != null && !roundId.isEmpty()) return roundId;
        try {
            SelectRound r = roundDao.getCurrentOpenRound();
            return r != null ? r.getRoundId() : null;
        } catch (SQLException e) { return null; }
    }
}