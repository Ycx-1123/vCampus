package vCampus.server.service;

import vCampus.common.vo.CourseOffering;
import vCampus.common.vo.SelectRound;
import vCampus.server.dao.CourseOfferingDao;
import vCampus.server.dao.SelectRoundDao;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class RoundAutoScheduler {

    private static ScheduledExecutorService scheduler;
    private static ScheduledFuture<?> nextTask;

    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final SelectRoundDao roundDao = new SelectRoundDao();
    private static final CourseOfferingDao offeringDao = new CourseOfferingDao();

    public static void start() {
        if (scheduler == null) {
            scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "RoundAutoScheduler");
                t.setDaemon(true);
                return t;
            });
        }
        System.out.println("[RoundAutoScheduler] 启动");
        scheduleNextTick();
    }

    /**
     * 管理员改过轮次时间后调这个，重新算下一个时间点
     */
    public static void reschedule() {
        System.out.println("[RoundAutoScheduler] 重排定时任务");
        if (nextTask != null) nextTask.cancel(false);
        scheduleNextTick();
    }

    private static void scheduleNextTick() {
        long delayMillis = 60_000;   // 默认兜底 1 分钟

        try {
            Date now = new Date();
            Date nextEvent = null;

            for (SelectRound r : roundDao.getAllRounds()) {
                Date start = parse(r.getStartTime());
                Date end = parse(r.getEndTime());
                if (start != null && start.after(now)) {
                    if (nextEvent == null || start.before(nextEvent)) nextEvent = start;
                }
                if (end != null && end.after(now)) {
                    if (nextEvent == null || end.before(nextEvent)) nextEvent = end;
                }
            }

            if (nextEvent != null) {
                delayMillis = Math.max(0, nextEvent.getTime() - System.currentTimeMillis()) + 200;
                System.out.println("[RoundAutoScheduler] 下次扫描时间：" + new Date(System.currentTimeMillis() + delayMillis));
            } else {
                System.out.println("[RoundAutoScheduler] 无未来时间点，60 秒后重查");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        nextTask = scheduler.schedule(RoundAutoScheduler::onTick, delayMillis, TimeUnit.MILLISECONDS);
    }

    private static void onTick() {
        try {
            tick();
        } catch (Throwable e) {
            System.err.println("[RoundAutoScheduler] tick 异常：");
            e.printStackTrace();
        } finally {
            scheduleNextTick();
        }
    }

    private static void tick() throws SQLException {
        Date now = new Date();
        List<SelectRound> rounds = roundDao.getAllRounds();
        if (rounds == null || rounds.isEmpty()) return;

        SelectRound shouldBeOpen = null;
        Date shouldBeOpenStart = null;

        for (SelectRound r : rounds) {
            Date start = parse(r.getStartTime());
            Date end = parse(r.getEndTime());
            if (start == null || end == null) continue;
            boolean inWindow = !now.before(start) && now.before(end);
            if (inWindow) {
                if (shouldBeOpen == null || start.after(shouldBeOpenStart)) {
                    shouldBeOpen = r;
                    shouldBeOpenStart = start;
                }
            }
        }

        for (SelectRound r : rounds) {
            Date end = parse(r.getEndTime());
            boolean isOpenStatus = "open".equals(r.getStatus());
            boolean shouldOpen = (shouldBeOpen != null && r.getRoundId().equals(shouldBeOpen.getRoundId()));

            try {
                if (shouldOpen && !isOpenStatus) {
                    System.out.println("[RoundAutoScheduler] 自动开放：" + r.getRoundId());
                    openRound(r);
                } else if (!shouldOpen && isOpenStatus) {
                    if (end != null && !now.before(end)) {
                        System.out.println("[RoundAutoScheduler] 自动关闭（到时间）：" + r.getRoundId());
                        closeRound(r);
                    } else if (shouldBeOpen != null && !r.getRoundId().equals(shouldBeOpen.getRoundId())) {
                        System.out.println("[RoundAutoScheduler] 自动关闭（被取代）：" + r.getRoundId());
                        closeRound(r);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void openRound(SelectRound round) throws SQLException {
        roundDao.updateStatus(round.getRoundId(), "open");
        for (CourseOffering o : offeringDao.getOfferingsByRoundId(round.getRoundId())) {
            String st = o.getEnrolledCount() >= o.getCapacity() ? "full" : "open";
            offeringDao.updateStatus(o.getOfferingId(), st);
        }
    }

    private static void closeRound(SelectRound round) throws SQLException {
        roundDao.updateStatus(round.getRoundId(), "closed");
        for (CourseOffering o : offeringDao.getOfferingsByRoundId(round.getRoundId())) {
            offeringDao.updateStatus(o.getOfferingId(), "closed");
        }
    }

    private static Date parse(String s) {
        if (s == null || s.isEmpty()) return null;
        s = s.trim().replace("：", ":").replace("。", ".")
             .replace("/", "-").replace(".", "-");
        String[] patterns = {
                "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
                "yyyy-M-d HH:mm:ss", "yyyy-M-d HH:mm", "yyyy-M-d"
        };
        for (String p : patterns) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(p);
                sdf.setLenient(false);
                return sdf.parse(s);
            } catch (Exception ignore) { }
        }
        return null;
    }
}