package vCampus.server.service;

import java.util.List;

import vCampus.common.enums.PaymentMethod;
import vCampus.common.vo.DormFeeBill;
import vCampus.common.vo.DormPaymentRecord;

public interface StudentPaymentService {

    // 查询自己的全部住宿费账单
    List<DormFeeBill> queryMyBills(
            String sId
    );

    // 查询自己的未缴清账单
    List<DormFeeBill> queryUnpaidBills(
            String sId
    );

    // 缴纳指定账单
    String payBill(
            String sId,
            int billId,
            double amount,
            PaymentMethod method,
            String bankPIN
    );

    // 查询自己的缴费历史
    List<DormPaymentRecord> queryPaymentHistory(
            String sId
    );
}