package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.util.*;

/**
 * 学分统计服务
 */
public class CreditService {

    private SelectDao selectDao = new SelectDao();
    private CourseDao courseDao = new CourseDao();
    private StudentDao studentDao = new StudentDao();
    private SelectRoundDao roundDao = new SelectRoundDao();

    /**
     * 统计学生已修学分
     * 口径：非当前学期 + 成绩 >= 60 + 同课程重修取最高分
     *
     * @param studentId 学生一卡通号
     * @param semester  当前学期（用于排除）
     * @return Map: { completedCredit, passedCourseCount, details }
     */
    public Map<String, Object> calcCompletedCredit(String studentId, String semester) {
        Map<String, Object> result = new HashMap<>();
        try {
            if (semester == null || semester.isEmpty()) {
                SelectRound current = roundDao.getCurrentOpenRound();
                if (current != null) semester = current.getSemester();
                else semester = "";  // 没开放轮次时不过滤
            }

            Student student = studentDao.findBySCard(studentId);
            if (student == null) {
                result.put("success", false);
                result.put("message", "学生不存在");
                return result;
            }

            Map<String, Double> passed = selectDao.getPassedCoursesWithScore(studentId, semester);

            double totalCredit = 0;
            List<Map<String, Object>> details = new ArrayList<>();

            for (Map.Entry<String, Double> entry : passed.entrySet()) {
                String courseId = entry.getKey();
                Double score = entry.getValue();
                Course course = courseDao.getCourseById(courseId);
                if (course == null) continue;

                totalCredit += course.getCredit();

                Map<String, Object> row = new HashMap<>();
                row.put("courseId", courseId);
                row.put("courseName", course.getCourseName());
                row.put("credit", course.getCredit());
                row.put("score", score);
                details.add(row);
            }

            // 按课程号排序
            details.sort(Comparator.comparing(m -> (String) m.get("courseId")));

            // 培养方案要求总学分（如果有）
            double requiredCredit = 0;
            if (student.getRequiredCredit() != null) {
                requiredCredit = student.getRequiredCredit();
            }

            result.put("success", true);
            result.put("studentId", studentId);
            result.put("studentName", student.getSname());
            result.put("completedCredit", totalCredit);
            result.put("passedCourseCount", details.size());
            result.put("requiredCredit", requiredCredit);
            result.put("remainingCredit", Math.max(0, requiredCredit - totalCredit));
            result.put("details", details);
            return result;
        } catch (SQLException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "统计失败：" + e.getMessage());
            return result;
        }
    }
}