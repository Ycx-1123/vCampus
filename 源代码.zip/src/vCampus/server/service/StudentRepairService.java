package vCampus.server.service;

import java.util.List;

import vCampus.common.vo.DormRepair;

public interface StudentRepairService {

    // 提交宿舍报修
    boolean submitRepair(
            String sId,
            String dormId,
            String description
    );

    // 查询学生自己的报修记录
    List<DormRepair> queryMyRepairs(
            String sId
    );

    // 取消自己的报修申请
    boolean cancelRepair(
            String sId,
            int repairId
    );
}