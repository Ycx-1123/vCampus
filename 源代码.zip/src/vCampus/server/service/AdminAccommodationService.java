package vCampus.server.service;

import java.util.Date;
import java.util.List;

import vCampus.common.vo.Accommodation;
import vCampus.common.vo.AccommodationImportRow;

public interface AdminAccommodationService {

    // 办理入住
    String checkIn(
            String sId,
            String dormId,
            String bedNumber
    );


    // 批量办理入住
    // 同时根据 Excel 中的住宿费创建住宿费账单
    String batchCheckIn(
            List<AccommodationImportRow> rows,
            String academicYear,
            String semester,
            Date dueDate
    );


    // 办理退宿
    String executeCheckOut(
            String sId
    );


    // 执行调宿
    String executeDormChange(
            String sId,
            String newDormId,
            String newBedNumber
    );


    // 查询学生当前住宿
    Accommodation queryStudentDorm(
            String sId
    );


    // 查询住宿历史
    // sId为空：查询所有人的历史
    // sId不为空：查询指定学生的历史
    List<Accommodation> queryHistory(
            String sId
    );
}