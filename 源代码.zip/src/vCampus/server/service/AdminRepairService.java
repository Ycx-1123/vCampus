package vCampus.server.service;

import java.util.List;

import vCampus.common.enums.RepairStatus;
import vCampus.common.vo.DormRepair;

public interface AdminRepairService {

    // 查询全部报修
    List<DormRepair> queryAllRepairs();

    // 根据报修编号查询
    DormRepair queryRepairById(
            int repairId
    );

    // 修改报修状态
    boolean updateRepairStatus(
            int repairId,
            RepairStatus status
    );
}