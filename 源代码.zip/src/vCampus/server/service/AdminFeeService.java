package vCampus.server.service;

import java.util.Date;
import java.util.List;

import vCampus.common.vo.DormFeeBill;

public interface AdminFeeService {

    // 创建单个住宿费账单
    boolean createBill(
            String sId,
            int accommodationId,
            String academicYear,
            String semester,
            double amount,
            Date dueDate
    );

    // 批量创建住宿费账单
    int batchCreateBills(
            List<DormFeeBill> bills
    );

    // 查询全部账单
    List<DormFeeBill> queryAllBills();

    // 查询指定学生账单
    List<DormFeeBill> queryStudentBills(
            String sId
    );

    // 查询所有尚未缴清的账单
    List<DormFeeBill> queryUnpaidBills();

    // 根据编号查询账单详情
    DormFeeBill queryBillById(
            int billId
    );

    // 调整账单应缴金额
    boolean adjustBill(
            int billId,
            double amount
    );

    // 取消 / 作废账单
    boolean cancelBill(
            int billId
    );
}