package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.util.*;

public class AdminRoundService {

    private CourseDao courseDao = new CourseDao();
    private CourseOfferingDao offeringDao = new CourseOfferingDao();
    private SelectRoundDao roundDao = new SelectRoundDao();
    private ProgramDao programDao = new ProgramDao();
    private ProgramCourseDao programCourseDao = new ProgramCourseDao();
    private TeacherDao teacherDao = new TeacherDao();
    private SelectDao selectDao = new SelectDao();

    // ============================================================
    // 一、轮次管理
    // ============================================================

    public List<SelectRound> getAllRounds() {
        try { return roundDao.getAllRounds(); }
        catch (SQLException e) { e.printStackTrace(); return new ArrayList<>(); }
    }

    public SelectRound getCurrentOpenRound() {
        try { return roundDao.getCurrentOpenRound(); }
        catch (SQLException e) { e.printStackTrace(); return null; }
    }

    public List<SelectRound> getOpenRounds() {
        List<SelectRound> result = new ArrayList<>();
        try {
            for (SelectRound r : roundDao.getAllRounds()) {
                if ("open".equals(r.getStatus())) result.add(r);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    public String addRound(SelectRound round) {
        try {
            // ★ 根据当前时间校正状态
            String correctedStatus = inferRoundStatus(round.getStartTime(), round.getEndTime(), round.getStatus());
            round.setStatus(correctedStatus);

            if ("open".equals(correctedStatus)) {
                closeAllOpenRounds();
            }
            roundDao.insertRound(round);
            RoundAutoScheduler.reschedule();
            return "新增成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "新增失败：" + e.getMessage();
        }
    }
    /**
     * 修改轮次信息（名称、学期、起止时间、状态）
     * 会根据新的时间自动推断状态；如果新状态是 open，会先关闭其他 open 轮次。
     */
    public String updateRound(SelectRound round) {
        try {
            SelectRound existing = roundDao.getRoundById(round.getRoundId());
            if (existing == null) return "修改失败：轮次不存在";

            // 根据新时间推断状态
            String newStatus = inferRoundStatus(round.getStartTime(), round.getEndTime(), round.getStatus());
            round.setStatus(newStatus);

            // 如果新状态是 open，先关闭其他 open 轮次
            if ("open".equals(newStatus)) {
                for (SelectRound r : roundDao.getAllRounds()) {
                    if ("open".equals(r.getStatus()) && !r.getRoundId().equals(round.getRoundId())) {
                        roundDao.updateStatus(r.getRoundId(), "closed");
                        for (CourseOffering o : offeringDao.getOfferingsByRoundId(r.getRoundId())) {
                            offeringDao.updateStatus(o.getOfferingId(), "closed");
                        }
                    }
                }
            }

            // 更新数据库
            roundDao.updateRound(round);

            // 同步该轮次下开课班级状态
            for (CourseOffering o : offeringDao.getOfferingsByRoundId(round.getRoundId())) {
                if ("open".equals(newStatus)) {
                    String st = o.getEnrolledCount() >= o.getCapacity() ? "full" : "open";
                    offeringDao.updateStatus(o.getOfferingId(), st);
                } else if ("closed".equals(newStatus)) {
                    offeringDao.updateStatus(o.getOfferingId(), "closed");
                }
            }

            // 重排定时任务
            RoundAutoScheduler.reschedule();
            return "修改成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "修改失败：" + e.getMessage();
        }
    }

    /**
     * 根据当前时间推断轮次状态：
     *   当前时间 < startTime -> upcoming
     *   startTime <= 当前时间 < endTime -> open
     *   当前时间 >= endTime -> closed
     * 时间解析失败时返回 originalStatus
     */
    
    private String inferRoundStatus(String startTime, String endTime, String originalStatus) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            long now = System.currentTimeMillis();
            long start = sdf.parse(startTime).getTime();
            long end = sdf.parse(endTime).getTime();

            if (now < start) return "upcoming";
            if (now < end) return "open";
            return "closed";
        } catch (Exception e) {
            return originalStatus != null ? originalStatus : "upcoming";
        }
    }

    public String closeRound(String roundId) {
        try {
            roundDao.updateStatus(roundId, "closed");
            for (CourseOffering o : offeringDao.getOfferingsByRoundId(roundId)) {
                offeringDao.updateStatus(o.getOfferingId(), "closed");
            }
            RoundAutoScheduler.reschedule();
            return "关闭成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "关闭失败：" + e.getMessage();
        }
    }

    public String openRound(String roundId) {
        try {
            for (SelectRound r : roundDao.getAllRounds()) {
                if ("open".equals(r.getStatus()) && !r.getRoundId().equals(roundId)) {
                    roundDao.updateStatus(r.getRoundId(), "closed");
                    for (CourseOffering o : offeringDao.getOfferingsByRoundId(r.getRoundId())) {
                        offeringDao.updateStatus(o.getOfferingId(), "closed");
                    }
                }
            }
            roundDao.updateStatus(roundId, "open");
            for (CourseOffering o : offeringDao.getOfferingsByRoundId(roundId)) {
                String st = o.getEnrolledCount() >= o.getCapacity() ? "full" : "open";
                offeringDao.updateStatus(o.getOfferingId(), st);
            }
            RoundAutoScheduler.reschedule();
            return "开放成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "开放失败：" + e.getMessage();
        }
    }

    public String deleteRound(String roundId) {
        try {
            roundDao.deleteRound(roundId);
            RoundAutoScheduler.reschedule();
            return "删除成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "删除失败：" + e.getMessage();
        }
    }

    private void closeAllOpenRounds() throws SQLException {
        for (SelectRound r : roundDao.getAllRounds()) {
            if ("open".equals(r.getStatus())) {
                roundDao.updateStatus(r.getRoundId(), "closed");
                for (CourseOffering o : offeringDao.getOfferingsByRoundId(r.getRoundId())) {
                    offeringDao.updateStatus(o.getOfferingId(), "closed");
                }
            }
        }
    }

    // ============================================================
    // 二、学期 / 选课状态 / 历史
    // ============================================================

    public String getCurrentSemester() {
        SelectRound round = getCurrentOpenRound();
        if (round != null) return round.getSemester();
        return "2025-2026-1";
    }

    public Map<String, Object> getSelectStatus() {
        Map<String, Object> status = new HashMap<>();
        SelectRound round = getCurrentOpenRound();
        if (round != null) {
            status.put("isOpen", true);
            status.put("semester", round.getSemester());
            status.put("startTime", round.getStartTime());
            status.put("endTime", round.getEndTime());
        } else {
            status.put("isOpen", false);
        }
        return status;
    }

    

    public List<Map<String, Object>> getSelectHistory(String semester) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            for (CourseOffering offering : offeringDao.getOfferingsBySemester(semester)) {
                Map<String, Object> row = new HashMap<>();
                row.put("offeringId", offering.getOfferingId());
                row.put("courseId", offering.getCourseId());
                // ★ 用 selectDao 统计选课记录数（已修正）
                row.put("selectCount", selectDao.getByOfferingId(offering.getOfferingId()).size());
                row.put("status", offering.getStatus());
                result.add(row);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    public List<String> getSemesters() {
        List<String> semesters = new ArrayList<>();
        try {
            Set<String> set = new HashSet<>();
            for (CourseOffering o : offeringDao.getAllOfferings()) {
                if (o.getSemester() != null && !o.getSemester().isEmpty()) set.add(o.getSemester());
            }
            semesters.addAll(set);
            Collections.sort(semesters);
        } catch (SQLException e) { e.printStackTrace(); }
        return semesters;
    }

    // ============================================================
    // 三、培养方案相关
    // ============================================================

    public List<Program> getAllActivePrograms() {
        List<Program> result = new ArrayList<>();
        try {
            for (Program p : programDao.getAllPrograms()) {
                if ("active".equals(p.getStatus())) result.add(p);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    public List<ProgramCourse> getProgramCourses(String programId) {
        try { return programCourseDao.getByProgramId(programId); }
        catch (SQLException e) { e.printStackTrace(); return new ArrayList<>(); }
    }

    public List<String> getOfferingIdsByCourseAndSemester(String courseId, String semester) {
        List<String> result = new ArrayList<>();
        try {
            for (CourseOffering o : offeringDao.getOfferingsByCourseId(courseId)) {
                if (semester.equals(o.getSemester())) result.add(o.getOfferingId());
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    // ============================================================
    // 四、批量新增课程
    // ============================================================

    public Map<String, Object> batchAddCourseByProgram(
            String programId, String semester, String roundId,
            Map<String, Integer> classCountMap) {

        Map<String, Object> result = new HashMap<>();
        List<String> errors = new ArrayList<>();
        int successCount = 0, skipCount = 0, processedCount = 0;

        try {
            if (roundId == null || roundId.isEmpty()) {
                SelectRound openRound = roundDao.getCurrentOpenRound();
                if (openRound == null) {
                    result.put("success", false);
                    result.put("message", "当前没有开放的选课轮次");
                    return result;
                }
                roundId = openRound.getRoundId();
            }

            List<ProgramCourse> programCourses = programCourseDao.getByProgramId(programId);
            List<ProgramCourse> matched = new ArrayList<>();
            for (ProgramCourse pc : programCourses) {
                if (semester.equals(pc.getRecommendSemester())) matched.add(pc);
            }
            if (matched.isEmpty()) {
                result.put("success", false);
                result.put("message", "该培养方案在学期 " + semester + " 下没有推荐课程");
                return result;
            }

            for (ProgramCourse pc : matched) {
                String courseId = pc.getCourseId();

                // ★ 只处理 classCountMap 里显式指定了正数的课程
                //   map 为 null / 没有该 courseId / 值 <= 0 → 跳过
                //   值 > 20 → 截断到 20
                if (classCountMap == null || !classCountMap.containsKey(courseId)) {
                    skipCount++;
                    continue;
                }
                Integer v = classCountMap.get(courseId);
                if (v == null || v <= 0) {
                    skipCount++;
                    continue;
                }
                int classCount = v;
                if (classCount > 20) classCount = 20;

                processedCount++;

                try {
                    Course course = courseDao.getCourseById(courseId);
                    if (course == null) {
                        course = new Course();
                        course.setCourseId(courseId);
                        course.setCourseName(courseId);
                        course.setCredit(pc.getCreditWeight());
                        course.setHours(0);
                        course.setCategoryId(null);
                        course.setDescription("由批量新增自动创建，待完善");
                        courseDao.insertCourse(course);
                    }

                    for (int i = 0; i < classCount; i++) {
                        String offeringId = generateOfferingIdForBatch(courseId, semester);
                        CourseOffering offering = new CourseOffering();
                        offering.setOfferingId(offeringId);
                        offering.setCourseId(courseId);
                        offering.setTeacherId("");
                        offering.setTeacherName("");
                        offering.setSemester(semester);
                        offering.setCapacity(50);
                        offering.setEnrolledCount(0);
                        offering.setSchedule("");
                        offering.setClassroom("");
                        offering.setCampus("九龙湖");
                        offering.setStatus("closed");
                        offering.setVersion(0);
                        offering.setRoundId(roundId);
                        offering.setRoomCapacity(70);
                        offeringDao.insertOffering(offering);
                        successCount++;
                    }
                } catch (SQLException e) {
                    errors.add(courseId + ": " + e.getMessage());
                }
            }

            result.put("success", true);
            result.put("successCount", successCount);
            result.put("skipCount", skipCount);
            result.put("totalCount", processedCount);   // ★ 改为实际处理的课程数
            result.put("errors", errors);
            result.put("message", String.format(
                    "已创建 %d 条待完善的开课记录（涉及 %d 门课，跳过 %d 门），失败 %d 条",
                    successCount, processedCount, skipCount, errors.size()));
        } catch (SQLException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "批量新增失败：" + e.getMessage());
        }
        return result;
    }
    private String generateOfferingIdForBatch(String courseId, String semester) throws SQLException {
        List<CourseOffering> existing = offeringDao.getOfferingsByCourseId(courseId);
        Set<String> existingIds = new HashSet<>();
        for (CourseOffering o : existing) existingIds.add(o.getOfferingId());
        for (int seq = 1; seq <= 99; seq++) {
            String candidate = courseId + "-" + semester + "-" + String.format("%02d", seq);
            if (!existingIds.contains(candidate)) return candidate;
        }
        return courseId + "-" + semester + "-" + System.currentTimeMillis();
    }
    
    // ============================================================
    // 五、教师查询（用于新增课程时填教师名）
    // ============================================================

    public Teacher getTeacherById(String teacherCard) {
        try { return teacherDao.getByCard(teacherCard); }
        catch (SQLException e) { e.printStackTrace(); return null; }
    }
}