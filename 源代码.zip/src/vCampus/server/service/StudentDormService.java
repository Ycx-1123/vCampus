package vCampus.server.service;

import java.util.List;

import vCampus.common.vo.Accommodation;
import vCampus.common.vo.Dormitory;

public interface StudentDormService {

    // 查询全部宿舍
    List<Dormitory> queryAllDorm();

    // 查询有空余床位的宿舍
    List<Dormitory> queryAvailableDorm();

    // 查询学生当前住宿
    Accommodation queryMyDorm(
            String sId
    );

    // 查询指定宿舍剩余床位数量
    int getRemainingBeds(
            String dormId
    );

    // 查询指定宿舍可用床位
    List<String> queryAvailableBeds(
            String dormId
    );
}