package vCampus.server.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import vCampus.common.vo.Admin;
import vCampus.common.vo.BorrowRecord;
import vCampus.common.vo.LibraryAdminRequest;
import vCampus.server.dao.BorrowRecordDao;
import vCampus.server.dao.DBUtil;

/** 管理员登录会话与借阅代办；不信任请求中自行填写的管理员身份。 */
public final class LibraryAdminService {
    private static final long SESSION_MILLIS = 8 * 60 * 60 * 1000L;
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final BorrowRecordDao records = new BorrowRecordDao();
    private static final class Session {
        final String card;
        final long expires = System.currentTimeMillis() + SESSION_MILLIS;
        Session(String card) { this.card = card; }
    }

    /** 仅由服务端登录成功分支调用，不向客户端暴露发放接口。 */
    public void onAuthenticatedLogin(Admin admin) {
        if (!admin.isManageLibrary()) return;
        sessions.entrySet().removeIf(e -> e.getValue().expires < System.currentTimeMillis());
        String token = UUID.randomUUID().toString();
        sessions.put(token, new Session(admin.getACard()));
        admin.setLibrarySessionToken(token);
    }

    private void authorize(LibraryAdminRequest request) throws SQLException {
        Session session = request == null || request.sessionToken == null ? null : sessions.get(request.sessionToken);
        if (session == null || session.expires < System.currentTimeMillis()) {
            throw new SQLException("管理员登录已失效，请退出后重新登录");
        }
        try (Connection conn = DBUtil.getConnection(); PreparedStatement query = conn.prepareStatement(
                "SELECT manageLibrary FROM tbl_admin WHERE aCard=?")) {
            query.setString(1, session.card);
            try (ResultSet result = query.executeQuery()) {
                if (!result.next() || !result.getBoolean(1)) throw new SQLException("当前管理员没有图书馆管理权限");
            }
        }
    }

    public List<BorrowRecord> search(LibraryAdminRequest request) throws SQLException {
        authorize(request);
        return records.searchAll(request.readerId, request.bookName, request.fromDate, request.toDate);
    }

    public boolean borrow(LibraryAdminRequest request) throws SQLException {
        authorize(request);
        String reader = required(request.readerId, "用户 ID（一卡通号）");
        String copy = required(request.copyId, "副本编号");
        LocalDate today = LocalDate.now();
        return records.borrow(copy, reader, today, today.plusDays(30));
    }

    public boolean returnBook(LibraryAdminRequest request) throws SQLException {
        authorize(request);
        return records.returnForReader(required(request.recordId, "借阅记录编号"),
                required(request.readerId, "用户 ID（一卡通号）"), LocalDate.now());
    }

    private String required(String value, String label) throws SQLException {
        if (value == null || value.trim().isEmpty()) throw new SQLException("请填写" + label);
        return value.trim();
    }
}
