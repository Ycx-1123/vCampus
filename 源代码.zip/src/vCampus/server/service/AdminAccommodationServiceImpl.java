package vCampus.server.service;

import java.util.Date;
import java.util.List;

import vCampus.common.enums.StayStatus;
import vCampus.common.vo.Accommodation;
import vCampus.common.vo.Dormitory;
import vCampus.common.vo.Student;
import vCampus.common.vo.DormFeeBill;
import vCampus.common.vo.AccommodationImportRow;

import vCampus.server.dao.AccommodationDAO;
import vCampus.server.dao.DormitoryDAO;
import vCampus.server.dao.DormFeeBillDAO;
import vCampus.server.dao.StudentDao;

public class AdminAccommodationServiceImpl
        implements AdminAccommodationService {

    private AccommodationDAO accommodationDAO;
    private DormitoryDAO dormitoryDAO;
    private DormFeeBillDAO dormFeeBillDAO;
    private StudentDao studentDao;


    public AdminAccommodationServiceImpl() {

        accommodationDAO =
                new AccommodationDAO();

        dormitoryDAO =
                new DormitoryDAO();

        dormFeeBillDAO =
                new DormFeeBillDAO();

        studentDao =
                new StudentDao();
    }


    // =====================================================
    // 办理入住
    // =====================================================

    @Override
    public String checkIn(
            String sId,
            String dormId,
            String bedNumber) {

        if (isEmpty(sId)
                || isEmpty(dormId)
                || isEmpty(bedNumber)) {

            return "入住信息不能为空";
        }


        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(sId);

        if (current != null) {

            return "该学生已经入住";
        }


        Dormitory dorm =
                dormitoryDAO.findById(dormId);

        if (dorm == null) {

            return "宿舍不存在";
        }


        /*
         * 性别校验
         *
         * 学生性别来自 tbl_student.sgender
         * 宿舍性别来自 tbl_dormitory.gender
         *
         * 男生只能进入男寝
         * 女生只能进入女寝
         */
        String genderResult =
                checkGenderMatch(
                        sId,
                        dorm
                );

        if (genderResult != null) {

            return genderResult;
        }


        if (dorm.getOccupied()
                >= dorm.getCapacity()) {

            return "宿舍已满";
        }


        if (accommodationDAO
                .isBedOccupied(
                        dormId,
                        bedNumber)) {

            return "该床位已被占用";
        }


        Accommodation accommodation =
                new Accommodation();

        accommodation.setsId(sId);

        accommodation.setDormId(dormId);

        accommodation.setBedNumber(
                bedNumber
        );

        accommodation.setCheckInTime(
                new Date()
        );

        accommodation.setStatus(
                StayStatus.IN
        );


        boolean insertResult =
                accommodationDAO.insert(
                        accommodation
                );

        if (!insertResult) {

            return "入住失败：住宿记录创建失败";
        }


        boolean occupiedResult =
                dormitoryDAO.updateOccupied(
                        dormId,
                        dorm.getOccupied() + 1
                );

        if (!occupiedResult) {

            accommodationDAO.checkOut(
                    accommodation.getRecordId()
            );

            return "入住失败：宿舍人数更新失败";
        }


        return "入住成功";
    }


    @Override
    public String batchCheckIn(
            List<AccommodationImportRow> rows,
            String academicYear,
            String semester,
            Date dueDate) {

        if (rows == null
                || rows.isEmpty()) {

            return "没有可导入的住宿数据";
        }


        if (academicYear == null
                || academicYear.trim().isEmpty()) {

            return "学年不能为空";
        }


        if (semester == null
                || semester.trim().isEmpty()) {

            return "学期不能为空";
        }


        if (dueDate == null) {

            return "缴费截止日期不能为空";
        }


        int successCount = 0;

        int failCount = 0;

        StringBuilder failMessage =
                new StringBuilder();


        for (AccommodationImportRow row
                : rows) {

            if (row == null) {

                failCount++;

                continue;
            }


            String sId =
                    row.getsId();

            String dormId =
                    row.getDormId();

            String bedNumber =
                    row.getBedNumber();


            if (isEmpty(sId)
                    || isEmpty(dormId)
                    || isEmpty(bedNumber)) {

                failCount++;

                failMessage.append(
                        "存在空的学生、宿舍或床位信息\n"
                );

                continue;
            }


            /*
             * 批量入住直接调用 checkIn()。
             *
             * 因此这里会自动执行：
             * 1. 学生重复入住检查
             * 2. 宿舍存在检查
             * 3. 男女寝性别检查
             * 4. 宿舍容量检查
             * 5. 床位占用检查
             */
            String checkInResult =
                    checkIn(
                            sId.trim(),
                            dormId.trim(),
                            bedNumber.trim()
                    );


            if (!"入住成功".equals(
                    checkInResult)) {

                failCount++;

                failMessage.append(
                        sId
                );

                failMessage.append(
                        "："
                );

                failMessage.append(
                        checkInResult
                );

                failMessage.append(
                        "\n"
                );

                continue;
            }


            /*
             * 入住成功以后重新查询当前住宿记录，
             * 获取刚刚生成的 recordId。
             */
            Accommodation accommodation =
                    accommodationDAO
                            .findCurrentByStudentId(
                                    sId.trim()
                            );


            if (accommodation == null) {

                failCount++;

                failMessage.append(
                        sId
                );

                failMessage.append(
                        "：住宿记录创建成功但无法获取记录ID\n"
                );

                continue;
            }


            /*
             * Excel 中的住宿费
             */
            double fee =
                    row.getFee();


            if (fee <= 0) {

                failCount++;

                failMessage.append(
                        sId
                );

                failMessage.append(
                        "：住宿费必须大于0\n"
                );

                continue;
            }


            /*
             * 创建住宿费账单
             */
            DormFeeBill bill =
                    new DormFeeBill();


            bill.setsId(
                    sId.trim()
            );


            bill.setAccommodationId(
                    accommodation.getRecordId()
            );


            bill.setAcademicYear(
                    academicYear.trim()
            );


            bill.setSemester(
                    semester.trim()
            );


            bill.setAmount(
                    fee
            );


            bill.setPaidAmount(
                    0
            );


            bill.setDueDate(
                    dueDate
            );


            /*
             * 新入住学生默认未缴费
             */
            bill.setStatus(
                    vCampus.common.enums.FeeStatus.UNPAID
            );


            bill.setCreateTime(
                    new Date()
            );


            boolean billResult =
                    dormFeeBillDAO.insert(
                            bill
                    );


            if (!billResult) {

                /*
                 * 住宿已经创建成功，
                 * 但是住宿费账单创建失败。
                 *
                 * 这里保持原来的处理逻辑，
                 * 不删除住宿记录。
                 */
                failCount++;

                failMessage.append(
                        sId
                );

                failMessage.append(
                        "：住宿成功，但住宿费账单创建失败\n"
                );

                continue;
            }


            successCount++;
        }


        StringBuilder result =
                new StringBuilder();


        result.append(
                "批量导入完成\n"
        );


        result.append(
                "成功："
        );

        result.append(
                successCount
        );

        result.append(
                " 条\n"
        );


        result.append(
                "失败："
        );

        result.append(
                failCount
        );

        result.append(
                " 条"
        );


        if (failMessage.length() > 0) {

            result.append(
                    "\n\n失败原因：\n"
            );

            result.append(
                    failMessage
            );
        }


        return result.toString();
    }


    // =====================================================
    // 办理退宿
    // =====================================================

    @Override
    public String executeCheckOut(
            String sId) {

        if (isEmpty(sId)) {

            return "学生编号不能为空";
        }


        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(sId);

        if (current == null) {

            return "该学生当前没有住宿记录";
        }


        Dormitory dorm =
                dormitoryDAO.findById(
                        current.getDormId()
                );

        if (dorm == null) {

            return "当前宿舍信息不存在";
        }


        int oldOccupied =
                dorm.getOccupied();

        int newOccupied =
                Math.max(
                        oldOccupied - 1,
                        0
                );


        boolean occupiedResult =
                dormitoryDAO.updateOccupied(
                        dorm.getDormId(),
                        newOccupied
                );

        if (!occupiedResult) {

            return "退宿失败：宿舍人数更新失败";
        }


        boolean checkOutResult =
                accommodationDAO.checkOut(
                        current.getRecordId()
                );

        if (!checkOutResult) {

            dormitoryDAO.updateOccupied(
                    dorm.getDormId(),
                    oldOccupied
            );

            return "退宿失败：住宿记录更新失败";
        }


        return "退宿成功";
    }


    // =====================================================
    // 执行调宿
    // =====================================================

    @Override
    public String executeDormChange(
            String sId,
            String newDormId,
            String newBedNumber) {

        if (isEmpty(sId)
                || isEmpty(newDormId)
                || isEmpty(newBedNumber)) {

            return "调宿信息不能为空";
        }


        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(sId);

        if (current == null) {

            return "该学生当前没有住宿记录";
        }


        if (newDormId.equals(
                current.getDormId())
                &&
                newBedNumber.equals(
                        current.getBedNumber())) {

            return "新宿舍和床位与当前住宿相同";
        }


        Dormitory newDorm =
                dormitoryDAO.findById(
                        newDormId
                );

        if (newDorm == null) {

            return "目标宿舍不存在";
        }


        /*
         * 调宿时也必须进行男女寝校验。
         *
         * 这里不能只依赖前端界面判断，
         * 因为管理员审批调宿最终也会调用这个方法。
         */
        String genderResult =
                checkGenderMatch(
                        sId,
                        newDorm
                );

        if (genderResult != null) {

            return genderResult;
        }


        if (newDorm.getOccupied()
                >= newDorm.getCapacity()) {

            return "目标宿舍已满";
        }


        if (accommodationDAO
                .isBedOccupied(
                        newDormId,
                        newBedNumber)) {

            return "目标床位已被占用";
        }


        Dormitory oldDorm =
                dormitoryDAO.findById(
                        current.getDormId()
                );

        if (oldDorm == null) {

            return "原宿舍信息不存在";
        }


        Accommodation newAccommodation =
                new Accommodation();

        newAccommodation.setsId(sId);

        newAccommodation.setDormId(
                newDormId
        );

        newAccommodation.setBedNumber(
                newBedNumber
        );

        newAccommodation.setCheckInTime(
                new Date()
        );

        newAccommodation.setStatus(
                StayStatus.IN
        );


        boolean insertResult =
                accommodationDAO.insert(
                        newAccommodation
                );

        if (!insertResult) {

            return "调宿失败：新住宿记录创建失败";
        }


        boolean newDormResult =
                dormitoryDAO.updateOccupied(
                        newDormId,
                        newDorm.getOccupied() + 1
                );

        if (!newDormResult) {

            accommodationDAO.checkOut(
                    newAccommodation.getRecordId()
            );

            return "调宿失败：目标宿舍人数更新失败";
        }


        boolean oldCheckOutResult =
                accommodationDAO.checkOut(
                        current.getRecordId()
                );

        if (!oldCheckOutResult) {

            accommodationDAO.checkOut(
                    newAccommodation.getRecordId()
            );

            dormitoryDAO.updateOccupied(
                    newDormId,
                    newDorm.getOccupied()
            );

            return "调宿失败：原住宿记录更新失败";
        }


        boolean oldDormResult =
                dormitoryDAO.updateOccupied(
                        oldDorm.getDormId(),
                        Math.max(
                                oldDorm.getOccupied() - 1,
                                0
                        )
                );

        if (!oldDormResult) {

            return "调宿完成，但原宿舍人数更新失败";
        }


        return "调宿成功";
    }


    // =====================================================
    // 查询学生当前住宿
    // =====================================================

    @Override
    public Accommodation queryStudentDorm(
            String sId) {

        if (isEmpty(sId)) {

            return null;
        }


        return accommodationDAO
                .findCurrentByStudentId(
                        sId
                );
    }


    // =====================================================
    // 查询住宿历史
    // sId为空：查询所有人的历史
    // sId不为空：查询指定学生的历史
    // =====================================================

    @Override
    public List<Accommodation> queryHistory(
            String sId) {

        if (isEmpty(sId)) {

            return accommodationDAO.findAll();
        }


        return accommodationDAO
                .findByStudentId(sId);
    }


    // =====================================================
    // 性别校验
    // =====================================================

    /**
     * 检查学生性别和宿舍性别是否匹配。
     *
     * 学生性别：
     * 男 / MALE
     * 女 / FEMALE
     *
     * 宿舍性别：
     * MALE
     * FEMALE
     *
     * 返回 null 表示校验通过。
     * 返回字符串表示校验失败。
     */
    private String checkGenderMatch(
            String sId,
            Dormitory dorm) {

        if (dorm == null) {

            return "宿舍不存在";
        }


        Student student =
                findStudentById(sId);

        if (student == null) {

            return "学生不存在";
        }


        String studentGender =
                normalizeGender(
                        student.getSgender()
                );

        String dormGender =
                normalizeGender(
                        dorm.getGender()
                );


        if (studentGender == null) {

            return "学生性别信息异常";
        }


        if (dormGender == null) {

            return "宿舍性别信息异常";
        }


        if (!studentGender.equals(
                dormGender)) {

            if ("MALE".equals(
                    studentGender)) {

                return "入住失败：男生不能入住女寝";

            } else {

                return "入住失败：女生不能入住男寝";
            }
        }


        return null;
    }


    /**
     * 根据学生编号查询学生。
     *
     * 当前 StudentDao 已经提供 findAll()，
     * 并且会读取 tbl_student.sgender，
     * 因此这里直接按 sid 查找。
     */
    private Student findStudentById(
            String sId) {

        if (isEmpty(sId)) {

            return null;
        }


        List<Student> students =
                studentDao.findAll();


        for (Student student : students) {

            if (student == null) {
                continue;
            }


            if (sId.trim().equals(
                    student.getSId())) {

                return student;
            }
        }


        return null;
    }


    /**
     * 统一处理学生和宿舍的性别表示。
     *
     * 男 / MALE → MALE
     * 女 / FEMALE → FEMALE
     */
    private String normalizeGender(
            String gender) {

        if (gender == null) {

            return null;
        }


        String value =
                gender.trim();


        if ("男".equals(value)
                || "MALE".equalsIgnoreCase(value)
                || "M".equalsIgnoreCase(value)) {

            return "MALE";
        }


        if ("女".equals(value)
                || "FEMALE".equalsIgnoreCase(value)
                || "F".equalsIgnoreCase(value)) {

            return "FEMALE";
        }


        return null;
    }


    // =====================================================
    // 判断字符串是否为空
    // =====================================================

    private boolean isEmpty(
            String value) {

        return value == null
                || value.trim().isEmpty();
    }

}