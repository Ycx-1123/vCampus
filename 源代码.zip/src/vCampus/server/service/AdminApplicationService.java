package vCampus.server.service;

import java.util.List;

import vCampus.common.enums.ApplicationType;
import vCampus.common.vo.DormApplication;

public interface AdminApplicationService {

    // 查询所有待审核申请
    List<DormApplication> queryPendingApplications();

    // 按申请类型查询
    List<DormApplication> queryApplicationsByType(
            ApplicationType type
    );

    // 审核通过
    boolean approveApplication(
            int applicationId,
            String adminId,
            String remark
    );

    // 审核拒绝
    boolean rejectApplication(
            int applicationId,
            String adminId,
            String remark
    );
}