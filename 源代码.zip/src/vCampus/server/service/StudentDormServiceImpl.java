package vCampus.server.service;

import java.util.List;

import vCampus.common.vo.Accommodation;
import vCampus.common.vo.Dormitory;
import vCampus.server.dao.AccommodationDAO;
import vCampus.server.dao.DormitoryDAO;

public class StudentDormServiceImpl
        implements StudentDormService {

    private DormitoryDAO dormitoryDAO;
    private AccommodationDAO accommodationDAO;

    public StudentDormServiceImpl() {

        dormitoryDAO =
                new DormitoryDAO();

        accommodationDAO =
                new AccommodationDAO();
    }


    // =====================================================
    // 查询全部宿舍
    // =====================================================

    @Override
    public List<Dormitory> queryAllDorm() {

        return dormitoryDAO.queryAll();
    }


    // =====================================================
    // 查询有空余床位的宿舍
    // =====================================================

    @Override
    public List<Dormitory> queryAvailableDorm() {

        return dormitoryDAO.queryAvailable();
    }


    // =====================================================
    // 查询学生当前住宿
    // =====================================================

    @Override
    public Accommodation queryMyDorm(
            String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {
            return null;
        }

        return accommodationDAO
                .findLatestByStudentId(
                        sId.trim()
                );
    }

    // =====================================================
    // 查询宿舍剩余床位数量
    // =====================================================

    @Override
    public int getRemainingBeds(
            String dormId) {

        if (dormId == null
                || dormId.trim().isEmpty()) {

            return -1;
        }

        Dormitory dorm =
                dormitoryDAO.findById(
                        dormId.trim()
                );

        if (dorm == null) {

            return -1;
        }

        return dorm.getCapacity()
                - dorm.getOccupied();
    }


    // =====================================================
    // 查询指定宿舍可用床位
    // =====================================================

    @Override
    public List<String> queryAvailableBeds(
            String dormId) {

        if (dormId == null
                || dormId.trim().isEmpty()) {

            return new java.util.ArrayList<>();
        }

        Dormitory dorm =
                dormitoryDAO.findById(
                        dormId.trim()
                );

        if (dorm == null) {

            return new java.util.ArrayList<>();
        }

        return accommodationDAO
                .queryAvailableBeds(
                        dorm.getDormId(),
                        dorm.getCapacity()
                );
    }

}