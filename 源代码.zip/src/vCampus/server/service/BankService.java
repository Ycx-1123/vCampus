package vCampus.server.service;

import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Logger; // ★ 新增：引入日志类

import vCampus.common.vo.BankAccount;
import vCampus.common.vo.BankTransaction;
import vCampus.server.dao.BankDao;

public class BankService {
	private final BankDao dao = new BankDao();
	private final Object lock = new Object();
	
	// ★ 新增：初始化 Logger
	private static final Logger logger = Logger.getLogger("vCampus.server.Server");

	public BankAccount getAccount(String holderCard) {
		if (blank(holderCard))
			return null;
		try {
			return dao.findByHolderCard(holderCard.trim());
		} catch (SQLException e) {
			return null;
		}
	}

	public BankAccount openAccount(String holderCard, String holderName, String bankPIN) {
		if (blank(holderCard) || blank(holderName) || !validPIN(bankPIN)) {
			return null;
		}

		try {
			if (dao.findByHolderCard(holderCard.trim()) != null) {
				return null;
			}

			BankAccount a = new BankAccount();
			a.setBankCardId(newBankCard());
			a.setHolderCard(holderCard.trim());
			a.setHolderName(holderName.trim());
			a.setBalance(0);
			a.setStatus(1);
			a.setCreateTime(new Date());
			a.setBankPIN(bankPIN);

			boolean success = dao.insertAccount(a);
			if (success) {
				// ★ 新增：开户成功日志
				logger.info("[Bank] 开户成功 - 持卡人: " + holderName + ", 一卡通: " + holderCard + ", 分配卡号: " + a.getBankCardId());
				return a;
			}
			return null;
		} catch (SQLException e) {
			return null;
		}
	}

	public List<BankTransaction> getTransactions(String holderCard) {
		BankAccount a = getAccount(holderCard);
		if (a == null)
			return Collections.emptyList();

		try {
			return dao.findTransactions(a.getBankCardId());
		} catch (SQLException e) {
			return Collections.emptyList();
		}
	}

	public boolean deposit(String holderCard, double amount, String bankPIN) {
		if (!validAmount(amount) || !validPIN(bankPIN))
			return false;

		BankAccount a = getAccount(holderCard);
		if (a == null)
			return false;

		if (!bankPIN.equals(a.getBankPIN()))
			return false;

		synchronized (lock) {
			try {
				boolean success = dao.deposit(a.getBankCardId(), amount, "DEPOSIT", "银行存款");
				if (success) {
					// ★ 新增：存款成功日志
					logger.info("[Bank] 存款成功 - 一卡通: " + holderCard + " | 金额: +" + amount + " | 银行卡号: " + a.getBankCardId());
				}
				return success;
			} catch (SQLException e) {
				return false;
			}
		}
	}

	public boolean withdraw(String holderCard, double amount, String bankPIN) {
		if (!validAmount(amount) || !validPIN(bankPIN))
			return false;

		BankAccount a = getAccount(holderCard);
		if (a == null)
			return false;

		if (!bankPIN.equals(a.getBankPIN()))
			return false;

		synchronized (lock) {
			try {
				boolean success = dao.withdraw(a.getBankCardId(), amount, "WITHDRAW", "银行取款");
				if (success) {
					// ★ 新增：取款成功日志
					logger.info("[Bank] 取款成功 - 一卡通: " + holderCard + " | 金额: -" + amount + " | 银行卡号: " + a.getBankCardId());
				}
				return success;
			} catch (SQLException e) {
				return false;
			}
		}
	}

	public boolean transfer(String holderCard, String targetBankCard, double amount, String bankPIN) {

		if (!validAmount(amount) || blank(targetBankCard) || !validPIN(bankPIN)) {
			return false;
		}

		BankAccount from = getAccount(holderCard);
		if (from == null)
			return false;

		if (!bankPIN.equals(from.getBankPIN()))
			return false;

		if (from.getBankCardId().equals(targetBankCard.trim())) {
			return false;
		}

		synchronized (lock) {
			try {
				boolean success = dao.transfer(from.getBankCardId(), targetBankCard.trim(), amount);
				if (success) {
					// ★ 新增：转账成功日志
					logger.info("[Bank] 转账成功 - 汇款人一卡通: " + holderCard + " | 收款卡号: " + targetBankCard + " | 金额: " + amount);
				}
				return success;
			} catch (SQLException e) {
				return false;
			}
		}
	}

	public boolean rechargeCampus(String holderCard, double amount, String bankPIN) {
		if (!validAmount(amount) || !validPIN(bankPIN))
			return false;

		BankAccount a = getAccount(holderCard);
		if (a == null)
			return false;

		if (!bankPIN.equals(a.getBankPIN()))
			return false;

		synchronized (lock) {
			try {
				boolean success = dao.rechargeCampus(a.getBankCardId(), holderCard, amount);
				if (success) {
					// ★ 新增：一卡通充值成功日志
					logger.info("[Bank] 一卡通充值成功 - 一卡通号: " + holderCard + " | 充值金额: " + amount);
				}
				return success;
			} catch (SQLException e) {
				return false;
			}
		}
	}

	public boolean payDorm(
	        String holderCard,
	        double amount,
	        int billId) {

	    if (!validAmount(amount)
	            || blank(holderCard)
	            || billId <= 0) {
	        return false;
	    }

	    synchronized (lock) {
	        try {
	            boolean success =
	                    dao.dormPayment(
	                            holderCard.trim(),
	                            amount,
	                            String.valueOf(billId)
	                    );

	            if (success) {
	                logger.info(
	                    "[Bank] 宿舍缴费成功 - 一卡通: "
	                    + holderCard
	                    + " | 账单ID: "
	                    + billId
	                    + " | 金额: "
	                    + amount
	                );
	            }

	            return success;

	        } catch (SQLException e) {
	            return false;
	        }
	    }
	}
	
	public boolean payDorm(
	        String holderCard,
	        double amount,
	        String bankPIN,
	        int billId) {

	    return payDorm(
	            holderCard,
	            amount,
	            billId
	    );
	}

	public List<BankAccount> getAllAccounts(String adminCard) {
		try {
			if (!dao.hasBankPermission(adminCard)) {
				return Collections.emptyList();
			}

			return dao.findAll();
		} catch (SQLException e) {
			return Collections.emptyList();
		}
	}

	public boolean setStatus(String adminCard, String bankCardId, int status) {
		if (blank(bankCardId) || (status != 0 && status != 1)) {
			return false;
		}

		try {
			if (!dao.hasBankPermission(adminCard))
				return false;

			boolean success = dao.setStatus(bankCardId.trim(), status);
			if (success) {
				// ★ 新增：冻结/解冻操作日志
				String action = (status == 1) ? "解除冻结" : "冻结";
				logger.info("[Bank] 账户状态变更 - 管理员: " + adminCard + " | 目标卡号: " + bankCardId + " | 动作: " + action);
			}
			return success;
		} catch (SQLException e) {
			return false;
		}
	}

	public boolean verifyPIN(String holderCard, String bankPIN) {
		if (blank(holderCard) || !validPIN(bankPIN)) {
			return false;
		}

		BankAccount a = getAccount(holderCard.trim());

		return a != null && a.getStatus() == 1 && bankPIN.equals(a.getBankPIN());
	}

	private String newBankCard() throws SQLException {
		for (int i = 0; i < 20; i++) {
			long value = ThreadLocalRandom.current().nextLong(0, 1000000000000000L);

			String card = "6222" + String.format("%015d", value);

			if (!dao.existsBankCard(card)) {
				return card;
			}
		}

		throw new SQLException("无法生成唯一银行卡号");
	}

	private boolean validPIN(String pin) {
		return pin != null && pin.matches("\\d{6}") && !"000000".equals(pin);
	}

	private boolean validAmount(double amount) {
		return amount > 0 && amount <= 1000000;
	}

	private boolean blank(String s) {
		return s == null || s.trim().isEmpty();
	}
}