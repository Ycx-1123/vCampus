package vCampus.server.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vCampus.common.enums.RepairStatus;
import vCampus.common.vo.Accommodation;
import vCampus.common.vo.DormRepair;
import vCampus.server.dao.AccommodationDAO;
import vCampus.server.dao.DormRepairDAO;

public class StudentRepairServiceImpl
        implements StudentRepairService {

    private DormRepairDAO dormRepairDAO;
    private AccommodationDAO accommodationDAO;


    public StudentRepairServiceImpl() {

        dormRepairDAO =
                new DormRepairDAO();

        accommodationDAO =
                new AccommodationDAO();
    }


    // =====================================================
    // 提交宿舍报修
    // =====================================================

    @Override
    public boolean submitRepair(
            String sId,
            String dormId,
            String description) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (dormId == null
                || dormId.trim().isEmpty()) {

            return false;
        }

        if (description == null
                || description.trim().isEmpty()) {

            return false;
        }


        String studentId =
                sId.trim();

        String repairDormId =
                dormId.trim();


        // 查询学生当前住宿
        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(
                                studentId
                        );


        // 当前没有住宿，不能提交宿舍报修
        if (current == null) {

            return false;
        }


        // 只能报修自己当前居住的宿舍
        if (!repairDormId.equals(
                current.getDormId())) {

            return false;
        }


        DormRepair repair =
                new DormRepair();


        repair.setsId(
                studentId
        );

        repair.setDormId(
                repairDormId
        );

        repair.setDescription(
                description.trim()
        );

        repair.setStatus(
                RepairStatus.PENDING
        );

        repair.setCreateTime(
                new Date()
        );


        return dormRepairDAO.insert(
                repair
        );
    }


    // =====================================================
    // 查询学生自己的报修记录
    // =====================================================

    @Override
    public List<DormRepair> queryMyRepairs(
            String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }


        return dormRepairDAO
                .queryByStudent(
                        sId.trim()
                );
    }


    // =====================================================
    // 取消报修
    // =====================================================

    @Override
    public boolean cancelRepair(
            String sId,
            int repairId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (repairId <= 0) {

            return false;
        }


        DormRepair repair =
                dormRepairDAO.findById(
                        repairId
                );


        // 报修不存在
        if (repair == null) {

            return false;
        }


        // 只能取消自己的报修
        if (!sId.trim().equals(
                repair.getsId())) {

            return false;
        }


        // 只有待处理状态才能取消
        if (repair.getStatus()
                != RepairStatus.PENDING) {

            return false;
        }


        return dormRepairDAO
                .updateStatus(
                        repairId,
                        RepairStatus.CANCELLED
                );
    }
}