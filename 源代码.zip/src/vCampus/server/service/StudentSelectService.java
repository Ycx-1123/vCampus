package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
//zhishiweileshangchuan
public class StudentSelectService {
    private CourseDao courseDao = new CourseDao();
    private CourseOfferingDao offeringDao = new CourseOfferingDao();
    private SelectDao selectDao = new SelectDao();
    private StudentDao studentDao = new StudentDao();
    private ClazzDao clazzDao = new ClazzDao();
    private MajorDao majorDao = new MajorDao();
    private ProgramDao programDao = new ProgramDao();
    private ProgramCourseDao programCourseDao = new ProgramCourseDao();
    private SelectRoundDao roundDao = new SelectRoundDao();

    // ============================================================
    // 一、学生选课：培养方案内 + recommendSemester 匹配当前学期
    // ============================================================

    public List<CourseDisplayDTO> getAvailableCoursesByRound(String studentId, String roundId, String campus) {
        List<CourseDisplayDTO> result = new ArrayList<>();
        try {
            SelectRound round = roundDao.getRoundById(roundId);
            if (round == null) return result;
            String st = round.getStatus();
            if (!"open".equals(st) && !"upcoming".equals(st)) return result;

            String semester = round.getSemester();
            List<CourseOffering> offerings = offeringDao.getOfferingsByRoundId(roundId);
            if (campus != null && !campus.isEmpty() && !"全部校区".equals(campus)) {
                offerings = offerings.stream()
                        .filter(o -> campus.equals(o.getCampus()))
                        .collect(Collectors.toList());
            }
            result = buildCourseDisplayList(studentId, semester, offerings);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 核心组装逻辑：
     *   1. 重修课（历史有 score < 60）：
     *      - 只显示"不在培养方案内 或 不在推荐学期"的
     *      - 跳过时间冲突
     *   2. 非重修课：
     *      - 必须在培养方案里
     *      - recommendSemester 必须匹配当前学期
     */
    private List<CourseDisplayDTO> buildCourseDisplayList(String studentId, String semester,
                                                          List<CourseOffering> offerings) throws SQLException {
        List<CourseDisplayDTO> result = new ArrayList<>();

        Student student = studentDao.findBySCard(studentId);
        if (student == null) return result;

        String majorName = getMajorNameByStudent(student);
        if (majorName == null || majorName.isEmpty()) return result;

        String grade = student.getEnrollYear();
        if (grade == null || grade.isEmpty()) return result;

        Program program = programDao.getProgramByMajorAndGrade(majorName, grade);
        if (program == null) return result;

        List<ProgramCourse> programCourses = programCourseDao.getByProgramId(program.getProgramId());
        Map<String, ProgramCourse> programCourseMap = new HashMap<>();
        for (ProgramCourse pc : programCourses) {
            programCourseMap.put(pc.getCourseId(), pc);
        }

        // 已选记录：只统计当前学期
        List<SelectRecord> selectedRecords = selectDao.getByStudentId(studentId);
        Set<String> selectedOfferingIds = new HashSet<>();
        Set<String> selectedCourseIds = new HashSet<>();
        for (SelectRecord record : selectedRecords) {
            if (!"selected".equals(record.getStatus())) continue;
            CourseOffering o = offeringDao.getOfferingById(record.getOfferingId());
            if (o == null) continue;
            if (!semester.equals(o.getSemester())) continue;
            selectedOfferingIds.add(record.getOfferingId());
            selectedCourseIds.add(o.getCourseId());
        }

        Set<String> failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);
        List<ScheduleDTO> selectedSchedules = getStudentSchedules(studentId, semester);

        for (CourseOffering offering : offerings) {
            String courseId = offering.getCourseId();
            boolean isRetake = failedCourseIds.contains(courseId);

            if (isRetake) {
                // 重修课：如果在培养方案里且是推荐学期，由"学生选课"显示，此处跳过
                ProgramCourse pc = programCourseMap.get(courseId);
                if (pc != null && semester.equals(pc.getRecommendSemester())) continue;
            } else {
                // 非重修课：必须在培养方案里 + recommendSemester 匹配
                ProgramCourse pc = programCourseMap.get(courseId);
                if (pc == null) continue;
                if (!semester.equals(pc.getRecommendSemester())) continue;
            }

            Course course = courseDao.getCourseById(courseId);
            if (course == null) continue;

            CourseDisplayDTO dto = new CourseDisplayDTO();
            dto.setCourseId(course.getCourseId());
            dto.setCourseName(course.getCourseName());
            dto.setCredit(course.getCredit());
            dto.setNature(getCourseNature(programCourses, courseId));
            dto.setDepartment(majorName);
            dto.setOfferingId(offering.getOfferingId());
            dto.setClassNum(extractClassNum(offering.getOfferingId()));
            dto.setTeacherId(offering.getTeacherId());
            dto.setTeacherName(offering.getTeacherName());
            dto.setSchedule(offering.getSchedule());
            dto.setClassroom(offering.getClassroom());
            dto.setSemester(offering.getSemester());
            dto.setCapacity(offering.getCapacity());
         // ★ 用实际选课记录数
            int realCount = countSelected(offering.getOfferingId());
            dto.setEnrolledCount(realCount);
            dto.setCourseType(course.getCategoryName() != null ? course.getCategoryName() : "未分类");
            dto.setCampus(offering.getCampus());
            dto.setFull(realCount >= offering.getCapacity());   // ★ full 也按实际人数判断

            boolean isSelected = selectedOfferingIds.contains(offering.getOfferingId());
            dto.setSelected(isSelected);
            dto.setSelectType(isRetake ? "retake" : "first");
            dto.setStatus(offering.getStatus());

            if (isSelected) {
                dto.setConflict(false);
                dto.setSameCourseConflict(false);
            } else {
                if (isRetake) dto.setConflict(false);
                else dto.setConflict(isTimeConflict(offering, selectedSchedules));
                dto.setSameCourseConflict(selectedCourseIds.contains(courseId));
            }
            result.add(dto);
        }
        return result;
    }

    // ============================================================
    // 二、重修课程：不在培养方案内（或不在推荐学期）+ 有不及格记录
    // ============================================================

    /**
     * 查询某轮次下的重修课程：该学生挂过科、且当前轮次有开课的课程
     * 不受培养方案限制
     */
    public List<CourseDisplayDTO> getRetakeCoursesByRound(String studentId, String roundId, String campus) {
        List<CourseDisplayDTO> result = new ArrayList<>();
        try {
            SelectRound round = roundDao.getRoundById(roundId);
            if (round == null) return result;

            String st = round.getStatus();
            if (!"open".equals(st) && !"upcoming".equals(st)) return result;

            String semester = round.getSemester();

            // 该生所有挂科课程ID
            Set<String> failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);
            if (failedCourseIds.isEmpty()) return result;

            List<CourseOffering> offerings = offeringDao.getOfferingsByRoundId(roundId);

            // 只保留挂科的课
            offerings = offerings.stream()
                    .filter(o -> failedCourseIds.contains(o.getCourseId()))
                    .collect(Collectors.toList());

            if (campus != null && !campus.isEmpty() && !"全部校区".equals(campus)) {
                offerings = offerings.stream()
                        .filter(o -> campus.equals(o.getCampus()))
                        .collect(Collectors.toList());
            }

            result = buildAllCourseDisplayList(studentId, semester, offerings);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    private List<CourseDisplayDTO> buildRetakeCourseDisplayList(String studentId, String semester,
                                                                 List<CourseOffering> offerings) throws SQLException {
        List<CourseDisplayDTO> result = new ArrayList<>();

        Student student = studentDao.findBySCard(studentId);
        if (student == null) return result;

        String majorName = getMajorNameByStudent(student);
        if (majorName == null || majorName.isEmpty()) return result;

        String grade = student.getEnrollYear();
        if (grade == null || grade.isEmpty()) return result;

        Program program = programDao.getProgramByMajorAndGrade(majorName, grade);
        if (program == null) return result;

        List<ProgramCourse> programCourses = programCourseDao.getByProgramId(program.getProgramId());
        Map<String, ProgramCourse> programCourseMap = new HashMap<>();
        for (ProgramCourse pc : programCourses) {
            programCourseMap.put(pc.getCourseId(), pc);
        }

        List<SelectRecord> selectedRecords = selectDao.getByStudentId(studentId);
        Set<String> selectedOfferingIds = new HashSet<>();
        Set<String> selectedCourseIds = new HashSet<>();
        for (SelectRecord record : selectedRecords) {
            if (!"selected".equals(record.getStatus())) continue;
            CourseOffering o = offeringDao.getOfferingById(record.getOfferingId());
            if (o == null) continue;
            if (!semester.equals(o.getSemester())) continue;
            selectedOfferingIds.add(record.getOfferingId());
            selectedCourseIds.add(o.getCourseId());
        }

        Set<String> failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);

        for (CourseOffering offering : offerings) {
            String courseId = offering.getCourseId();

            if (!failedCourseIds.contains(courseId)) continue;

            // 培养方案里且是推荐学期 → 归"学生选课"，不归重修
            ProgramCourse pc = programCourseMap.get(courseId);
            if (pc != null && semester.equals(pc.getRecommendSemester())) continue;

            Course course = courseDao.getCourseById(courseId);
            if (course == null) continue;

            CourseDisplayDTO dto = new CourseDisplayDTO();
            dto.setCourseId(course.getCourseId());
            dto.setCourseName(course.getCourseName());
            dto.setCredit(course.getCredit());
            dto.setNature("重修");
            dto.setDepartment(majorName);
            dto.setOfferingId(offering.getOfferingId());
            dto.setClassNum(extractClassNum(offering.getOfferingId()));
            dto.setTeacherId(offering.getTeacherId());
            dto.setTeacherName(offering.getTeacherName());
            dto.setSchedule(offering.getSchedule());
            dto.setClassroom(offering.getClassroom());
            dto.setSemester(offering.getSemester());
            dto.setCapacity(offering.getCapacity());
            dto.setEnrolledCount(offering.getEnrolledCount());
            dto.setCourseType(course.getCategoryName() != null ? course.getCategoryName() : "未分类");
            dto.setCampus(offering.getCampus());
            dto.setFull(offering.getEnrolledCount() >= offering.getCapacity());

            boolean isSelected = selectedOfferingIds.contains(offering.getOfferingId());
            dto.setSelected(isSelected);
            dto.setSelectType("retake");
            dto.setStatus(offering.getStatus());

            if (isSelected) {
                dto.setConflict(false);
                dto.setSameCourseConflict(false);
            } else {
                dto.setConflict(false);  // 重修跳过时间冲突
                dto.setSameCourseConflict(selectedCourseIds.contains(courseId));
            }
            result.add(dto);
        }
        return result;
    }

    // ============================================================
    // 三、全校课程查询：该轮次下所有开课班级，不做过滤
    // ============================================================

    public List<CourseDisplayDTO> getAllCoursesByRound(String studentId, String roundId, String campus) {
        List<CourseDisplayDTO> result = new ArrayList<>();
        try {
            SelectRound round = roundDao.getRoundById(roundId);
            if (round == null) return result;
            String st = round.getStatus();
            if (!"open".equals(st) && !"upcoming".equals(st)) return result;

            String semester = round.getSemester();
            List<CourseOffering> offerings = offeringDao.getOfferingsByRoundId(roundId);
            if (campus != null && !campus.isEmpty() && !"全部校区".equals(campus)) {
                offerings = offerings.stream()
                        .filter(o -> campus.equals(o.getCampus()))
                        .collect(Collectors.toList());
            }
            result = buildAllCourseDisplayList(studentId, semester, offerings);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    private List<CourseDisplayDTO> buildAllCourseDisplayList(String studentId, String semester,
                                                              List<CourseOffering> offerings) throws SQLException {
        List<CourseDisplayDTO> result = new ArrayList<>();

        Student student = studentDao.findBySCard(studentId);
        String majorName = "";
        if (student != null) {
            String m = getMajorNameByStudent(student);
            if (m != null) majorName = m;
        }

        List<SelectRecord> selectedRecords = selectDao.getByStudentId(studentId);
        Set<String> selectedOfferingIds = new HashSet<>();
        Set<String> selectedCourseIds = new HashSet<>();
        for (SelectRecord record : selectedRecords) {
            if (!"selected".equals(record.getStatus())) continue;
            CourseOffering o = offeringDao.getOfferingById(record.getOfferingId());
            if (o == null) continue;
            if (!semester.equals(o.getSemester())) continue;
            selectedOfferingIds.add(record.getOfferingId());
            selectedCourseIds.add(o.getCourseId());
        }

        Set<String> failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);
        List<ScheduleDTO> selectedSchedules = getStudentSchedules(studentId, semester);

        for (CourseOffering offering : offerings) {
            String courseId = offering.getCourseId();
            Course course = courseDao.getCourseById(courseId);
            if (course == null) continue;

            CourseDisplayDTO dto = new CourseDisplayDTO();
            dto.setCourseId(course.getCourseId());
            dto.setCourseName(course.getCourseName());
            dto.setCredit(course.getCredit());
            dto.setNature("—");
            dto.setDepartment(majorName);
            dto.setOfferingId(offering.getOfferingId());
            dto.setClassNum(extractClassNum(offering.getOfferingId()));
            dto.setTeacherId(offering.getTeacherId());
            dto.setTeacherName(offering.getTeacherName());
            dto.setSchedule(offering.getSchedule());
            dto.setClassroom(offering.getClassroom());
            dto.setSemester(offering.getSemester());
            dto.setCapacity(offering.getCapacity());
            int realCount = countSelected(offering.getOfferingId());
            dto.setEnrolledCount(realCount);
            dto.setCourseType(course.getCategoryName() != null ? course.getCategoryName() : "未分类");
            dto.setCampus(offering.getCampus());
            dto.setFull(realCount >= offering.getCapacity());

            boolean isSelected = selectedOfferingIds.contains(offering.getOfferingId());
            dto.setSelected(isSelected);

            boolean isRetake = failedCourseIds.contains(courseId);
            dto.setSelectType(isRetake ? "retake" : "first");
            dto.setStatus(offering.getStatus());

            if (isSelected) {
                dto.setConflict(false);
                dto.setSameCourseConflict(false);
            } else {
                if (isRetake) dto.setConflict(false);
                else dto.setConflict(isTimeConflict(offering, selectedSchedules));
                dto.setSameCourseConflict(selectedCourseIds.contains(courseId));
            }
            result.add(dto);
        }
        return result;
    }

    // ============================================================
    // 四、已选课程
    // ============================================================

    public List<CourseDisplayDTO> getMySelectedCourses(String studentId, String semester) {
        List<CourseDisplayDTO> result = new ArrayList<>();
        try {
            for (SelectRecord record : selectDao.getByStudentId(studentId)) {
                CourseOffering offering = offeringDao.getOfferingById(record.getOfferingId());
                if (offering == null) continue;
                if (!offering.getSemester().equals(semester)) continue;

                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                CourseDisplayDTO dto = new CourseDisplayDTO();
                dto.setCourseId(course.getCourseId());
                dto.setCourseName(course.getCourseName());
                dto.setCredit(course.getCredit());
                dto.setTeacherName(offering.getTeacherName());
                dto.setSchedule(offering.getSchedule());
                dto.setClassroom(offering.getClassroom());
                dto.setOfferingId(offering.getOfferingId());
                dto.setSelected(true);
                dto.setSelectType(record.getSelectType());
                dto.setClassNum(extractClassNum(offering.getOfferingId()));
                dto.setSemester(offering.getSemester());
                if (record.getScore() != null) dto.setScore(record.getScore());
                result.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    // ============================================================
    // 五、提交选课
    // ============================================================

    public SmartSelectResultDTO submitAllCourses(String studentId, List<String> offeringIds, String semester) {
        SmartSelectResultDTO result = new SmartSelectResultDTO();
        List<SelectResultDetail> details = new ArrayList<>();

        if (offeringIds == null || offeringIds.isEmpty()) {
            result.setSuccess(false);
            result.setMessage("没有选择任何课程");
            result.setDetails(details);
            return result;
        }

        List<String> uniqueIds = new ArrayList<>();
        Set<String> courseIdSet = new HashSet<>();
        for (String offeringId : offeringIds) {
            try {
                CourseOffering offering = offeringDao.getOfferingById(offeringId);
                if (offering != null && !courseIdSet.contains(offering.getCourseId())) {
                    courseIdSet.add(offering.getCourseId());
                    uniqueIds.add(offeringId);
                }
            } catch (SQLException e) { e.printStackTrace(); }
        }

        Date submitTime = new Date();
        List<ScheduleDTO> selectedSchedules = getStudentSchedules(studentId, semester);

        // ★ 提前算好挂科集合，用于判断本次提交的课是不是重修
        Set<String> failedCourseIds;
        try {
            failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);
        } catch (SQLException e) {
            failedCourseIds = new HashSet<>();
        }

        int successCount = 0, failCount = 0;

        for (String offeringId : uniqueIds) {
            SelectResultDetail detail = selectCourseDirect(studentId, offeringId, submitTime, selectedSchedules, semester);
            if (detail.isSuccess()) {
                successCount++;
                try {
                    CourseOffering offering = offeringDao.getOfferingById(offeringId);
                    if (offering != null && offering.getSchedule() != null) {
                        // ★ 关键：只有非重修课才加入冲突检测列表
                        boolean isRetake = failedCourseIds.contains(offering.getCourseId());
                        if (!isRetake) {
                            ScheduleDTO ns = new ScheduleDTO();
                            ns.setSchedule(offering.getSchedule());
                            selectedSchedules.add(ns);
                        }
                    }
                } catch (SQLException e) { e.printStackTrace(); }
            } else {
                failCount++;
            }
            details.add(detail);
        }

        result.setSuccess(true);
        result.setTotalCount(uniqueIds.size());
        result.setSuccessCount(successCount);
        result.setFailCount(failCount);
        result.setDetails(details);
        result.setMessage(String.format("提交完成：成功 %d 门，失败 %d 门", successCount, failCount));
        return result;
    }

    private SelectResultDetail selectCourseDirect(String studentId, String offeringId,
            Date submitTime, List<ScheduleDTO> existingSchedules,
            String semester) {
SelectResultDetail detail = new SelectResultDetail();
detail.setOfferingId(offeringId);

try {
// 1. 重复选课校验
if (selectDao.existsSelectRecord(studentId, offeringId)) {
detail.setSuccess(false);
detail.setMessage("您已选过该课程，不能重复选择");
return detail;
}

// 2. 开课班级存在校验
CourseOffering offering = offeringDao.getOfferingById(offeringId);
if (offering == null) {
detail.setSuccess(false);
detail.setMessage("该开课班级不存在");
return detail;
}

// 3. 学期匹配校验
if (!offering.getSemester().equals(semester)) {
detail.setSuccess(false);
detail.setMessage("课程不在当前学期");
return detail;
}

// 4. ★ 轮次状态校验：轮次不是 open 就禁止提交
try {
SelectRound round = roundDao.getRoundById(offering.getRoundId());
if (round != null && !"open".equals(round.getStatus())) {
detail.setSuccess(false);
detail.setMessage("当前选课轮次已关闭");
return detail;
}
} catch (SQLException ignore) {
// 查不到轮次不影响主流程，放行
}

// 5. 课程信息完整性（教师/时间/教室是否已填）
boolean incomplete = (offering.getTeacherName() == null || offering.getTeacherName().isEmpty())
|| (offering.getSchedule() == null || offering.getSchedule().isEmpty())
|| (offering.getClassroom() == null || offering.getClassroom().isEmpty());

// 6. 关闭状态校验（信息未完善的课即使 closed 也放行）
if ("closed".equals(offering.getStatus()) && !incomplete) {
detail.setSuccess(false);
detail.setMessage("该课程已关闭选课");
return detail;
}

// 7. 名额校验
if (offering.getEnrolledCount() >= offering.getCapacity()) {
detail.setSuccess(false);
detail.setMessage("该课程名额已满");
return detail;
}

// 8. 课程模板存在校验
Course course = courseDao.getCourseById(offering.getCourseId());
if (course == null) {
detail.setSuccess(false);
detail.setMessage("课程不存在");
return detail;
}

// 9. 同课程其他教学班校验（只统计当前学期）
for (SelectRecord record : selectDao.getByStudentId(studentId)) {
if (!"selected".equals(record.getStatus())) continue;
CourseOffering existing = offeringDao.getOfferingById(record.getOfferingId());
if (existing == null) continue;
if (!semester.equals(existing.getSemester())) continue;
if (existing.getCourseId().equals(offering.getCourseId())) {
detail.setSuccess(false);
detail.setMessage("同一门课程已选其他教学班");
return detail;
}
}

// 10. 重修判定
boolean isRetake = selectDao.hasFailedCourse(studentId, offering.getCourseId(), semester);

// 11. 时间冲突校验（重修豁免；信息未完善的课跳过）
if (!isRetake && !incomplete && isTimeConflict(offering, existingSchedules)) {
detail.setSuccess(false);
detail.setMessage("与已选课程时间冲突");
return detail;
}

// 12. ★ 乐观锁扣减之前，再查一次开课是否仍然存在（防管理员删课）
CourseOffering latest = offeringDao.getOfferingById(offeringId);
if (latest == null) {
detail.setSuccess(false);
detail.setMessage("该课程已被管理员删除，无法选课");
return detail;
}

String selectType = isRetake ? "retake" : "first";

// 13. 乐观锁扣减容量
boolean lockSuccess = offeringDao.decrementCapacity(offeringId, offering.getVersion());
if (!lockSuccess) {
detail.setSuccess(false);
detail.setMessage("很遗憾，名额已被抢完，请刷新后重试");
return detail;
}

// 14. ★ 写入前再兜底校验一次（极端并发下删课与插入交错）
if (offeringDao.getOfferingById(offeringId) == null) {
// 乐观锁已经扣减成功，但开课被删了：回滚容量
try {
offeringDao.updateEnrolledCount(offeringId, -1);
} catch (SQLException ignore) { }
detail.setSuccess(false);
detail.setMessage("该课程已被管理员删除，无法选课");
return detail;
}

// 15. 写入选课记录
SelectRecord record = new SelectRecord();
record.setStudentId(studentId);
record.setOfferingId(offeringId);
record.setSelectTime(submitTime);
record.setStatus("selected");
record.setSelectType(selectType);
selectDao.insertSelectRecord(record);

detail.setCourseName(course.getCourseName());
detail.setSuccess(true);
detail.setMessage("选课成功（" + ("first".equals(selectType) ? "首修" : "重修") + "）");
} catch (SQLException e) {
e.printStackTrace();
detail.setSuccess(false);
detail.setMessage("系统异常：" + e.getMessage());
}
return detail;
}

    public String dropCourse(String studentId, String offeringId) {
        try {
            if (!selectDao.existsSelectRecord(studentId, offeringId)) return "您未选该课程，无法退课";
            selectDao.deleteSelectRecord(studentId, offeringId);
            offeringDao.updateEnrolledCount(offeringId, -1);
            return "退课成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "退课失败：" + e.getMessage();
        }
    }

    // ============================================================
    // 辅助方法
    // ============================================================

    private List<ScheduleDTO> getStudentSchedules(String studentId, String semester) {
        List<ScheduleDTO> result = new ArrayList<>();
        try {
            // ★ 用挂科集合判断重修，与 buildCourseDisplayList 里的 isRetake 判断保持完全一致
            Set<String> failedCourseIds = selectDao.getFailedCourseIds(studentId, semester);

            for (SelectRecord record : selectDao.getByStudentId(studentId)) {
                if (!"selected".equals(record.getStatus())) continue;

                CourseOffering offering = offeringDao.getOfferingById(record.getOfferingId());
                if (offering == null) continue;
                if (!offering.getSemester().equals(semester)) continue;

                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                // ★ 关键：重修课不参与时间冲突检测，直接跳过
                // 重修课允许与同学期课程时间冲突，因此不能放进"已选课表"里
                boolean isRetake = failedCourseIds.contains(offering.getCourseId());
                if (isRetake) continue;

                ScheduleDTO dto = new ScheduleDTO();
                dto.setCourseId(course.getCourseId());
                dto.setCourseName(course.getCourseName());
                dto.setTeacherName(offering.getTeacherName());
                dto.setClassroom(offering.getClassroom());
                dto.setSchedule(offering.getSchedule());
                dto.setOfferingId(offering.getOfferingId());
                result.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    private String getMajorNameByStudent(Student student) {
        String clazzId = student.getClazzid();
        if (clazzId == null || clazzId.isEmpty()) return null;

        Clazz clazz = clazzDao.findById(clazzId);
        if (clazz == null) return null;

        String majorId = clazz.getMajorid();
        if (majorId == null || majorId.isEmpty()) return null;

        Major major = majorDao.findById(majorId);
        return major != null ? major.getMajorname() : null;
    }

    private boolean isTimeConflict(CourseOffering offering, List<ScheduleDTO> existingSchedules) {
        if (offering.getSchedule() == null || offering.getSchedule().isEmpty()) return false;
        for (ScheduleDTO existing : existingSchedules) {
            if (existing.getSchedule() != null && existing.getSchedule().equals(offering.getSchedule())) {
                return true;
            }
        }
        return false;
    }

    private String getCourseNature(List<ProgramCourse> programCourses, String courseId) {
        for (ProgramCourse pc : programCourses) {
            if (pc.getCourseId().equals(courseId)) return pc.getCourseType();
        }
        return "重修";
    }

    private String extractClassNum(String offeringId) {
        if (offeringId == null) return "01";
        int idx = offeringId.lastIndexOf("-");
        if (idx > 0 && idx < offeringId.length() - 1) return offeringId.substring(idx + 1);
        if (offeringId.length() >= 2) {
            String suffix = offeringId.substring(offeringId.length() - 2);
            if (suffix.matches("\\d{2}")) return suffix;
        }
        return "01";
    }
    private int countSelected(String offeringId) {
        try {
            int cnt = 0;
            for (SelectRecord r : selectDao.getByOfferingId(offeringId)) {
                if ("selected".equals(r.getStatus())) cnt++;
            }
            return cnt;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
}