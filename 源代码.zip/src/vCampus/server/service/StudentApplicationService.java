package vCampus.server.service;

import java.util.List;

import vCampus.common.enums.ApplicationType;
import vCampus.common.vo.DormApplication;

public interface StudentApplicationService {

    // 提交调宿申请
    boolean applyDormChange(
            String sId,
            String targetDormId,
            String targetBedNumber,
            String reason
    );

    // 提交退宿申请
    boolean applyCheckout(
            String sId,
            ApplicationType type,
            String reason
    );

    // 查询当前学生自己提交的全部申请
    List<DormApplication> queryMyApplications(
            String sId
    );

    // 取消指定申请
    boolean cancelApplication(
            String sId,
            int applicationId
    );
}