package vCampus.server.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vCampus.common.enums.FeeStatus;
import vCampus.common.vo.DormFeeBill;
import vCampus.server.dao.DormFeeBillDAO;

public class AdminFeeServiceImpl
        implements AdminFeeService {

    private DormFeeBillDAO dormFeeBillDAO;

    public AdminFeeServiceImpl() {

        dormFeeBillDAO =
                new DormFeeBillDAO();
    }


    @Override
    public boolean createBill(
            String sId,
            int accommodationId,
            String academicYear,
            String semester,
            double amount,
            Date dueDate) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (accommodationId <= 0) {

            return false;
        }

        if (academicYear == null
                || academicYear.trim().isEmpty()) {

            return false;
        }

        if (semester == null
                || semester.trim().isEmpty()) {

            return false;
        }

        if (amount <= 0
                || dueDate == null) {

            return false;
        }


        if (dormFeeBillDAO.existsBill(
                accommodationId,
                academicYear.trim(),
                semester.trim())) {

            return false;
        }


        DormFeeBill bill =
                new DormFeeBill();

        bill.setsId(
                sId.trim()
        );

        bill.setAccommodationId(
                accommodationId
        );

        bill.setAcademicYear(
                academicYear.trim()
        );

        bill.setSemester(
                semester.trim()
        );

        bill.setAmount(
                amount
        );

        bill.setPaidAmount(
                0
        );

        bill.setDueDate(
                dueDate
        );

        bill.setStatus(
                FeeStatus.UNPAID
        );

        bill.setCreateTime(
                new Date()
        );


        return dormFeeBillDAO.insert(
                bill
        );
    }


    @Override
    public int batchCreateBills(
            List<DormFeeBill> bills) {

        if (bills == null
                || bills.isEmpty()) {

            return 0;
        }

        int count = 0;


        for (DormFeeBill bill :
                bills) {

            if (bill == null) {

                continue;
            }

            if (createBill(
                    bill.getsId(),
                    bill.getAccommodationId(),
                    bill.getAcademicYear(),
                    bill.getSemester(),
                    bill.getAmount(),
                    bill.getDueDate())) {

                count++;
            }
        }

        return count;
    }


    @Override
    public List<DormFeeBill>
            queryAllBills() {

        List<DormFeeBill> bills =
                dormFeeBillDAO.queryAll();

        Date now = new Date();

        for (DormFeeBill bill : bills) {

            if (bill.getStatus() == FeeStatus.CANCELLED
                    || bill.getStatus() == FeeStatus.PAID) {
                continue;
            }

            if (bill.getPaidAmount() < bill.getAmount()
                    && bill.getDueDate() != null
                    && bill.getDueDate().before(now)) {

                if (bill.getStatus() != FeeStatus.OVERDUE) {

                    dormFeeBillDAO.updateStatus(
                            bill.getBillId(),
                            FeeStatus.OVERDUE
                    );

                    bill.setStatus(
                            FeeStatus.OVERDUE
                    );
                }
            }
        }

        return bills;
    }

    @Override
    public DormFeeBill queryBillById(
            int billId) {

        if (billId <= 0) {

            return null;
        }

        return dormFeeBillDAO.findById(
                billId
        );
    }


    @Override
    public List<DormFeeBill>
            queryStudentBills(
                    String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }

        return dormFeeBillDAO
                .queryByStudent(
                        sId.trim()
                );
    }


    @Override
    public List<DormFeeBill>
            queryUnpaidBills() {

        return dormFeeBillDAO
                .queryUnpaid();
    }


    @Override
    public boolean adjustBill(
            int billId,
            double amount) {

        if (billId <= 0
                || amount <= 0) {

            return false;
        }

        DormFeeBill bill =
                dormFeeBillDAO.findById(
                        billId
                );

        if (bill == null) {

            return false;
        }

        if (bill.getStatus()
                == FeeStatus.CANCELLED) {

            return false;
        }

        if (amount <
                bill.getPaidAmount()) {

            return false;
        }


        if (!dormFeeBillDAO.updateAmount(
                billId,
                amount)) {

            return false;
        }


        if (bill.getPaidAmount()
                >= amount) {

            return dormFeeBillDAO
                    .updateStatus(
                            billId,
                            FeeStatus.PAID
                    );
        }


        // 原来已经逾期，调整金额后仍保持逾期
        if (bill.getStatus()
                == FeeStatus.OVERDUE) {

            return dormFeeBillDAO
                    .updateStatus(
                            billId,
                            FeeStatus.OVERDUE
                    );
        }


        if (bill.getPaidAmount() > 0) {

            return dormFeeBillDAO
                    .updateStatus(
                            billId,
                            FeeStatus.PARTIALLY_PAID
                    );
        }


        return dormFeeBillDAO
                .updateStatus(
                        billId,
                        FeeStatus.UNPAID
                );
    }


    @Override
    public boolean cancelBill(
            int billId) {

        if (billId <= 0) {

            return false;
        }

        DormFeeBill bill =
                dormFeeBillDAO.findById(
                        billId
                );

        if (bill == null) {

            return false;
        }

        if (bill.getStatus()
                == FeeStatus.CANCELLED) {

            return false;
        }

        if (bill.getPaidAmount() > 0) {

            return false;
        }

        return dormFeeBillDAO
                .updateStatus(
                        billId,
                        FeeStatus.CANCELLED
                );
    }
}