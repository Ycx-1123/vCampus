package vCampus.server.service;

import java.util.List;
import vCampus.common.vo.Department;
import vCampus.common.vo.Major;
import vCampus.server.dao.DepartmentDao;

public class DepartmentService {
	private DepartmentDao departmentDao = new DepartmentDao();
	
	public List<Department> findAllDepartment() {
		return departmentDao.findAll();
	}
	
	public Department findDepartmentById(String deptid) {
		return departmentDao.findById(deptid);
	}
	
	public boolean addDepartment(Department dept) {
		Department exist = departmentDao.findById(dept.getDeptid());
		if(exist != null){
			return false;
		}
		return departmentDao.add(dept);
	}
	
	public boolean updateDepartment(Department dept) {
		return departmentDao.update(dept);
	}
	
	//预留扩展：后面可加规则：院系下还有专业/班级则禁止删除
	public boolean deleteDepartment(String deptid) {
		MajorService majorService = new MajorService();
		List<Major> majorListUnderDept = majorService.findMajorByDeptId(deptid);
		
		if(!majorListUnderDept.isEmpty()) {
			return false;
		}
		return departmentDao.delete(deptid);
	}
}
