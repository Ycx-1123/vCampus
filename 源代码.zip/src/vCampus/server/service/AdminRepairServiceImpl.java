package vCampus.server.service;

import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.RepairStatus;
import vCampus.common.vo.DormRepair;
import vCampus.server.dao.DormRepairDAO;

public class AdminRepairServiceImpl
        implements AdminRepairService {

    private DormRepairDAO dormRepairDAO;

    public AdminRepairServiceImpl() {

        dormRepairDAO =
                new DormRepairDAO();
    }


    // =====================================================
    // 查询全部报修
    // =====================================================

    @Override
    public List<DormRepair> queryAllRepairs() {

        return dormRepairDAO.queryAll();
    }


    // =====================================================
    // 根据编号查询报修
    // =====================================================

    @Override
    public DormRepair queryRepairById(
            int repairId) {

        if (repairId <= 0) {

            return null;
        }

        return dormRepairDAO.findById(
                repairId
        );
    }


    // =====================================================
    // 修改报修状态
    // =====================================================

    @Override
    public boolean updateRepairStatus(
            int repairId,
            RepairStatus status) {

        if (repairId <= 0) {
            return false;
        }

        if (status == null) {
            return false;
        }

        DormRepair repair =
                dormRepairDAO.findById(
                        repairId
                );

        if (repair == null) {
            return false;
        }

        RepairStatus currentStatus =
                repair.getStatus();

        if (currentStatus == null) {
            return false;
        }

        // 状态相同，不需要重复修改
        if (currentStatus == status) {
            return false;
        }

        // 已完成和已取消属于终态
        if (currentStatus == RepairStatus.FINISHED
                || currentStatus == RepairStatus.CANCELLED) {

            return false;
        }

        // PENDING 可以进入 PROCESSING 或 CANCELLED
        if (currentStatus == RepairStatus.PENDING) {

            if (status != RepairStatus.PROCESSING
                    && status != RepairStatus.CANCELLED) {

                return false;
            }
        }

        // PROCESSING 可以进入 FINISHED 或 CANCELLED
        if (currentStatus == RepairStatus.PROCESSING) {

            if (status != RepairStatus.FINISHED
                    && status != RepairStatus.CANCELLED) {

                return false;
            }
        }

        return dormRepairDAO.updateStatus(
                repairId,
                status
        );
    }
}