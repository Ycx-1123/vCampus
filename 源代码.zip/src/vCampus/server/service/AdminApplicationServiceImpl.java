package vCampus.server.service;

import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.ApplicationStatus;
import vCampus.common.enums.ApplicationType;
import vCampus.common.vo.DormApplication;
import vCampus.server.dao.DormApplicationDAO;

public class AdminApplicationServiceImpl
        implements AdminApplicationService {

    private DormApplicationDAO dormApplicationDAO;

    private AdminAccommodationService
            adminAccommodationService;


    public AdminApplicationServiceImpl() {

        dormApplicationDAO =
                new DormApplicationDAO();

        adminAccommodationService =
                new AdminAccommodationServiceImpl();
    }


    // =====================================================
    // 查询所有待审核申请
    // =====================================================

    @Override
    public List<DormApplication>
            queryPendingApplications() {

        return dormApplicationDAO
                .queryPending();
    }


    // =====================================================
    // 按申请类型查询
    // =====================================================

    @Override
    public List<DormApplication>
            queryApplicationsByType(
                    ApplicationType type) {

        if (type == null) {

            return new ArrayList<>();
        }

        return dormApplicationDAO
                .queryByType(type);
    }


    // =====================================================
    // 审核通过
    // =====================================================

    @Override
    public boolean approveApplication(
            int applicationId,
            String adminId,
            String remark) {

        if (applicationId <= 0) {

            return false;
        }


        if (adminId == null
                || adminId.trim().isEmpty()) {

            return false;
        }


        // 查询申请
        DormApplication application =
                dormApplicationDAO.findById(
                        applicationId
                );

        if (application == null) {

            return false;
        }


        // 只有待审核申请才能通过
        if (application.getStatus()
                != ApplicationStatus.PENDING) {

            return false;
        }


        String sId =
                application.getsId();

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }


        ApplicationType type =
                application.getType();


        // =================================================
        // 调宿申请
        // =================================================

        if (type
                == ApplicationType.CHANGE_DORM) {

            String targetDormId =
                    application.getTargetDormId();

            String targetBedNumber =
                    application.getTargetBedNumber();


            if (targetDormId == null
                    || targetDormId.trim()
                            .isEmpty()) {

                return false;
            }


            if (targetBedNumber == null
                    || targetBedNumber.trim()
                            .isEmpty()) {

                return false;
            }


            String result =
                    adminAccommodationService
                            .executeDormChange(
                                    sId,
                                    targetDormId,
                                    targetBedNumber
                            );


            if (result == null
                    || !result.contains("成功")) {

                return false;
            }
        }


        // =================================================
        // 在校生退宿
        // =================================================

        else if (type
                == ApplicationType.CHECKOUT_CURRENT) {

            String result =
                    adminAccommodationService
                            .executeCheckOut(
                                    sId
                            );


            if (result == null
                    || !result.contains("成功")) {

                return false;
            }
        }


        // =================================================
        // 毕业生退宿
        // =================================================

        else if (type
                == ApplicationType.CHECKOUT_GRADUATE) {

            String result =
                    adminAccommodationService
                            .executeCheckOut(
                                    sId
                            );


            if (result == null
                    || !result.contains("成功")) {

                return false;
            }
        }


        // =================================================
        // 实际住宿业务执行成功后，
        // 再修改申请状态
        // =================================================

        return dormApplicationDAO
                .updateStatus(
                        applicationId,
                        ApplicationStatus.APPROVED,
                        adminId,
                        remark
                );
    }


    // =====================================================
    // 审核拒绝
    // =====================================================

    @Override
    public boolean rejectApplication(
            int applicationId,
            String adminId,
            String remark) {

        if (applicationId <= 0) {

            return false;
        }


        if (adminId == null
                || adminId.trim().isEmpty()) {

            return false;
        }


        DormApplication application =
                dormApplicationDAO.findById(
                        applicationId
                );

        if (application == null) {

            return false;
        }


        if (application.getStatus()
                != ApplicationStatus.PENDING) {

            return false;
        }


        return dormApplicationDAO
                .updateStatus(
                        applicationId,
                        ApplicationStatus.REJECTED,
                        adminId,
                        remark
                );
    }

}