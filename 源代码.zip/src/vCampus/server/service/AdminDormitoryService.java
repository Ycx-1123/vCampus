package vCampus.server.service;

import java.util.List;

import vCampus.common.vo.Dormitory;

public interface AdminDormitoryService {

    // 查询全部宿舍
    List<Dormitory> queryAllDorm();

    // 查询有空余床位的宿舍
    List<Dormitory> queryAvailableDorm();

    // 新增宿舍
    boolean addDorm(Dormitory dorm);

    // 修改宿舍
    boolean updateDorm(Dormitory dorm);

    // 删除宿舍
    boolean deleteDorm(String dormId);
}