package vCampus.server.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import vCampus.common.enums.FeeStatus;
import vCampus.common.enums.PaymentMethod;
import vCampus.common.enums.PaymentStatus;
import vCampus.common.vo.DormFeeBill;
import vCampus.common.vo.DormPaymentRecord;
import vCampus.common.vo.Student;
import vCampus.server.dao.DormFeeBillDAO;
import vCampus.server.dao.DormPaymentRecordDAO;
import vCampus.server.dao.StudentDao;

public class StudentPaymentServiceImpl
        implements StudentPaymentService {

    private static final double EPS =
            0.000001;

    private DormFeeBillDAO dormFeeBillDAO;

    private DormPaymentRecordDAO
            dormPaymentRecordDAO;

    private StudentDao studentDao;

    private BankService bankService;


    public StudentPaymentServiceImpl() {

        dormFeeBillDAO =
                new DormFeeBillDAO();

        dormPaymentRecordDAO =
                new DormPaymentRecordDAO();

        studentDao =
                new StudentDao();

        bankService =
                new BankService();
    }


    @Override
    public List<DormFeeBill> queryMyBills(
            String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }

        return dormFeeBillDAO
                .queryByStudent(
                        sId.trim()
                );
    }


    @Override
    public List<DormFeeBill> queryUnpaidBills(
            String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }

        return dormFeeBillDAO
                .queryUnpaidByStudent(
                        sId.trim()
                );
    }


    @Override
    public String payBill(
            String sId,
            int billId,
            double amount,
            PaymentMethod method,
            String bankPIN) {
        if (sId == null
                || sId.trim().isEmpty()) {

            return "学号不能为空";
        }


        if (billId <= 0) {

            return "账单编号无效";
        }


        if (amount <= 0) {

            return "缴费金额必须大于0";
        }


        if (method == null) {

            return "支付方式不能为空";
        }


        if (method != PaymentMethod.CAMPUS_BANK) {

            return "住宿费只能使用本人绑定银行卡支付";
        }


        String studentId =
                sId.trim();


        DormFeeBill bill =
                dormFeeBillDAO.findById(
                        billId
                );


        if (bill == null) {

            return "账单不存在";
        }


        if (!studentId.equals(
                bill.getsId())) {

            return "无权支付该账单";
        }


        if (bill.getStatus()
                == FeeStatus.CANCELLED) {

            return "账单已作废";
        }


        if (bill.getStatus()
                == FeeStatus.PAID) {

            return "账单已缴清";
        }


        double unpaidAmount =
                bill.getAmount()
                - bill.getPaidAmount();


        if (unpaidAmount <= EPS) {

            return "账单已缴清";
        }


        if (amount - unpaidAmount
                > EPS) {

            return "缴费金额不能超过未缴金额";
        }


        Student student =
                findStudentById(
                        studentId
                );


        if (student == null) {

            return "学生信息不存在";
        }


        String holderCard =
                student.getSCard();


        if (holderCard == null
                || holderCard.trim().isEmpty()) {

            return "未找到本人绑定的银行卡";
        }


        holderCard =
                holderCard.trim();
double oldPaidAmount =
                bill.getPaidAmount();


        FeeStatus oldStatus =
                bill.getStatus();


        double newPaidAmount =
                oldPaidAmount
                + amount;


        FeeStatus newStatus;


        if (newPaidAmount
                >= bill.getAmount() - EPS) {

            newPaidAmount =
                    bill.getAmount();

            newStatus =
                    FeeStatus.PAID;

        } else {

            if (bill.getStatus()
                    == FeeStatus.OVERDUE) {

                newStatus =
                        FeeStatus.OVERDUE;

            } else {

                newStatus =
                        FeeStatus.PARTIALLY_PAID;
            }
        }


        DormPaymentRecord record =
                new DormPaymentRecord();


        record.setBillId(
                billId
        );


        record.setsId(
                studentId
        );


        record.setAmount(
                amount
        );


        record.setPaymentMethod(
                PaymentMethod.CAMPUS_BANK
        );


        record.setPaymentStatus(
                PaymentStatus.PENDING
        );


        record.setTransactionNumber(
                generateTransactionNumber()
        );


        record.setPaymentTime(
                new Date()
        );


        boolean insertResult =
                dormPaymentRecordDAO.insert(
                        record
                );


        if (!insertResult) {

            return "缴费失败：无法创建支付记录";
        }


        boolean billResult =
                dormFeeBillDAO.updatePayment(
                        billId,
                        newPaidAmount,
                        newStatus
                );


        if (!billResult) {

            dormPaymentRecordDAO
                    .updateStatus(
                            record.getPaymentId(),
                            PaymentStatus.FAILED
                    );

            return "缴费失败：账单更新失败";
        }


        boolean bankResult =
                bankService.payDorm(
                        holderCard,
                        amount,
                        billId
                );


        if (!bankResult) {

            dormFeeBillDAO.updatePayment(
                    billId,
                    oldPaidAmount,
                    oldStatus
            );

            dormPaymentRecordDAO
                    .updateStatus(
                            record.getPaymentId(),
                            PaymentStatus.FAILED
                    );

            return "缴费失败：银行卡扣款失败，请检查银行卡余额或账户状态";
        }


        boolean paymentResult =
                dormPaymentRecordDAO
                        .updateStatus(
                                record.getPaymentId(),
                                PaymentStatus.SUCCESS
                        );


        if (!paymentResult) {

            return "缴费成功，但支付记录状态更新失败";
        }


        return "缴费成功";
    }


    @Override
    public List<DormPaymentRecord>
            queryPaymentHistory(
                    String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }

        return dormPaymentRecordDAO
                .queryByStudent(
                        sId.trim()
                );
    }


    private Student findStudentById(
            String sId) {

        List<Student> students =
                studentDao.findAll();

        for (Student student : students) {

            if (student != null
                    && sId.equals(
                            student.getSId()
                    )) {

                return student;
            }
        }

        return null;
    }


    private String generateTransactionNumber() {

        return "PAY-"
                + UUID.randomUUID()
                        .toString()
                        .replace(
                                "-",
                                ""
                        )
                        .toUpperCase();
    }
}