package vCampus.server.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import vCampus.common.vo.Book;
import vCampus.common.vo.BookCategory;
import vCampus.common.vo.BookCopy;
import vCampus.common.vo.BookRecommendation;
import vCampus.common.vo.BorrowRecord;
import vCampus.common.vo.LibraryReader;
import vCampus.common.vo.ReservationRecord;
import vCampus.server.ILibraryServerSrv;
import vCampus.server.dao.BookCategoryDao;
import vCampus.server.dao.BookCopyDao;
import vCampus.server.dao.BookRecommendationDao;
import vCampus.server.dao.BookDao;
import vCampus.server.dao.BorrowRecordDao;
import vCampus.server.dao.LibraryReaderDao;
import vCampus.server.dao.ReservationRecordDao;

/**
 * 图书馆业务服务层。
 *
 * <p>这一层供 Server 调用：它负责检查基本参数、组合 DAO 操作，并把数据库异常统一处理，
 * 不让异常直接传到网络通信层。</p>
 */
public class LibraryService implements ILibraryServerSrv {

    private final BookDao bookDao = new BookDao();
    private final BookCategoryDao categoryDao = new BookCategoryDao();
    private final BookCopyDao copyDao = new BookCopyDao();
    private final BorrowRecordDao borrowRecordDao = new BorrowRecordDao();
    private final ReservationRecordDao reservationRecordDao = new ReservationRecordDao();
    private final LibraryReaderDao readerDao = new LibraryReaderDao();
    private final BookRecommendationDao recommendationDao = new BookRecommendationDao();
    /** 每个客户端处理线程各自保存最近一次业务失败原因，供 Server 返回给界面。 */
    private final ThreadLocal<String> failureReason = new ThreadLocal<>();

    public String takeFailureReason() {
        String reason = failureReason.get();
        failureReason.remove();
        return reason;
    }

    @Override
    public List<Book> getAllBooks() {
        try {
            return bookDao.findAll();
        } catch (SQLException e) {
            return emptyList("查询全部图书", e);
        }
    }

    @Override
    public List<Book> searchBooks(String keyword) {
        try {
            return bookDao.search(keyword);
        } catch (SQLException e) {
            return emptyList("检索图书", e);
        }
    }

    @Override
    public Book findBookById(String bookId) {
        if (isBlank(bookId)) {
            return null;
        }
        try {
            return bookDao.findById(bookId.trim());
        } catch (SQLException e) {
            logSqlError("查询图书", e);
            return null;
        }
    }

    @Override
    public boolean addBook(Book book) {
        if (book == null || isBlank(book.getBookId()) || isBlank(book.getBookName())) {
            return false;
        }
        try {
            if (bookDao.findById(book.getBookId().trim()) != null) {
                return false;
            }
            return bookDao.add(book);
        } catch (SQLException e) {
            return operationFailed("新增图书", e);
        }
    }

    @Override
    public boolean updateBook(Book book) {
        if (book == null || isBlank(book.getBookId()) || isBlank(book.getBookName())) {
            return false;
        }
        try {
            return bookDao.update(book);
        } catch (SQLException e) {
            return operationFailed("修改图书", e);
        }
    }

    @Override
    public boolean deleteBook(String bookId) {
        if (isBlank(bookId)) {
            return false;
        }
        try {
            return bookDao.delete(bookId.trim());
        } catch (SQLException e) {
            return operationFailed("删除图书", e);
        }
    }

    @Override
    public List<BookCategory> getAllBookCategories() {
        try {
            return categoryDao.findAll();
        } catch (SQLException e) {
            return emptyList("查询图书分类", e);
        }
    }

    @Override
    public boolean addBookCategory(BookCategory category) {
        if (category == null || isBlank(category.getCategoryId()) || isBlank(category.getCategoryName())) {
            return false;
        }
        try {
            if (categoryDao.findById(category.getCategoryId().trim()) != null) {
                return false;
            }
            return categoryDao.add(category);
        } catch (SQLException e) {
            return operationFailed("新增图书分类", e);
        }
    }

    @Override
    public boolean updateBookCategory(BookCategory category) {
        if (category == null || isBlank(category.getCategoryId()) || isBlank(category.getCategoryName())) {
            return false;
        }
        try {
            return categoryDao.update(category);
        } catch (SQLException e) {
            return operationFailed("修改图书分类", e);
        }
    }

    @Override
    public boolean deleteBookCategory(String categoryId) {
        if (isBlank(categoryId)) {
            return false;
        }
        try {
            return categoryDao.delete(categoryId.trim());
        } catch (SQLException e) {
            return operationFailed("删除图书分类", e);
        }
    }

    @Override
    public List<BookCopy> getBookCopies(String bookId) {
        if (isBlank(bookId)) {
            return Collections.emptyList();
        }
        try {
            return copyDao.findByBookId(bookId.trim());
        } catch (SQLException e) {
            return emptyList("查询馆藏副本", e);
        }
    }

    @Override
    public boolean addBookCopy(BookCopy copy) {
        if (copy == null || isBlank(copy.getCopyId()) || isBlank(copy.getBookId())) {
            return false;
        }
        try {
            if (bookDao.findById(copy.getBookId().trim()) == null || copyDao.findById(copy.getCopyId().trim()) != null) {
                return false;
            }
            return copyDao.add(copy);
        } catch (SQLException e) {
            return operationFailed("新增馆藏副本", e);
        }
    }

    @Override
    public boolean updateBookCopy(BookCopy copy) {
        if (copy == null || isBlank(copy.getCopyId()) || isBlank(copy.getBookId())) {
            return false;
        }
        try {
            if (bookDao.findById(copy.getBookId().trim()) == null) {
                return false;
            }
            return copyDao.update(copy);
        } catch (SQLException e) {
            return operationFailed("修改馆藏副本", e);
        }
    }

    @Override
    public boolean deleteBookCopy(String copyId) {
        if (isBlank(copyId)) {
            return false;
        }
        try {
            return copyDao.delete(copyId.trim());
        } catch (SQLException e) {
            return operationFailed("删除馆藏副本", e);
        }
    }

    @Override
    public boolean borrowBook(String copyId, String readerId, LocalDate borrowDate, LocalDate dueDate) {
        failureReason.remove();
        if (isBlank(copyId) || isBlank(readerId) || borrowDate == null) {
            return fail("借阅信息不完整，请重新选择图书副本");
        }
        try {
            // 借期由服务端按有效预约人数统一计算：热门书 14 天，其余为 30 天。
            return borrowRecordDao.borrow(copyId.trim(), readerId.trim(), borrowDate, borrowDate.plusDays(30));
        } catch (SQLException e) {
            return operationFailed("借阅图书", e);
        }
    }

    @Override
    public boolean returnBook(String recordId, LocalDate returnDate) {
        failureReason.remove();
        if (isBlank(recordId) || returnDate == null) {
            return fail("归还信息不完整");
        }
        try {
            return borrowRecordDao.returnBook(recordId.trim(), returnDate);
        } catch (SQLException e) {
            return operationFailed("归还图书", e);
        }
    }

    /** 读者归还图书时登记损坏：副本停止外借并按规则扣除处理费。 */
    public boolean returnDamagedBook(String recordId, LocalDate returnDate) {
        failureReason.remove();
        if (isBlank(recordId) || returnDate == null) {
            return fail("损坏归还信息不完整");
        }
        try {
            return borrowRecordDao.returnDamagedBook(recordId.trim(), returnDate);
        } catch (SQLException e) {
            return operationFailed("归还并登记损坏", e);
        }
    }

    @Override
    public boolean renewBook(String recordId, LocalDate newDueDate) {
        failureReason.remove();
        if (isBlank(recordId) || newDueDate == null) {
            return fail("续借信息不完整");
        }
        try {
            // 续借日期由服务端按当前应还日期顺延 30 天统一计算。
            return borrowRecordDao.renew(recordId.trim(), LocalDate.now());
        } catch (SQLException e) {
            return operationFailed("续借图书", e);
        }
    }

    @Override
    public boolean reserveBook(String bookId, String readerId, LocalDateTime reservationTime) {
        failureReason.remove();
        if (isBlank(bookId) || isBlank(readerId)) {
            return fail("预约信息不完整");
        }
        try {
            if (bookDao.findById(bookId.trim()) == null || readerDao.findById(readerId.trim()) == null) {
                return fail("未找到图书或读者的图书馆权限");
            }
            return reservationRecordDao.reserve(bookId.trim(), readerId.trim(), reservationTime);
        } catch (SQLException e) {
            return operationFailed("预约图书", e);
        }
    }

    @Override
    public boolean cancelReservation(String reservationId) {
        if (isBlank(reservationId)) {
            return false;
        }
        try {
            return reservationRecordDao.cancel(reservationId.trim());
        } catch (SQLException e) {
            return operationFailed("取消预约", e);
        }
    }

    @Override
    public List<ReservationRecord> getReservationsByReader(String readerId) {
        if (isBlank(readerId)) {
            return Collections.emptyList();
        }
        try {
            return reservationRecordDao.findByReaderId(readerId.trim());
        } catch (SQLException e) {
            return emptyList("查询读者预约", e);
        }
    }

    @Override
    public List<ReservationRecord> getWaitingReservations(String bookId) {
        if (isBlank(bookId)) {
            return Collections.emptyList();
        }
        try {
            return reservationRecordDao.findWaitingByBookId(bookId.trim());
        } catch (SQLException e) {
            return emptyList("查询预约队列", e);
        }
    }

    @Override
    public LibraryReader getLibraryReader(String readerId) {
        if (isBlank(readerId)) {
            return null;
        }
        try {
            return readerDao.findById(readerId.trim());
        } catch (SQLException e) {
            logSqlError("查询读者", e);
            return null;
        }
    }

    @Override
    public boolean canBorrow(String readerId, LocalDate borrowDate) {
        if (isBlank(readerId) || borrowDate == null) {
            return false;
        }
        try {
            return readerDao.canBorrow(readerId.trim(), borrowDate);
        } catch (SQLException e) {
            return operationFailed("检查借阅资格", e);
        }
    }

    @Override
    public List<BorrowRecord> getBorrowRecordsByReader(String readerId) {
        if (isBlank(readerId)) {
            return Collections.emptyList();
        }
        try {
            return borrowRecordDao.findByReaderId(readerId.trim());
        } catch (SQLException e) {
            return emptyList("查询读者借阅记录", e);
        }
    }

    @Override
    public List<BorrowRecord> getActiveBorrowRecords() {
        try {
            return borrowRecordDao.findActive();
        } catch (SQLException e) {
            return emptyList("查询在借记录", e);
        }
    }

    @Override
    public boolean submitBookRecommendation(BookRecommendation recommendation) {
        failureReason.remove();
        if (recommendation == null || isBlank(recommendation.getReaderCardId()) || isBlank(recommendation.getBookName())) {
            return fail("荐书信息填写不完整：请填写书名");
        }
        try {
            LibraryReader reader = readerDao.findById(recommendation.getReaderCardId().trim());
            if (reader == null || (!LibraryReader.TYPE_TEACHER.equals(reader.getReaderType())
                    && !LibraryReader.TYPE_STUDENT.equals(reader.getReaderType()))) {
                return fail("只有已开通图书馆权限的师生可以提交荐书");
            }
            recommendation.setReaderCardId(reader.getReaderId());
            recommendation.setRecommenderType(reader.getReaderType());
            recommendation.setBookName(recommendation.getBookName().trim());
            return recommendationDao.add(recommendation);
        } catch (SQLException e) {
            return operationFailed("提交荐书", e);
        }
    }

    @Override
    public List<BookRecommendation> getRecommendationsByTeacherCardId(String teacherCardId) {
        if (isBlank(teacherCardId)) return Collections.emptyList();
        try {
            return recommendationDao.findByTeacherCardId(teacherCardId.trim());
        } catch (SQLException e) {
            return emptyList("查询读者荐书", e);
        }
    }

    @Override
    public List<BookRecommendation> getProcurementReferences() {
        try {
            Map<String, BookRecommendation> grouped = new LinkedHashMap<>();
            for (BookRecommendation item : recommendationDao.findProcurementReferences()) {
                grouped.put(procurementKey(item.getBookName()), item);
            }
            // 没有师生荐书但预约排队很长的现有图书，也必须进入采购参考，不能被遗漏。
            for (BookRecommendation hotBook : reservationRecordDao.findHotBookProcurementReferences()) {
                BookRecommendation item = grouped.get(procurementKey(hotBook.getBookName()));
                if (item == null) {
                    grouped.put(procurementKey(hotBook.getBookName()), hotBook);
                } else {
                    item.setActiveReservationCount(Math.max(item.getActiveReservationCount(), hotBook.getActiveReservationCount()));
                    if (isBlank(item.getAuthor())) item.setAuthor(hotBook.getAuthor());
                    if (isBlank(item.getPublisher())) item.setPublisher(hotBook.getPublisher());
                    if (isBlank(item.getCategoryId())) item.setCategoryId(hotBook.getCategoryId());
                }
            }
            List<BookRecommendation> results = new java.util.ArrayList<>(grouped.values());
            int maxRecommendationCount = 0;
            int maxReservationCount = 0;
            for (BookRecommendation item : results) {
                if (item.getActiveReservationCount() == 0) {
                    item.setActiveReservationCount(reservationRecordDao.countActiveReservationsByBookName(item.getBookName()));
                }
                maxRecommendationCount = Math.max(maxRecommendationCount, item.getRecommendationCount());
                maxReservationCount = Math.max(maxReservationCount, item.getActiveReservationCount());
            }
            for (BookRecommendation item : results) {
                double recommendationPart = maxRecommendationCount == 0 ? 0
                        : item.getRecommendationCount() * 70.0 / maxRecommendationCount;
                double reservationPart = maxReservationCount == 0 ? 0 : item.getActiveReservationCount() * 30.0 / maxReservationCount;
                item.setReferenceScore((int) Math.round(recommendationPart + reservationPart));
                applyDemandPolicy(item);
            }
            Collections.sort(results, (a, b) -> {
                int demand = Integer.compare(b.getSuggestedAdditionalCopies(), a.getSuggestedAdditionalCopies());
                return demand != 0 ? demand : Integer.compare(b.getReferenceScore(), a.getReferenceScore());
            });
            return results;
        } catch (SQLException e) {
            return emptyList("查询采购参考", e);
        }
    }

    /** 预约人数是实际需求信号：3 人起提示补 1 册，6 人起补 2 册，10 人起紧急补 3 册。 */
    private void applyDemandPolicy(BookRecommendation item) {
        int reservations = item.getActiveReservationCount();
        if (reservations >= 10) {
            item.setDemandLevel("紧急采购");
            item.setSuggestedAdditionalCopies(3);
        } else if (reservations >= 6) {
            item.setDemandLevel("热门采购");
            item.setSuggestedAdditionalCopies(2);
        } else if (reservations >= ReservationRecordDao.HOT_RESERVATION_THRESHOLD) {
            item.setDemandLevel("需求较高");
            item.setSuggestedAdditionalCopies(1);
        } else {
            item.setDemandLevel("常规");
            item.setSuggestedAdditionalCopies(0);
        }
    }

    private String procurementKey(String bookName) {
        return bookName == null ? "" : bookName.trim().toLowerCase(java.util.Locale.ROOT);
    }

    private boolean operationFailed(String operation, SQLException e) {
        logSqlError(operation, e);
        failureReason.set(e.getMessage() == null ? operation + "失败" : e.getMessage());
        return false;
    }

    private boolean fail(String reason) {
        failureReason.set(reason);
        return false;
    }

    private <T> List<T> emptyList(String operation, SQLException e) {
        logSqlError(operation, e);
        return Collections.emptyList();
    }

    private void logSqlError(String operation, SQLException e) {
        System.err.println("图书馆模块" + operation + "失败：" + e.getMessage());
    }

    private boolean isBlank(String text) {
        return text == null || text.trim().isEmpty();
    }
}
