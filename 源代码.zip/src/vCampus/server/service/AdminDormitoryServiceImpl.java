package vCampus.server.service;

import java.util.List;

import vCampus.common.vo.Dormitory;
import vCampus.server.dao.DormitoryDAO;

public class AdminDormitoryServiceImpl implements AdminDormitoryService {

	@Override
	public List<Dormitory> queryAllDorm() {
	    return dormitoryDAO.queryAll();
	}

	@Override
	public List<Dormitory> queryAvailableDorm() {
	    return dormitoryDAO.queryAvailable();
	}

	@Override
	public boolean addDorm(Dormitory dorm) {

	    if (dorm == null) {
	        return false;
	    }

	    return dormitoryDAO.insert(dorm);
	}

	@Override
	public boolean updateDorm(Dormitory dorm) {

	    if (dorm == null) {
	        return false;
	    }

	    return dormitoryDAO.update(dorm);
	}

	@Override
	public boolean deleteDorm(String dormId) {

	    if (dormId == null || dormId.trim().isEmpty()) {
	        return false;
	    }

	    return dormitoryDAO.delete(dormId);
	}
	
	private DormitoryDAO dormitoryDAO;
	
	public AdminDormitoryServiceImpl() {
	    dormitoryDAO = new DormitoryDAO();
	}
}
