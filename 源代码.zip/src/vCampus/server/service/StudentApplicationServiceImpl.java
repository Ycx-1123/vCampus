package vCampus.server.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vCampus.common.enums.ApplicationStatus;
import vCampus.common.enums.ApplicationType;
import vCampus.common.vo.Accommodation;
import vCampus.common.vo.DormApplication;
import vCampus.common.vo.Dormitory;
import vCampus.server.dao.AccommodationDAO;
import vCampus.server.dao.DormApplicationDAO;
import vCampus.server.dao.DormitoryDAO;

public class StudentApplicationServiceImpl
        implements StudentApplicationService {

    private DormApplicationDAO dormApplicationDAO;
    private AccommodationDAO accommodationDAO;
    private DormitoryDAO dormitoryDAO;

    public StudentApplicationServiceImpl() {

        dormApplicationDAO =
                new DormApplicationDAO();

        accommodationDAO =
                new AccommodationDAO();

        dormitoryDAO =
                new DormitoryDAO();
    }


    // =====================================================
    // 提交调宿申请
    // =====================================================

    @Override
    public boolean applyDormChange(
            String sId,
            String targetDormId,
            String targetBedNumber,
            String reason) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (targetDormId == null
                || targetDormId.trim().isEmpty()) {

            return false;
        }

        if (targetBedNumber == null
                || targetBedNumber.trim().isEmpty()) {

            return false;
        }

        if (reason == null
                || reason.trim().isEmpty()) {

            return false;
        }


        String studentId =
                sId.trim();

        String newDormId =
                targetDormId.trim();

        String newBedNumber =
                targetBedNumber.trim();


        // 查询当前住宿
        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(
                                studentId
                        );

        if (current == null) {

            return false;
        }


        // 查询目标宿舍
        Dormitory targetDorm =
                dormitoryDAO.findById(
                        newDormId
                );

        if (targetDorm == null) {

            return false;
        }


        // 目标宿舍已经满员
        if (targetDorm.getOccupied()
                >= targetDorm.getCapacity()) {

            return false;
        }


        // 不能申请当前自己的床位
        if (current.getDormId()
                .equals(newDormId)

                && current.getBedNumber()
                .equals(newBedNumber)) {

            return false;
        }


        // 目标床位已经被占用
        if (accommodationDAO
                .isBedOccupied(
                        newDormId,
                        newBedNumber
                )) {

            return false;
        }


        DormApplication application =
                new DormApplication();


        application.setsId(
                studentId
        );

        application.setAccommodationId(
                current.getRecordId()
        );

        application.setType(
                ApplicationType.CHANGE_DORM
        );

        application.setCurrentDormId(
                current.getDormId()
        );

        application.setCurrentBedNumber(
                current.getBedNumber()
        );

        application.setTargetDormId(
                newDormId
        );

        application.setTargetBedNumber(
                newBedNumber
        );

        application.setReason(
                reason.trim()
        );

        application.setStatus(
                ApplicationStatus.PENDING
        );

        application.setSubmitTime(
                new Date()
        );


        return dormApplicationDAO.insert(
                application
        );
    }


    // =====================================================
    // 提交退宿申请
    // =====================================================

    @Override
    public boolean applyCheckout(
            String sId,
            ApplicationType type,
            String reason) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (type == null
                || type == ApplicationType.CHANGE_DORM) {

            return false;
        }

        if (reason == null
                || reason.trim().isEmpty()) {

            return false;
        }


        String studentId =
                sId.trim();


        // 必须有当前住宿记录才能申请退宿
        Accommodation current =
                accommodationDAO
                        .findCurrentByStudentId(
                                studentId
                        );

        if (current == null) {

            return false;
        }


        DormApplication application =
                new DormApplication();


        application.setsId(
                studentId
        );

        application.setAccommodationId(
                current.getRecordId()
        );

        application.setType(
                type
        );

        application.setCurrentDormId(
                current.getDormId()
        );

        application.setCurrentBedNumber(
                current.getBedNumber()
        );


        // 退宿没有目标宿舍
        application.setTargetDormId(
                null
        );

        application.setTargetBedNumber(
                null
        );


        application.setReason(
                reason.trim()
        );

        application.setStatus(
                ApplicationStatus.PENDING
        );

        application.setSubmitTime(
                new Date()
        );


        return dormApplicationDAO.insert(
                application
        );
    }


    // =====================================================
    // 查询自己的全部申请
    // =====================================================

    @Override
    public List<DormApplication>
            queryMyApplications(
                    String sId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return new ArrayList<>();
        }

        return dormApplicationDAO
                .queryByStudent(
                        sId.trim()
                );
    }


    // =====================================================
    // 取消申请
    // =====================================================

    @Override
    public boolean cancelApplication(
            String sId,
            int applicationId) {

        if (sId == null
                || sId.trim().isEmpty()) {

            return false;
        }

        if (applicationId <= 0) {

            return false;
        }


        DormApplication application =
                dormApplicationDAO
                        .findById(
                                applicationId
                        );


        if (application == null) {

            return false;
        }


        // 只能取消自己的申请
        if (!sId.trim().equals(
                application.getsId())) {

            return false;
        }


        // 只有待审核申请可以取消
        if (application.getStatus()
                != ApplicationStatus.PENDING) {

            return false;
        }


        return dormApplicationDAO
                .cancel(
                        applicationId
                );
    }
}