package vCampus.server.service;

import java.util.List;
import vCampus.common.vo.Student;
import vCampus.server.dao.StudentDao;

public class StudentService {
	private StudentDao studentDao = new StudentDao();

    // 查询全部学生
    public List<Student> findAllStudent() {
        return studentDao.findAll();
    }

    // 根据学号查询单个学生
    public Student findStudentBySCard(String sCard) {
        return studentDao.findBySCard(sCard);
    }

    // 根据班级编号，查询该班所有学生
    public List<Student> findStudentByClazzId(String clazzid) {
        return studentDao.findStudentByClazzId(clazzid);
    }

    // 新增学生学籍
    public boolean addStudent(Student student) {
        // 1、学号不能重复
        Student exist = studentDao.findBySCard(student.getSCard());
        if(exist != null){
            return false;
        }
        // 2、已修学分不能超过所需毕业学分
        if(student.getFinishedCredit() != null && student.getRequiredCredit() != null){
            if(student.getFinishedCredit() > student.getRequiredCredit()){
                return false;
            }
        }
        if(student.getSpassword() == null || student.getSpassword().trim().isEmpty()){
            student.setSpassword("123456");
        }
        return studentDao.add(student);
    }

    // 修改学籍信息
    public boolean updateStudent(Student student) {
        Student target = studentDao.findBySCard(student.getSCard());
        if(target == null){
            return false;
        }
        if(student.getFinishedCredit() != null && student.getRequiredCredit() != null){
            if(student.getFinishedCredit() > student.getRequiredCredit()){
                return false;
            }
        }
        if(target.isLocked()){
            System.out.println("修改失败：该学生学籍已锁定");
            return false;
        }
        return studentDao.update(student);
    }
    
    //删除学籍
    public boolean deleteStudent(String sCard) {
        Student stu = studentDao.findBySCard(sCard);
        if(stu == null){
            return false;
        }
        //锁定学籍不能删除
        if(stu.isLocked()){
            System.out.println("删除失败：该学生学籍已锁定");
            return false;
        }
        return studentDao.delete(sCard);
    }

    // 锁定学籍
    public boolean lockStudent(String sCard) {
        return studentDao.lockStudent(sCard);
    }

    // 解锁学籍
    public boolean unlockStudent(String sCard) {
        return studentDao.unlockStudent(sCard);
    }

    // 判断毕业学分是否达标
    public boolean isGraduationQualified(String sCard) {
        Student stu = studentDao.findBySCard(sCard);
        if(stu == null){
            return false;
        }
        Double finish = stu.getFinishedCredit();
        Double req = stu.getRequiredCredit();
        if(finish == null || req == null){
            return false;
        }
        return finish >= req;
    }
}
