package vCampus.server.service;

import vCampus.common.vo.*;
import vCampus.server.dao.*;

import java.sql.SQLException;
import java.util.*;

public class AdminCourseService {

    private CourseDao courseDao = new CourseDao();
    private CourseOfferingDao offeringDao = new CourseOfferingDao();
    private SelectDao selectDao = new SelectDao();
    private SelectRoundDao roundDao = new SelectRoundDao();

    // ============================================================
    // 一、课程模板管理
    // ============================================================

    

    public Course getCourseById(String courseId) {
        try { return courseDao.getCourseById(courseId); }
        catch (SQLException e) { e.printStackTrace(); return null; }
    }

    public boolean addCourse(Course course) {
        try { courseDao.insertCourse(course); return true; }
        catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean updateCourse(Course course) {
        try { courseDao.updateCourse(course); return true; }
        catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public String deleteCourse(String courseId) {
        try {
            offeringDao.deleteOfferingsByCourseId(courseId);
            courseDao.deleteCourse(courseId);
            return "删除成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "删除失败：" + e.getMessage();
        }
    }

    // ============================================================
    // 二、开课班级管理
    // ============================================================

    public List<Map<String, Object>> getAllCoursesWithOffering(String roundId) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            roundId = resolveRoundId(roundId);
            if (roundId == null) return result;

            List<CourseOffering> offerings = offeringDao.getOfferingsByRoundId(roundId);

            // 一次性算真实人数
            Map<String, Integer> realCountMap = new HashMap<>();
            for (CourseOffering offering : offerings) {
                int cnt = 0;
                for (SelectRecord r : selectDao.getByOfferingId(offering.getOfferingId())) {
                    if ("selected".equals(r.getStatus())) cnt++;
                }
                realCountMap.put(offering.getOfferingId(), cnt);
            }

            for (CourseOffering offering : offerings) {
                Course course = courseDao.getCourseById(offering.getCourseId());
                if (course == null) continue;

                int realCount = realCountMap.getOrDefault(offering.getOfferingId(), 0);

                // ★ 如果冗余字段与实际不符，顺便修回数据库
                if (offering.getEnrolledCount() != realCount) {
                    offeringDao.recalcEnrolledCount(offering.getOfferingId());
                }

                result.add(buildCourseRow(course, offering, realCount));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
    /**
     * 拼装课程列表的一行（enrolledCount 用实际学生数，不用冗余字段）
     */
    private Map<String, Object> buildCourseRow(Course course, CourseOffering offering, int realEnrolledCount) {
        Map<String, Object> row = new HashMap<>();
        row.put("courseId", course.getCourseId());
        row.put("courseName", course.getCourseName());
        row.put("credit", course.getCredit());
        row.put("offeringId", offering.getOfferingId());
        row.put("teacherName", offering.getTeacherName());
        row.put("capacity", offering.getCapacity());
        row.put("enrolledCount", realEnrolledCount);
        row.put("roomCapacity", offering.getRoomCapacity());

        // ★ 状态按实际情况现算：满则 full；没满且冗余字段是 closed 则保留 closed；否则 open
        String realStatus;
        if (realEnrolledCount >= offering.getCapacity()) {
            realStatus = "full";
        } else if ("closed".equals(offering.getStatus())) {
            realStatus = "closed";
        } else {
            realStatus = "open";
        }
        row.put("status", realStatus);

        row.put("schedule", offering.getSchedule());
        row.put("classroom", offering.getClassroom());
        row.put("semester", offering.getSemester());
        row.put("roundId", offering.getRoundId());
        return row;
    }

    
    public List<Map<String, Object>> searchCourses(String keyword, String roundId) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            roundId = resolveRoundId(roundId);
            if (roundId == null) return result;

            // 先把该轮次下匹配的 offering 都收集起来
            List<CourseOffering> matchedOfferings = new ArrayList<>();
            List<Course> matchedCourses = new ArrayList<>();
            for (Course course : courseDao.searchCourses(keyword)) {
                for (CourseOffering offering : offeringDao.getOfferingsByCourseIdAndRound(course.getCourseId(), roundId)) {
                    matchedOfferings.add(offering);
                    matchedCourses.add(course);
                }
            }

            // 一次性算真实人数
            Map<String, Integer> realCountMap = new HashMap<>();
            for (CourseOffering offering : matchedOfferings) {
                int cnt = 0;
                for (SelectRecord r : selectDao.getByOfferingId(offering.getOfferingId())) {
                    if ("selected".equals(r.getStatus())) cnt++;
                }
                realCountMap.put(offering.getOfferingId(), cnt);
            }

            for (int i = 0; i < matchedOfferings.size(); i++) {
                CourseOffering offering = matchedOfferings.get(i);
                Course course = matchedCourses.get(i);
                int realCount = realCountMap.getOrDefault(offering.getOfferingId(), 0);

                // ★ 顺便修回数据库
                if (offering.getEnrolledCount() != realCount) {
                    offeringDao.recalcEnrolledCount(offering.getOfferingId());
                }

                result.add(buildCourseRow(course, offering, realCount));}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public String addCourseAndOffering(Course course, CourseOffering offering) {
        try {
            if (offering.getRoundId() == null || offering.getRoundId().isEmpty()) {
                SelectRound openRound = roundDao.getCurrentOpenRound();
                if (openRound == null) return "当前没有开放的选课轮次，无法新增开课";
                offering.setRoundId(openRound.getRoundId());
            }
            SelectRound round = roundDao.getRoundById(offering.getRoundId());
            if (round != null && !"open".equals(round.getStatus())) {
                offering.setStatus("closed");
            } else if (offering.getStatus() == null || offering.getStatus().isEmpty()) {
                offering.setStatus("open");
            }
            if (offering.getCapacity() <= 0) offering.setCapacity(50);
            if (offering.getRoomCapacity() <= 0) offering.setRoomCapacity(70);

            if (courseDao.getCourseById(course.getCourseId()) == null) {
                courseDao.insertCourse(course);
            }
            if (offeringDao.getOfferingById(offering.getOfferingId()) != null) {
                return "开课ID [" + offering.getOfferingId() + "] 已存在，请更换";
            }
            offeringDao.insertOffering(offering);
            return "新增成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "新增失败：" + e.getMessage();
        }
    }

    public String updateCourseAndOffering(Course course, CourseOffering offering) {
        try {
            courseDao.updateCourse(course);
            offeringDao.updateOffering(offering);

            // ★ 改容量后，重算已选人数和状态
            offeringDao.recalcEnrolledCount(offering.getOfferingId());

            return "修改成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "修改失败：" + e.getMessage();
        }
    }

    public String deleteOffering(String offeringId) {
        try {
            for (SelectRecord record : selectDao.getByOfferingId(offeringId)) {
                selectDao.deleteSelectRecord(record.getSelectId());
            }
            offeringDao.deleteOffering(offeringId);
            return "删除成功";
        } catch (SQLException e) {
            e.printStackTrace();
            return "删除失败：" + e.getMessage();
        }
    }

    public boolean addOffering(CourseOffering offering) {
        try { offeringDao.insertOffering(offering); return true; }
        catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean updateOffering(CourseOffering offering) {
        try {
            offeringDao.updateOffering(offering);

            // ★ 改容量后，重算已选人数和状态
            offeringDao.recalcEnrolledCount(offering.getOfferingId());

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 返回课程+开课+学生名单详情。
     * 其中 enrolledCount 用实际学生名单条数，避免与冗余字段不一致。
     */
    public Map<String, Object> getCourseDetailByOfferingId(String offeringId) {
        Map<String, Object> result = new HashMap<>();
        try {
            CourseOffering offering = offeringDao.getOfferingById(offeringId);
            if (offering == null) {
                result.put("success", false);
                result.put("message", "开课班级不存在");
                return result;
            }
            Course course = courseDao.getCourseById(offering.getCourseId());
            if (course == null) {
                result.put("success", false);
                result.put("message", "课程不存在");
                return result;
            }

            // 先查实际学生名单
            List<StudentScoreDTO> students = selectDao.getStudentsByOfferingId(offeringId);

            Map<String, Object> info = new HashMap<>();
            info.put("offeringId", offering.getOfferingId());
            info.put("courseId", course.getCourseId());
            info.put("courseName", course.getCourseName());
            info.put("credit", course.getCredit());
            info.put("hours", course.getHours());
            info.put("categoryId", course.getCategoryId());
            info.put("categoryName", course.getCategoryName());
            info.put("description", course.getDescription());
            info.put("teacherId", offering.getTeacherId());
            info.put("teacherName", offering.getTeacherName());
            info.put("capacity", offering.getCapacity());
            // ★ 用实际学生名单条数，不用 offering.getEnrolledCount()
            info.put("enrolledCount", students.size());
            info.put("roomCapacity", offering.getRoomCapacity());
            info.put("schedule", offering.getSchedule());
            info.put("classroom", offering.getClassroom());
            info.put("campus", offering.getCampus());
            info.put("semester", offering.getSemester());
            String realStatus;
            if (students.size() >= offering.getCapacity()) {
                realStatus = "full";
            } else if ("closed".equals(offering.getStatus())) {
                realStatus = "closed";
            } else {
                realStatus = "open";
            }
            info.put("status", realStatus);
            info.put("students", students);

            result.put("success", true);
            result.put("data", info);
        } catch (SQLException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        return result;
    }

    // ============================================================
    // 三、Excel 导入导出
    // ============================================================

    public byte[] exportOfferingTemplate(String roundId) {
        try {
            roundId = resolveRoundId(roundId);
            if (roundId == null) return null;

            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("课表模板");
            String[] headers = {"offeringId", "teacherId", "teacherName", "schedule",
                                "classroom", "campus", "capacity", "roomCapacity"};

            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            org.apache.poi.ss.usermodel.CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(org.apache.poi.ss.usermodel.IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(org.apache.poi.ss.usermodel.FillPatternType.SOLID_FOREGROUND);
            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell c = headerRow.createCell(i);
                c.setCellValue(headers[i]);
                c.setCellStyle(headerStyle);
            }

            int rowNum = 1;
            for (CourseOffering o : offeringDao.getOfferingsByRoundId(roundId)) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(str(o.getOfferingId()));
                row.createCell(1).setCellValue(str(o.getTeacherId()));
                row.createCell(2).setCellValue(str(o.getTeacherName()));
                row.createCell(3).setCellValue(str(o.getSchedule()));
                row.createCell(4).setCellValue(str(o.getClassroom()));
                row.createCell(5).setCellValue(str(o.getCampus()));
                row.createCell(6).setCellValue(o.getCapacity());
                row.createCell(7).setCellValue(o.getRoomCapacity());
            }
            for (int i = 0; i < headers.length; i++) sheet.autoSizeColumn(i);

            workbook.write(baos);
            workbook.close();
            return baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Map<String, Object> importOfferingExcel(byte[] fileBytes, String fileName) {
        Map<String, Object> result = new HashMap<>();
        List<String> errors = new ArrayList<>();
        int successCount = 0, notFoundCount = 0;

        try (java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(fileBytes)) {
            org.apache.poi.ss.usermodel.Workbook workbook;
            if (fileName != null && fileName.toLowerCase().endsWith(".xlsx")) {
                workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook(bais);
            } else {
                workbook = new org.apache.poi.hssf.usermodel.HSSFWorkbook(bais);
            }
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);
            int lastRow = sheet.getLastRowNum();

            for (int rowIdx = 1; rowIdx <= lastRow; rowIdx++) {
                org.apache.poi.ss.usermodel.Row row = sheet.getRow(rowIdx);
                if (row == null) continue;
                try {
                    String offeringId = getCellString(row, 0);
                    if (offeringId == null || offeringId.isEmpty()) continue;
                    CourseOffering offering = offeringDao.getOfferingById(offeringId);
                    if (offering == null) {
                        notFoundCount++;
                        errors.add("第 " + (rowIdx + 1) + " 行：offeringId [" + offeringId + "] 不存在");
                        continue;
                    }
                    String teacherId = getCellString(row, 1);
                    String teacherName = getCellString(row, 2);
                    String schedule = getCellString(row, 3);
                    String classroom = getCellString(row, 4);
                    String campus = getCellString(row, 5);
                    String capacityStr = getCellString(row, 6);
                    String roomCapStr = getCellString(row, 7);

                    if (teacherId != null && !teacherId.isEmpty()) offering.setTeacherId(teacherId);
                    if (teacherName != null && !teacherName.isEmpty()) offering.setTeacherName(teacherName);
                    if (schedule != null && !schedule.isEmpty()) offering.setSchedule(schedule);
                    if (classroom != null && !classroom.isEmpty()) offering.setClassroom(classroom);
                    if (campus != null && !campus.isEmpty()) offering.setCampus(campus);
                    if (capacityStr != null && !capacityStr.isEmpty()) {
                        try { offering.setCapacity((int) Double.parseDouble(capacityStr)); }
                        catch (NumberFormatException ex) {
                            errors.add("第 " + (rowIdx + 1) + " 行：容量格式错误 [" + capacityStr + "]");
                            continue;
                        }
                    }
                    if (roomCapStr != null && !roomCapStr.isEmpty()) {
                        try { offering.setRoomCapacity((int) Double.parseDouble(roomCapStr)); }
                        catch (NumberFormatException ex) {
                            errors.add("第 " + (rowIdx + 1) + " 行：教室容量格式错误 [" + roomCapStr + "]");
                            continue;
                        }
                    }
                    offeringDao.updateOffering(offering);
                    successCount++;
                } catch (Exception ex) {
                    errors.add("第 " + (rowIdx + 1) + " 行：" + ex.getMessage());
                }
            }
            workbook.close();

            result.put("success", true);
            result.put("successCount", successCount);
            result.put("notFoundCount", notFoundCount);
            result.put("totalRows", lastRow);
            result.put("errors", errors);
            result.put("message", String.format("导入完成：成功 %d 条，未找到 %d 条，失败 %d 条",
                    successCount, notFoundCount, errors.size()));
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "导入失败：" + e.getMessage());
        }
        return result;
    }

    // ============================================================
    // 四、克隆轮次
    // ============================================================

    public Map<String, Object> cloneRoundOfferings(String sourceRoundId, String targetRoundId) {
        Map<String, Object> result = new HashMap<>();
        List<String> errors = new ArrayList<>();
        int successCount = 0, skipCount = 0;

        try {
            SelectRound target = roundDao.getRoundById(targetRoundId);
            if (target == null) {
                result.put("success", false); result.put("message", "目标轮次不存在"); return result;
            }
            SelectRound source = roundDao.getRoundById(sourceRoundId);
            if (source == null) {
                result.put("success", false); result.put("message", "源轮次不存在"); return result;
            }
            if (sourceRoundId.equals(targetRoundId)) {
                result.put("success", false); result.put("message", "源轮次和目标轮次不能相同"); return result;
            }

            String semester = target.getSemester();
            List<CourseOffering> sourceOfferings = offeringDao.getOfferingsByRoundId(sourceRoundId);
            if (sourceOfferings.isEmpty()) {
                result.put("success", false); result.put("message", "源轮次下没有开课记录"); return result;
            }

            for (CourseOffering src : sourceOfferings) {
                try {
                    String offeringId = generateOfferingIdForBatch(src.getCourseId(), semester);
                    CourseOffering copy = new CourseOffering();
                    copy.setOfferingId(offeringId);
                    copy.setCourseId(src.getCourseId());
                    copy.setTeacherId(src.getTeacherId());
                    copy.setTeacherName(src.getTeacherName());
                    copy.setSemester(semester);
                    copy.setCapacity(src.getCapacity() > 0 ? src.getCapacity() : 50);
                    copy.setEnrolledCount(0);
                    copy.setSchedule(src.getSchedule());
                    copy.setClassroom(src.getClassroom());
                    copy.setCampus(src.getCampus());
                    copy.setStatus("closed");
                    copy.setVersion(0);
                    copy.setRoundId(targetRoundId);
                    copy.setRoomCapacity(src.getRoomCapacity() > 0 ? src.getRoomCapacity() : 70);
                    offeringDao.insertOffering(copy);
                    successCount++;
                } catch (SQLException e) {
                    errors.add(src.getOfferingId() + ": " + e.getMessage());
                }
            }

            result.put("success", true);
            result.put("successCount", successCount);
            result.put("skipCount", skipCount);
            result.put("totalCount", sourceOfferings.size());
            result.put("errors", errors);
            result.put("message", String.format("已从「%s」复制 %d 条到「%s」，失败 %d 条",
                    source.getRoundName(), successCount, target.getRoundName(), errors.size()));
        } catch (SQLException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "复制失败：" + e.getMessage());
        }
        return result;
    }

    // ============================================================
    // 辅助方法
    // ============================================================

    private String resolveRoundId(String roundId) {
        if (roundId != null && !roundId.isEmpty()) return roundId;
        try {
            SelectRound openRound = roundDao.getCurrentOpenRound();
            return openRound != null ? openRound.getRoundId() : null;
        } catch (SQLException e) { return null; }
    }

    private Map<String, Object> buildCourseRow(Course course, CourseOffering offering) {
        Map<String, Object> row = new HashMap<>();
        row.put("courseId", course.getCourseId());
        row.put("courseName", course.getCourseName());
        row.put("credit", course.getCredit());
        row.put("offeringId", offering.getOfferingId());
        row.put("teacherName", offering.getTeacherName());
        row.put("capacity", offering.getCapacity());
        row.put("enrolledCount", offering.getEnrolledCount());
        row.put("roomCapacity", offering.getRoomCapacity());
        row.put("status", offering.getStatus());
        row.put("schedule", offering.getSchedule());
        row.put("classroom", offering.getClassroom());
        row.put("semester", offering.getSemester());
        row.put("roundId", offering.getRoundId());
        return row;
    }

    private String generateOfferingIdForBatch(String courseId, String semester) throws SQLException {
        List<CourseOffering> existing = offeringDao.getOfferingsByCourseId(courseId);
        Set<String> existingIds = new HashSet<>();
        for (CourseOffering o : existing) existingIds.add(o.getOfferingId());
        for (int seq = 1; seq <= 99; seq++) {
            String candidate = courseId + "-" + semester + "-" + String.format("%02d", seq);
            if (!existingIds.contains(candidate)) return candidate;
        }
        return courseId + "-" + semester + "-" + System.currentTimeMillis();
    }

    private String getCellString(org.apache.poi.ss.usermodel.Row row, int col) {
        org.apache.poi.ss.usermodel.Cell cell = row.getCell(col);
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case STRING: return cell.getStringCellValue().trim();
            case NUMERIC:
                double d = cell.getNumericCellValue();
                if (d == Math.floor(d)) return String.valueOf((long) d);
                return String.valueOf(d);
            case BOOLEAN: return String.valueOf(cell.getBooleanCellValue());
            default: return null;
        }
    }
    /**
     * 按课程号批量查询课程（用于批量新增时显示课程名）
     */
    public List<Course> getCoursesByIds(List<String> courseIds) {
        try {
            return courseDao.getCoursesByIds(courseIds);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    private String str(Object obj) { return obj == null ? "" : obj.toString(); }
}