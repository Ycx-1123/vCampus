
package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.shop.Order;
import vCampus.common.shop.OrderItem;
import vCampus.common.shop.OrderStatus;

public class OrderDAO {

    private static final String DB_URL = "jdbc:ucanaccess://./vCampus.accdb;ignoreCase=true;newDatabaseVersion=V2019";

    /**
     * 插入订单主表，并返回生成的订单ID（自增主键）
     */
 // ★ 新增：支持事务的订单主表插入
    public long insertOrder(Connection conn, Order order) throws SQLException {
        String sql = "INSERT INTO tblOrder (userId, totalAmount, status, createTime) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            setUserIdParam(pstmt, 1, order.getUserId());
            pstmt.setDouble(2, order.getTotalAmount());
            pstmt.setString(3, order.getStatus().name());
            pstmt.setTimestamp(4, new Timestamp(order.getCreateTime().getTime()));
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getLong(1);
            }
            return -1;
        }
    }

    // ★ 新增：支持事务的订单明细插入
    public boolean insertOrderItem(Connection conn, OrderItem item) throws SQLException {
        String sql = "INSERT INTO tblOrderItem (orderId, productId, quantity, unitPrice) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, item.getOrderId());
            pstmt.setInt(2, item.getProductId());
            pstmt.setInt(3, item.getQuantity());
            pstmt.setDouble(4, item.getUnitPrice());
            return pstmt.executeUpdate() > 0;
        }
    }

    // ★ 新增：查询用户订单列表
    public List<Order> queryByUser(String userId) {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT * FROM tblOrder WHERE userId = ? ORDER BY createTime DESC";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            setUserIdParam(pstmt, 1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getLong("orderId"));
                order.setUserId(rs.getString("userId"));
                order.setTotalAmount(rs.getDouble("totalAmount"));
                order.setStatus(OrderStatus.valueOf(rs.getString("status")));
                order.setCreateTime(rs.getTimestamp("createTime"));
                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    
    public long insertOrder(Order order) {
        String sql = "INSERT INTO tblOrder (userId, totalAmount, status, createTime) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            setUserIdParam(pstmt, 1, order.getUserId());
            pstmt.setDouble(2, order.getTotalAmount());
            pstmt.setString(3, order.getStatus().name());
            pstmt.setTimestamp(4, new Timestamp(order.getCreateTime().getTime()));

            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getLong(1); // 返回自增ID
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * 插入订单明细
     */
    public boolean insertOrderItem(OrderItem item) {
        String sql = "INSERT INTO tblOrderItem (orderId, productId, quantity, unitPrice) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, item.getOrderId());
            pstmt.setInt(2, item.getProductId());
            pstmt.setInt(3, item.getQuantity());
            pstmt.setDouble(4, item.getUnitPrice());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void setUserIdParam(PreparedStatement pstmt, int index, String userId) throws SQLException {
        try {
            pstmt.setLong(index, Long.parseLong(userId));
        } catch (NumberFormatException e) {
            pstmt.setString(index, userId);
        }
    }
}
