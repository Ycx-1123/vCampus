package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserAccountDao {

    private static final String DB_URL = "jdbc:ucanaccess://./vCampus.accdb;ignoreCase=true;newDatabaseVersion=V2019";

    public double getBalance(String userId, String accountType) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) { 
            return getBalance(conn, userId, accountType);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public double getBalance(Connection conn, String userId, String accountType) throws SQLException {
        if ("BANK".equalsIgnoreCase(accountType)) {
            double bankBalance = queryBalance(conn,
                    "SELECT balance FROM tbl_bank_account WHERE holderCard = ? AND status = 1", userId);
            if (bankBalance >= 0) return bankBalance;

            return queryBalance(conn, "SELECT balance FROM tblUserAccount WHERE userId = ?", userId);
        }

        double studentBalance = queryBalance(conn, "SELECT sbalance FROM tbl_student WHERE sCard = ?", userId);
        if (studentBalance >= 0) return studentBalance;

        double teacherBalance = queryBalance(conn, "SELECT tbalance FROM tbl_teacher WHERE tcard = ?", userId);
        if (teacherBalance >= 0) return teacherBalance;

        return queryBalance(conn, "SELECT balance FROM tblUserAccount WHERE userId = ?", userId);
    }

    public boolean deductBalance(String userId, String accountType, double amount) {
        if (amount <= 0 || !isValidAccountType(accountType)) return false;
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            return deductBalance(conn, userId, accountType, amount);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deductBalance(Connection conn, String userId, String accountType, double amount) throws SQLException {
        if (amount <= 0 || !isValidAccountType(accountType)) return false;
        if ("BANK".equalsIgnoreCase(accountType)) {
            if (updateBalance(conn,
                    "UPDATE tbl_bank_account SET balance = balance - ? WHERE holderCard = ? AND status = 1 AND balance >= ?",
                    userId, amount)) return true;
            return updateBalance(conn,
                    "UPDATE tblUserAccount SET balance = balance - ? WHERE userId = ? AND balance >= ?",
                    userId, amount);
        }

        if (updateBalance(conn, "UPDATE tbl_student SET sbalance = sbalance - ? WHERE sCard = ? AND sbalance >= ?", userId, amount)) return true;
        if (updateBalance(conn, "UPDATE tbl_teacher SET tbalance = tbalance - ? WHERE tcard = ? AND tbalance >= ?", userId, amount)) return true;
        return updateBalance(conn, "UPDATE tblUserAccount SET balance = balance - ? WHERE userId = ? AND balance >= ?", userId, amount);
    }

    public boolean addBalance(String userId, String accountType, double amount) {
        if (amount <= 0 || !isValidAccountType(accountType)) return false;
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            if ("BANK".equalsIgnoreCase(accountType)) {
                if (updateBalance(conn, "UPDATE tbl_bank_account SET balance = balance + ? WHERE holderCard = ? AND status = 1", userId, amount)) return true;
                return updateBalance(conn, "UPDATE tblUserAccount SET balance = balance + ? WHERE userId = ?", userId, amount);
            }

            if (updateBalance(conn, "UPDATE tbl_student SET sbalance = sbalance + ? WHERE sCard = ?", userId, amount)) return true;
            if (updateBalance(conn, "UPDATE tbl_teacher SET tbalance = tbalance + ? WHERE tcard = ?", userId, amount)) return true;
            return updateBalance(conn, "UPDATE tblUserAccount SET balance = balance + ? WHERE userId = ?", userId, amount);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean isValidAccountType(String accountType) {
        return "CARD".equalsIgnoreCase(accountType) || "BANK".equalsIgnoreCase(accountType);
    }

    private double queryBalance(Connection conn, String sql, String userId) throws SQLException {
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return -1;
    }

    private boolean updateBalance(Connection conn, String sql, String userId, double amount) throws SQLException {
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, amount);
            pstmt.setString(2, userId);
            if (sql.contains(">= ?")) {
                pstmt.setDouble(3, amount);
            }
            return pstmt.executeUpdate() > 0;
        }
    }
}
