package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import vCampus.common.vo.BookRecommendation;

/** 数据访问类：对应 tbl_book_recommendation。 */
public class BookRecommendationDao {

    public boolean add(BookRecommendation recommendation) throws SQLException {
        try (Connection connection = DBUtil.getConnection()) {
            String readerIdColumn = readerIdColumn(connection);
            String sql = "INSERT INTO tbl_book_recommendation "
                    + "(recommendationId, " + readerIdColumn + ", recommenderType, bookName, author, publisher, categoryId, recommendReason, recommendTime, status) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nextId(connection));
            statement.setString(2, recommendation.getReaderCardId());
            statement.setString(3, recommendation.getRecommenderType());
            statement.setString(4, recommendation.getBookName());
            statement.setString(5, recommendation.getAuthor());
            statement.setString(6, recommendation.getPublisher());
            statement.setString(7, recommendation.getCategoryId());
            statement.setString(8, recommendation.getReason());
            statement.setTimestamp(9, Timestamp.valueOf(recommendation.getRecommendTime() == null
                    ? LocalDateTime.now() : recommendation.getRecommendTime()));
            statement.setString(10, BookRecommendation.STATUS_PENDING);
            return statement.executeUpdate() == 1;
            }
        }
    }

    public List<BookRecommendation> findByTeacherCardId(String teacherCardId) throws SQLException {
        List<BookRecommendation> results = new ArrayList<>();
        try (Connection connection = DBUtil.getConnection()) {
            String readerIdColumn = readerIdColumn(connection);
            // Access/UCanAccess 不允许 SELECT * 后再追加别名列：可能与表内已有字段重名。
            // 因此明确列出页面需要的字段，同时将新旧读者字段统一别名为 recommendationReaderId。
            String sql = "SELECT recommendationId, " + readerIdColumn + " AS recommendationReaderId, "
                    + "recommenderType, bookName, author, publisher, categoryId, recommendReason, recommendTime, status "
                    + "FROM tbl_book_recommendation WHERE " + readerIdColumn + "=? ORDER BY recommendTime DESC";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, teacherCardId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) results.add(mapRow(resultSet));
                }
            }
        }
        return results;
    }

    /** 按相同书名、作者、出版社、图书分类号合并，分别统计教师与学生荐书。 */
    public List<BookRecommendation> findProcurementReferences() throws SQLException {
        Map<String, BookRecommendation> grouped = new LinkedHashMap<>();
        String sql = "SELECT bookName, author, publisher, categoryId, recommenderType "
                + "FROM tbl_book_recommendation WHERE status='PENDING' ORDER BY bookName";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String bookName = resultSet.getString("bookName");
                String author = resultSet.getString("author");
                String publisher = resultSet.getString("publisher");
                String categoryId = resultSet.getString("categoryId");
                String key = safeKey(bookName) + "\u0001" + safeKey(author) + "\u0001"
                        + safeKey(publisher) + "\u0001" + safeKey(categoryId);
                BookRecommendation recommendation = grouped.get(key);
                if (recommendation == null) {
                    recommendation = new BookRecommendation();
                    recommendation.setBookName(bookName);
                    recommendation.setAuthor(author);
                    recommendation.setPublisher(publisher);
                    recommendation.setCategoryId(categoryId);
                    grouped.put(key, recommendation);
                }
                if ("TEACHER".equalsIgnoreCase(resultSet.getString("recommenderType"))) {
                    recommendation.setTeacherRecommendationCount(recommendation.getTeacherRecommendationCount() + 1);
                } else {
                    // 旧记录没有类别时按学生的基础权重计入，避免历史数据被忽略。
                    recommendation.setStudentRecommendationCount(recommendation.getStudentRecommendationCount() + 1);
                }
            }
        }
        List<BookRecommendation> results = new ArrayList<>(grouped.values());
        for (BookRecommendation item : results) {
            item.setRecommendationCount(item.getTeacherRecommendationCount() * 2
                    + item.getStudentRecommendationCount());
        }
        return results;
    }

    private BookRecommendation mapRow(ResultSet resultSet) throws SQLException {
        BookRecommendation recommendation = new BookRecommendation();
        recommendation.setRecommendationId(resultSet.getString("recommendationId"));
        recommendation.setReaderCardId(resultSet.getString("recommendationReaderId"));
        recommendation.setRecommenderType(resultSet.getString("recommenderType"));
        recommendation.setBookName(resultSet.getString("bookName"));
        recommendation.setAuthor(resultSet.getString("author"));
        recommendation.setPublisher(resultSet.getString("publisher"));
        recommendation.setCategoryId(resultSet.getString("categoryId"));
        recommendation.setReason(resultSet.getString("recommendReason"));
        Timestamp time = resultSet.getTimestamp("recommendTime");
        recommendation.setRecommendTime(time == null ? null : time.toLocalDateTime());
        recommendation.setStatus(resultSet.getString("status"));
        return recommendation;
    }

    private String nextId(Connection connection) throws SQLException {
        int max = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT recommendationId FROM tbl_book_recommendation");
                ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String id = resultSet.getString(1);
                if (id != null && id.matches("RC\\d+")) max = Math.max(max, Integer.parseInt(id.substring(2)));
            }
        }
        return String.format("RC%04d", max + 1);
    }

    private String safeKey(String value) {
        return value == null ? "" : value;
    }

    /** 兼容数据库升级过程：优先使用规范列 readerId，旧表仍可继续使用 teacherCardId。 */
    private String readerIdColumn(Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM tbl_book_recommendation WHERE 1=0");
                ResultSet resultSet = statement.executeQuery()) {
            java.sql.ResultSetMetaData metaData = resultSet.getMetaData();
            boolean hasLegacyColumn = false;
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                String name = metaData.getColumnLabel(i);
                if ("readerId".equalsIgnoreCase(name)) return "readerId";
                if ("teacherCardId".equalsIgnoreCase(name)) hasLegacyColumn = true;
            }
            if (hasLegacyColumn) return "teacherCardId";
        }
        throw new SQLException("tbl_book_recommendation 缺少 readerId 字段");
    }
}
