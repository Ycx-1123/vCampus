package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.StayStatus;
import vCampus.common.vo.Dormitory;

/**
 * 宿舍数据访问类。
 */
public class DormitoryDAO {

    // 查询全部宿舍
    public List<Dormitory> queryAll() {
        List<Dormitory> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "SELECT dormId, building, roomNumber, gender, "
                    + "capacity, occupied, feePerSemester "
                    + "FROM tbl_dormitory";

            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                list.add(toDormitory(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }

        return list;
    }


    // 查询有空余床位的宿舍
    public List<Dormitory> queryAvailable() {
        List<Dormitory> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "SELECT dormId, building, roomNumber, gender, "
                    + "capacity, occupied, feePerSemester "
                    + "FROM tbl_dormitory "
                    + "WHERE occupied < capacity";

            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                list.add(toDormitory(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }

        return list;
    }


    // 根据宿舍编号查询
    public Dormitory findById(String dormId) {
        Dormitory dorm = null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "SELECT dormId, building, roomNumber, gender, "
                    + "capacity, occupied, feePerSemester "
                    + "FROM tbl_dormitory "
                    + "WHERE dormId=?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dormId);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                dorm = toDormitory(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }

        return dorm;
    }


    // 判断宿舍是否存在
    private boolean exists(String dormId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "SELECT dormId FROM tbl_dormitory WHERE dormId=?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dormId);

            rs = pstmt.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
    }


    // 新增宿舍
    public boolean insert(Dormitory dorm) {

        if (dorm == null || exists(dorm.getDormId())) {
            return false;
        }

        if (dorm.getCapacity() <= 0 ||
                dorm.getOccupied() < 0 ||
                dorm.getOccupied() > dorm.getCapacity()) {
            return false;
        }

        if (!"MALE".equals(dorm.getGender()) &&
                !"FEMALE".equals(dorm.getGender())) {
            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "INSERT INTO tbl_dormitory "
                    + "(dormId,building,roomNumber,gender,"
                    + "capacity,occupied,feePerSemester) "
                    + "VALUES(?,?,?,?,?,?,?)";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, dorm.getDormId());
            pstmt.setString(2, dorm.getBuilding());
            pstmt.setString(3, dorm.getRoomNumber());
            pstmt.setString(4, dorm.getGender());
            pstmt.setInt(5, dorm.getCapacity());
            pstmt.setInt(6, dorm.getOccupied());
            pstmt.setDouble(7, dorm.getFeePerSemester());

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }


    // 修改宿舍
    public boolean update(Dormitory dorm) {

        if (dorm == null ||
                !exists(dorm.getDormId()) ||
                dorm.getCapacity() < dorm.getOccupied()) {
            return false;
        }

        if (!"MALE".equals(dorm.getGender()) &&
                !"FEMALE".equals(dorm.getGender())) {
            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "UPDATE tbl_dormitory SET "
                    + "building=?,"
                    + "roomNumber=?,"
                    + "gender=?,"
                    + "capacity=?,"
                    + "occupied=?,"
                    + "feePerSemester=? "
                    + "WHERE dormId=?";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, dorm.getBuilding());
            pstmt.setString(2, dorm.getRoomNumber());
            pstmt.setString(3, dorm.getGender());
            pstmt.setInt(4, dorm.getCapacity());
            pstmt.setInt(5, dorm.getOccupied());
            pstmt.setDouble(6, dorm.getFeePerSemester());
            pstmt.setString(7, dorm.getDormId());

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }


    // 判断宿舍是否有人入住
    private boolean hasAccommodation(String dormId) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();

            String sql = "SELECT recordId FROM tbl_accommodation "
                    + "WHERE dormId=? AND status=?";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, dormId);
            pstmt.setString(2, StayStatus.IN.name());

            rs = pstmt.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return true;

        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
    }


    // 删除宿舍
    public boolean delete(String dormId) {

        if (hasAccommodation(dormId)) {
            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();

            String sql =
                    "DELETE FROM tbl_dormitory WHERE dormId=?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dormId);

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }


    // 更新入住人数
    public boolean updateOccupied(String dormId, int newOccupied) {

        if (!exists(dormId) || newOccupied < 0) {
            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();

            String sql =
                    "UPDATE tbl_dormitory "
                    + "SET occupied=? "
                    + "WHERE dormId=?";

            pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, newOccupied);
            pstmt.setString(2, dormId);

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }


    // ResultSet转换
    private Dormitory toDormitory(ResultSet rs)
            throws SQLException {

        Dormitory dorm = new Dormitory();

        dorm.setDormId(
                rs.getString("dormId")
        );

        dorm.setBuilding(
                rs.getString("building")
        );

        dorm.setRoomNumber(
                rs.getString("roomNumber")
        );

        dorm.setGender(
                rs.getString("gender")
        );

        dorm.setCapacity(
                rs.getInt("capacity")
        );

        dorm.setOccupied(
                rs.getInt("occupied")
        );

        dorm.setFeePerSemester(
                rs.getDouble("feePerSemester")
        );

        return dorm;
    }
}