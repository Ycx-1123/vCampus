package vCampus.server.dao;

import vCampus.common.vo.Teacher;
import vCampus.common.vo.LibraryReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 教师表（tbl_teacher）数据访问对象
 * 主键：tcard（一卡通号）
 */
public class TeacherDao {

    // ============================================================
    // 一、私有映射方法
    // ============================================================

    private Teacher mapRow(ResultSet rs) throws SQLException {
        Teacher t = new Teacher();
        t.setTeacherCard(rs.getString("tcard"));
        t.setPassword(rs.getString("tpassword"));
        t.setTeacherName(rs.getString("tname"));
        t.setTeacherNum(rs.getString("tId"));
        t.setGender(rs.getString("tgender"));
        t.setDepartment(rs.getString("tdepartment"));
        t.setTitle(rs.getString("ttitle"));
        t.setPhone(rs.getString("tphone"));
        t.setEmail(rs.getString("temail"));
        t.setAddress(rs.getString("taddress"));
        t.setOffice(rs.getString("toffice"));
        t.setBalance(rs.getDouble("tbalance"));
        t.setStatus(rs.getString("tstatus"));
        return t;
    }

    // ============================================================
    // 二、查询方法
    // ============================================================

    /**
     * 根据一卡通号（主键）查询教师
     */
    public Teacher getByCard(String teacherCard) throws SQLException {
        String sql = "SELECT * FROM tbl_teacher WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherCard);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /**
     * 根据教工号（tId）查询教师
     */
    public Teacher getByTeacherNum(String teacherNum) throws SQLException {
        String sql = "SELECT * FROM tbl_teacher WHERE tId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherNum);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /**
     * 获取所有教师列表
     */
    public List<Teacher> getAll() throws SQLException {
        List<Teacher> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_teacher ORDER BY tcard";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    /**
     * 根据学院查询教师
     */
    public List<Teacher> getByDepartment(String department) throws SQLException {
        List<Teacher> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_teacher WHERE tdepartment = ? ORDER BY tcard";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, department);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    /**
     * 根据职称查询教师
     */
    public List<Teacher> getByTitle(String title) throws SQLException {
        List<Teacher> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_teacher WHERE ttitle = ? ORDER BY tcard";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, title);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    /**
     * 搜索教师（支持一卡通号、教工号、姓名）
     */
    public List<Teacher> search(String keyword) throws SQLException {
        List<Teacher> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_teacher WHERE tcard LIKE ? OR tId LIKE ? OR tname LIKE ? ORDER BY tcard";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    /**
     * 教师登录验证（一卡通号 + 密码）
     */
    public Teacher checkLogin(String teacherCard, String password) throws SQLException {
        String sql = "SELECT * FROM tbl_teacher WHERE tcard = ? AND tpassword = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherCard);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /**
     * 检查一卡通号是否存在
     */
    public boolean exists(String teacherCard) throws SQLException {
        String sql = "SELECT 1 FROM tbl_teacher WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherCard);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ============================================================
    // 三、插入方法
    // ============================================================

    public void insert(Teacher teacher) throws SQLException {
        String sql = "INSERT INTO tbl_teacher (tcard, tpassword, tname, tId, tgender, tdepartment, " +
                     "ttitle, tphone, temail, taddress, toffice, tbalance, tstatus) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);
            try {
            pstmt.setString(1, teacher.getTeacherCard());
            pstmt.setString(2, teacher.getPassword());
            pstmt.setString(3, teacher.getTeacherName());
            pstmt.setString(4, teacher.getTeacherNum());
            pstmt.setString(5, teacher.getGender());
            pstmt.setString(6, teacher.getDepartment());
            pstmt.setString(7, teacher.getTitle());
            pstmt.setString(8, teacher.getPhone());
            pstmt.setString(9, teacher.getEmail());
            pstmt.setString(10, teacher.getAddress());
            pstmt.setString(11, teacher.getOffice());
            pstmt.setDouble(12, teacher.getBalance());
            pstmt.setString(13, teacher.getStatus());
            pstmt.executeUpdate();
            // 教师新增成功后，自动创建默认可借的图书馆读者记录。
            new LibraryReaderDao().ensureReader(conn, teacher.getTeacherCard(), LibraryReader.TYPE_TEACHER);
            conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    // ============================================================
    // 四、更新方法
    // ============================================================

    public void update(Teacher teacher) throws SQLException {
        String sql = "UPDATE tbl_teacher SET tpassword = ?, tname = ?, tId = ?, tgender = ?, " +
                     "tdepartment = ?, ttitle = ?, tphone = ?, temail = ?, taddress = ?, " +
                     "toffice = ?, tbalance = ?, tstatus = ? WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacher.getPassword());
            pstmt.setString(2, teacher.getTeacherName());
            pstmt.setString(3, teacher.getTeacherNum());
            pstmt.setString(4, teacher.getGender());
            pstmt.setString(5, teacher.getDepartment());
            pstmt.setString(6, teacher.getTitle());
            pstmt.setString(7, teacher.getPhone());
            pstmt.setString(8, teacher.getEmail());
            pstmt.setString(9, teacher.getAddress());
            pstmt.setString(10, teacher.getOffice());
            pstmt.setDouble(11, teacher.getBalance());
            pstmt.setString(12, teacher.getStatus());
            pstmt.setString(13, teacher.getTeacherCard());
            pstmt.executeUpdate();
        }
    }

    public void updateStatus(String teacherCard, String status) throws SQLException {
        String sql = "UPDATE tbl_teacher SET tstatus = ? WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setString(2, teacherCard);
            pstmt.executeUpdate();
        }
    }

    public void updatePassword(String teacherCard, String newPassword) throws SQLException {
        String sql = "UPDATE tbl_teacher SET tpassword = ? WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newPassword);
            pstmt.setString(2, teacherCard);
            pstmt.executeUpdate();
        }
    }

    // ============================================================
    // 五、删除方法
    // ============================================================

    public void delete(String teacherCard) throws SQLException {
        String sql = "DELETE FROM tbl_teacher WHERE tcard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherCard);
            pstmt.executeUpdate();
        }
    }

    // ============================================================
    // 六、统计方法
    // ============================================================

    public int count() throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_teacher";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public int countByDepartment(String department) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_teacher WHERE tdepartment = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, department);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    // ============================================================
    // 七、测试方法
    // ============================================================

    public static void main(String[] args) {
        TeacherDao dao = new TeacherDao();

        try {
            System.out.println("=== 测试：查询所有教师 ===");
            List<Teacher> all = dao.getAll();
            System.out.println("共 " + all.size() + " 位教师");
            for (Teacher t : all) {
                System.out.println("  " + t.getTeacherCard() + " | " + t.getTeacherNum() + " | " +
                                   t.getTeacherName() + " | " + t.getTitle());
            }

            System.out.println("\n=== 测试：根据一卡通号查询 ===");
            Teacher t = dao.getByCard("T001");
            if (t != null) {
                System.out.println("  一卡通号：" + t.getTeacherCard());
                System.out.println("  教工号：" + t.getTeacherNum());
                System.out.println("  姓名：" + t.getTeacherName());
                System.out.println("  职称：" + t.getTitle());
            }

            System.out.println("\n=== 测试：统计总数 ===");
            System.out.println("教师总数：" + dao.count());

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
