package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.vo.BookCategory;

/** 数据访问类：对应 tbl_book_category。 */
public class BookCategoryDao {

    public List<BookCategory> findAll() throws SQLException {
        List<BookCategory> categories = new ArrayList<>();
        String sql = "SELECT * FROM tbl_book_category ORDER BY categoryId";
        try (Connection connection = DBUtil.getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                categories.add(mapRow(resultSet));
            }
        }
        return categories;
    }

    public BookCategory findById(String categoryId) throws SQLException {
        String sql = "SELECT * FROM tbl_book_category WHERE categoryId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, categoryId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapRow(resultSet) : null;
            }
        }
    }

    public boolean add(BookCategory category) throws SQLException {
        String sql = "INSERT INTO tbl_book_category (categoryId, categoryName, description) VALUES (?, ?, ?)";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, category.getCategoryId());
            statement.setString(2, category.getCategoryName());
            statement.setString(3, category.getDescription());
            return statement.executeUpdate() == 1;
        }
    }

    public boolean update(BookCategory category) throws SQLException {
        String sql = "UPDATE tbl_book_category SET categoryName = ?, description = ? WHERE categoryId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, category.getCategoryName());
            statement.setString(2, category.getDescription());
            statement.setString(3, category.getCategoryId());
            return statement.executeUpdate() == 1;
        }
    }

    public boolean delete(String categoryId) throws SQLException {
        String checkSql = "SELECT COUNT(*) FROM tbl_book WHERE categoryId = ?";
        String deleteSql = "DELETE FROM tbl_book_category WHERE categoryId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement check = connection.prepareStatement(checkSql)) {
            check.setString(1, categoryId);
            try (ResultSet resultSet = check.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    throw new SQLException("该分类下还有图书，不能删除：" + categoryId);
                }
            }
            try (PreparedStatement delete = connection.prepareStatement(deleteSql)) {
                delete.setString(1, categoryId);
                return delete.executeUpdate() == 1;
            }
        }
    }

    private BookCategory mapRow(ResultSet resultSet) throws SQLException {
        return new BookCategory(resultSet.getString("categoryId"), resultSet.getString("categoryName"),
                resultSet.getString("description"));
    }
}
