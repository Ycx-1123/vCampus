package vCampus.server.dao;

import vCampus.common.vo.Admin;
import vCampus.common.vo.Student;
import vCampus.common.vo.Teacher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {

    public Object checkLogin(String cardId, String password) {
        return loginCheck(cardId, password);
    }

    public Object loginCheck(String cardId, String password) {
        Student userStu = checkStudentLogin(cardId, password);
        if (userStu != null) return userStu;

        Teacher userTea = checkTeacherLogin(cardId, password);
        if (userTea != null) return userTea;

        Admin userAdmin = checkAdminLogin(cardId, password);
        if (userAdmin != null) return userAdmin;

        return null;
    }

    private Student checkStudentLogin(String cardId, String password) {
        String sql = "SELECT * FROM tbl_student WHERE sCard = ? AND spassword = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cardId);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Student student = extractStudentFromResultSet(rs);
                    student.setSdepartment("STUDENT"); 
                    return student;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Teacher checkTeacherLogin(String cardId, String password) {
        String sql = "SELECT * FROM tbl_teacher WHERE tCard = ? AND tpassword = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cardId);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Teacher teacher = new Teacher();
                    teacher.setTeacherId(rs.getString("tId"));
                    // 图书馆模块以教师的校园卡号作为读者编号。
                    teacher.setCardNumber(rs.getString("tCard"));
                    teacher.setTeacherName(rs.getString("tname"));
                    teacher.setDepartment("TEACHER"); 
                    return teacher;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Admin checkAdminLogin(String cardId, String password) {
        String sql = "SELECT * FROM tbl_admin WHERE aCard = ? AND apassword = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cardId);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Admin admin = new Admin();
                    admin.setAId(rs.getString("aId"));
                    admin.setAName(rs.getString("aname"));
                    admin.setACard(rs.getString("aCard"));
                    admin.setADepartment("ADMIN"); 

                    admin.setManageStudent(rs.getBoolean("manageStudent"));
                    admin.setManageCourse(rs.getBoolean("manageCourse"));
                    admin.setManageLibrary(rs.getBoolean("manageLibrary"));
                    admin.setManageDorm(rs.getBoolean("manageDorm"));
                    admin.setManageShop(rs.getBoolean("manageShop"));
                    admin.setManageBank(rs.getBoolean("manageBank"));
                    
                    return admin;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Student getStudentById(String sCard) {
        String sql = "SELECT * FROM tbl_student WHERE sCard = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, sCard);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return extractStudentFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Student extractStudentFromResultSet(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setSId(rs.getString("sId"));
        student.setSname(rs.getString("sname"));
        student.setSpassword(rs.getString("spassword"));
        student.setSgender(rs.getString("sgender"));
        student.setSdepartment(rs.getString("sdepartment"));
        student.setSphone(rs.getString("sphone"));
        student.setSemail(rs.getString("semail"));
        student.setSaddress(rs.getString("saddress"));
        student.setSbalance(rs.getDouble("sbalance"));
        student.setSstatus(rs.getString("sstatus"));
        student.setSCard(rs.getString("sCard"));
        return student;
    }
    
    public boolean verifyAccountAndPhone(String role, String card, String phone) {
        String sql = "";
        
        // 根据角色分配对应的查询 SQL
        if ("Student".equalsIgnoreCase(role)) {
            sql = "SELECT sphone FROM tbl_student WHERE sCard = ?";
        } else if ("Teacher".equalsIgnoreCase(role)) {
            sql = "SELECT tphone FROM tbl_teacher WHERE tCard = ?";
        } else if ("Admin".equalsIgnoreCase(role)) {
            sql = "SELECT aphone FROM tbl_admin WHERE aCard = ?"; 
        } else {
            return false;
        }

        // 修复点：使用 DBUtil.getConnection() 正确获取并自动关闭连接
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String cleanCard = card.replaceAll("\\s+", "");
            pstmt.setString(1, cleanCard);
            
            System.out.println("[DEBUG] Executing query for Card: [" + cleanCard + "]");
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String dbPhone = rs.getString(1);
                    
                    if (dbPhone != null) {
                        // 清理数据库和输入的空格及不可见字符
                        String cleanDbPhone = dbPhone.replaceAll("[\\s\\u0000]+", "");
                        String cleanInputPhone = phone.replaceAll("\\s+", "");
                        
                        System.out.println("[DEBUG] Database Phone: [" + cleanDbPhone + "] Length: " + cleanDbPhone.length());
                        System.out.println("[DEBUG] User Input Phone: [" + cleanInputPhone + "] Length: " + cleanInputPhone.length());
                        
                        // 比对手机号是否一致
                        return cleanInputPhone.equals(cleanDbPhone);
                    } else {
                        System.out.println("[DEBUG] Match failed: Phone number in database is NULL.");
                    }
                } else {
                    System.out.println("[DEBUG] Match failed: No record found for Card [" + cleanCard + "]");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false; // 发生异常或未匹配时返回 false
    }
    public boolean updatePassword(String role, String cardId, String newPassword) {
        String sql = "";
        
        // 根据角色分配对应的更新 SQL
        if ("Student".equalsIgnoreCase(role)) {
            sql = "UPDATE tbl_student SET spassword = ? WHERE sCard = ?";
        } else if ("Teacher".equalsIgnoreCase(role)) {
            sql = "UPDATE tbl_teacher SET tpassword = ? WHERE tCard = ?";
        } else if ("Admin".equalsIgnoreCase(role)) {
            sql = "UPDATE tbl_admin SET apassword = ? WHERE aCard = ?";
        } else {
            return false;
        }

        // 使用 DBUtil 获取连接，利用 try-with-resources 自动释放资源
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // 清理一卡通号两端的空格以防匹配失败
            String cleanCard = cardId.replaceAll("\\s+", "");
            
            pstmt.setString(1, newPassword);
            pstmt.setString(2, cleanCard);
            
            // 执行更新操作，返回受影响的行数
            int rows = pstmt.executeUpdate();
            return rows > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    /**
     * 自动识别角色并修改密码：
     * 先后检查 Student、Teacher、Admin 表，匹配卡号和手机号，通过后修改密码。
     */
    public boolean autoVerifyAndResetPassword(String cardId, String phone, String newPassword) {
        String cleanCard = cardId != null ? cardId.replaceAll("\\s+", "") : "";
        String cleanPhone = phone != null ? phone.replaceAll("\\s+", "") : "";
        
        if (cleanCard.isEmpty() || cleanPhone.isEmpty() || newPassword == null) {
            return false;
        }

        // 1. 尝试在学生表中查找并更新
        if (checkAndResetTable("tbl_student", "sCard", "sphone", "spassword", cleanCard, cleanPhone, newPassword)) {
            return true;
        }
        
        // 2. 尝试在教师表中查找并更新
        if (checkAndResetTable("tbl_teacher", "tCard", "tphone", "tpassword", cleanCard, cleanPhone, newPassword)) {
            return true;
        }
        
        // 3. 尝试在管理员表中查找并更新
        if (checkAndResetTable("tbl_admin", "aCard", "aphone", "apassword", cleanCard, cleanPhone, newPassword)) {
            return true;
        }
        
        return false;
    }

    /**
     * 内部辅助方法：针对指定表检查卡号和手机号，若匹配则更新密码
     */
    private boolean checkAndResetTable(String tableName, String cardCol, String phoneCol, String pwdCol, 
                                       String card, String phone, String newPassword) {
        String selectSql = "SELECT " + phoneCol + " FROM " + tableName + " WHERE " + cardCol + " = ?";
        String updateSql = "UPDATE " + tableName + " SET " + pwdCol + " = ? WHERE " + cardCol + " = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmtSelect = conn.prepareStatement(selectSql)) {
            
            pstmtSelect.setString(1, card);
            try (ResultSet rs = pstmtSelect.executeQuery()) {
                if (rs.next()) {
                    String dbPhone = rs.getString(1);
                    if (dbPhone != null) {
                        String cleanDbPhone = dbPhone.replaceAll("[\\s\\u0000]+", "");
                        // 手机号匹配成功
                        if (phone.equals(cleanDbPhone)) {
                            // 执行更新密码
                            try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql)) {
                                pstmtUpdate.setString(1, newPassword);
                                pstmtUpdate.setString(2, card);
                                return pstmtUpdate.executeUpdate() > 0;
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    /**
     * 自动验证用户一卡通号与手机号是否匹配，并返回数据库中绑定的邮箱。
     * @param cardId 一卡通号
     * @param phone 手机号
     * @return 如果匹配成功，返回邮箱地址（若未绑定邮箱则返回空字符串""）；如果匹配失败，返回 null
     */
    public String verifyUserInfoAndGetEmail(String cardId, String phone) {
        String cleanCard = cardId != null ? cardId.replaceAll("\\s+", "") : "";
        String cleanPhone = phone != null ? phone.replaceAll("\\s+", "") : "";
        
        if (cleanCard.isEmpty() || cleanPhone.isEmpty()) {
            return null;
        }

        // 1. 尝试在学生表中查找并获取 semail
        String email = checkTableAndGetEmail("tbl_student", "sCard", "sphone", "semail", cleanCard, cleanPhone);
        if (email != null) return email;
        
        // 2. 尝试在教师表中查找并获取 temail
        email = checkTableAndGetEmail("tbl_teacher", "tCard", "tphone", "temail", cleanCard, cleanPhone);
        if (email != null) return email;
        
        // 3. 尝试在管理员表中查找并获取 aemail
        email = checkTableAndGetEmail("tbl_admin", "aCard", "aphone", "aemail", cleanCard, cleanPhone);
        if (email != null) return email;
        
        return null; // 均未找到或匹配失败
    }

    /**
     * 内部辅助方法：针对指定表检查卡号和手机号，若匹配则返回邮箱地址
     */
    private String checkTableAndGetEmail(String tableName, String cardCol, String phoneCol, String emailCol, 
                                         String card, String phone) {
        String selectSql = "SELECT " + phoneCol + ", " + emailCol + " FROM " + tableName + " WHERE " + cardCol + " = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
            
            pstmt.setString(1, card);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String dbPhone = rs.getString(1);
                    if (dbPhone != null) {
                        // 清理数据库中的空格及不可见字符
                        String cleanDbPhone = dbPhone.replaceAll("[\\s\\u0000]+", "");
                        
                        // 手机号匹配成功
                        if (phone.equals(cleanDbPhone)) {
                            String email = rs.getString(2);
                            // 若邮箱存在则返回去空后的邮箱，否则返回空字符串防止返回 null 误判为验证失败
                            return email != null ? email.trim() : ""; 
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
