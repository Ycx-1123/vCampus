package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.ApplicationStatus;
import vCampus.common.enums.ApplicationType;
import vCampus.common.vo.DormApplication;


public class DormApplicationDAO {


    // 新增申请
    public boolean insert(DormApplication application) {

        if(application == null)
            return false;

        if(hasPendingApplication(application.getsId()))
            return false;

        if(application.getStatus() == null)
            application.setStatus(ApplicationStatus.PENDING);

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "INSERT INTO tbl_dorm_application "
                    + "(sId,accommodationId,type,currentDormId,"
                    + "currentBedNumber,targetDormId,targetBedNumber,"
                    + "reason,status,submitTime)"
                    + " VALUES(?,?,?,?,?,?,?,?,?,?)";


            pstmt = conn.prepareStatement(
                    sql,
                    Statement.RETURN_GENERATED_KEYS
            );
            
            pstmt.setString(1, application.getsId());
            pstmt.setInt(2, application.getAccommodationId());
            pstmt.setString(3, application.getType().name());
            pstmt.setString(4, application.getCurrentDormId());
            pstmt.setString(5, application.getCurrentBedNumber());
            pstmt.setString(6, application.getTargetDormId());
            pstmt.setString(7, application.getTargetBedNumber());
            pstmt.setString(8, application.getReason());
            pstmt.setString(9, application.getStatus().name());

            if(application.getSubmitTime()!=null)
                pstmt.setTimestamp(
                        10,
                        new Timestamp(application.getSubmitTime().getTime()));
            else
                pstmt.setTimestamp(10,null);


            int result =
                    pstmt.executeUpdate();

            if (result > 0) {

                rs =
                        pstmt.getGeneratedKeys();

                if (rs.next()) {

                    application.setApplicationId(
                            rs.getInt(1)
                    );
                }

                return true;
            }

            return false;

        }catch(Exception e){

            e.printStackTrace();
            return false;

        }finally{

            DBUtil.close(conn,pstmt,rs);
        }
    }



    // 判断是否存在待审核申请
    private boolean hasPendingApplication(String sId){

        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;

        try{

            conn=DBUtil.getConnection();

            String sql =
                    "SELECT applicationId FROM tbl_dorm_application "
                    + "WHERE sId=? AND status=?";

            pstmt=conn.prepareStatement(sql);

            pstmt.setString(1,sId);
            pstmt.setString(
                    2,
                    ApplicationStatus.PENDING.name()
            );

            rs=pstmt.executeQuery();

            return rs.next();


        }catch(Exception e){

            e.printStackTrace();
            return true;

        }finally{

            DBUtil.close(conn,pstmt,rs);
        }
    }



    // 根据编号查询
    public DormApplication findById(int applicationId){

        DormApplication application=null;

        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;

        try{

            conn=DBUtil.getConnection();

            String sql =
                    "SELECT * FROM tbl_dorm_application "
                    + "WHERE applicationId=?";

            pstmt=conn.prepareStatement(sql);
            pstmt.setInt(1,applicationId);

            rs=pstmt.executeQuery();

            if(rs.next())
                application=toDormApplication(rs);


        }catch(Exception e){

            e.printStackTrace();

        }finally{

            DBUtil.close(conn,pstmt,rs);
        }

        return application;
    }



    // 查询学生申请
    public List<DormApplication> queryByStudent(String sId){

        List<DormApplication> list=new ArrayList<>();

        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;

        try{

            conn=DBUtil.getConnection();

            String sql =
                    "SELECT * FROM tbl_dorm_application "
                    + "WHERE sId=? ORDER BY submitTime DESC";


            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,sId);

            rs=pstmt.executeQuery();


            while(rs.next())
                list.add(toDormApplication(rs));


        }catch(Exception e){

            e.printStackTrace();

        }finally{

            DBUtil.close(conn,pstmt,rs);
        }

        return list;
    }



    // 查询待审核申请
    public List<DormApplication> queryPending(){

        List<DormApplication> list=new ArrayList<>();

        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;


        try{

            conn=DBUtil.getConnection();

            String sql =
                    "SELECT * FROM tbl_dorm_application "
                    + "WHERE status=? ORDER BY submitTime";


            pstmt=conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    ApplicationStatus.PENDING.name()
            );


            rs=pstmt.executeQuery();


            while(rs.next())
                list.add(toDormApplication(rs));


        }catch(Exception e){

            e.printStackTrace();

        }finally{

            DBUtil.close(conn,pstmt,rs);
        }

        return list;
    }


    /**
     * 根据申请类型查询申请。
     *
     * @param type 申请类型
     * @return 指定类型的申请列表
     */
    public List<DormApplication> queryByType(
            ApplicationType type) {

        List<DormApplication> list =
                new ArrayList<>();

        if (type == null) {
            return list;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_application "
                    + "WHERE type=? "
                    + "ORDER BY submitTime DESC";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    type.name()
            );

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormApplication(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }
    

    // 修改申请状态
    public boolean updateStatus(
            int applicationId,
            ApplicationStatus status,
            String reviewerId,
            String remark){

        if(status==null)
            return false;


        Connection conn=null;
        PreparedStatement pstmt=null;


        try{

            conn=DBUtil.getConnection();


            String sql =
                    "UPDATE tbl_dorm_application "
                    + "SET status=?,"
                    + "reviewTime=?,"
                    + "reviewerId=?,"
                    + "reviewRemark=? "
                    + "WHERE applicationId=? "
                    + "AND status=?";


            pstmt=conn.prepareStatement(sql);

            pstmt.setString(1,status.name());

            pstmt.setTimestamp(
                    2,
                    new Timestamp(System.currentTimeMillis())
            );

            pstmt.setString(3,reviewerId);
            pstmt.setString(4,remark);
            pstmt.setInt(5,applicationId);
            pstmt.setString(6,ApplicationStatus.PENDING.name());


            return pstmt.executeUpdate()>0;


        }catch(Exception e){

            e.printStackTrace();
            return false;

        }finally{

            DBUtil.close(conn,pstmt,null);
        }
    }



    // 取消申请
    public boolean cancel(int applicationId){

        Connection conn=null;
        PreparedStatement pstmt=null;


        try{

            conn=DBUtil.getConnection();


            String sql =
                    "UPDATE tbl_dorm_application "
                    + "SET status=? "
                    + "WHERE applicationId=? "
                    + "AND status=?";


            pstmt=conn.prepareStatement(sql);


            pstmt.setString(
                    1,
                    ApplicationStatus.CANCELLED.name()
            );

            pstmt.setInt(2,applicationId);

            pstmt.setString(
                    3,
                    ApplicationStatus.PENDING.name()
            );


            return pstmt.executeUpdate()>0;


        }catch(Exception e){

            e.printStackTrace();
            return false;

        }finally{

            DBUtil.close(conn,pstmt,null);
        }
    }



    // ResultSet转换
    private DormApplication toDormApplication(ResultSet rs)
            throws SQLException{


        DormApplication application =
                new DormApplication();


        application.setApplicationId(
                rs.getInt("applicationId")
        );

        application.setsId(
                rs.getString("sId")
        );

        application.setAccommodationId(
                rs.getInt("accommodationId")
        );

        application.setType(
                ApplicationType.valueOf(
                        rs.getString("type")
                )
        );

        application.setCurrentDormId(
                rs.getString("currentDormId")
        );

        application.setCurrentBedNumber(
                rs.getString("currentBedNumber")
        );

        application.setTargetDormId(
                rs.getString("targetDormId")
        );

        application.setTargetBedNumber(
                rs.getString("targetBedNumber")
        );

        application.setReason(
                rs.getString("reason")
        );

        application.setStatus(
                ApplicationStatus.valueOf(
                        rs.getString("status")
                )
        );

        application.setSubmitTime(
                rs.getTimestamp("submitTime")
        );

        application.setReviewTime(
                rs.getTimestamp("reviewTime")
        );

        application.setReviewerId(
                rs.getString("reviewerId")
        );

        application.setReviewRemark(
                rs.getString("reviewRemark")
        );


        return application;
    }
}