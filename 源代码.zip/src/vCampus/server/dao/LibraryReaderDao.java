package vCampus.server.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import vCampus.common.vo.LibraryReader;

/** 数据访问类：对应 tbl_book_reader。 */
public class LibraryReaderDao {

    public LibraryReader findById(String readerId) throws SQLException {
        return findByCardId(readerId);
    }

    /** 用校园卡号查询图书馆读者扩展资料。 */
    public LibraryReader findByCardId(String cardId) throws SQLException {
        String sql = "SELECT * FROM tbl_book_reader WHERE cardId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cardId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapRow(resultSet) : null;
            }
        }
    }

    public boolean add(LibraryReader reader) throws SQLException {
        if (!isValidAccountCard(reader.getCardId(), reader.getReaderType())) {
            throw new SQLException("cardId 未在对应的学生或教师表中找到");
        }
        String sql = "INSERT INTO tbl_book_reader (readerId, cardId, readerType, borrowingBlockedUntil) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            fillStatement(statement, reader, false);
            return statement.executeUpdate() == 1;
        }
    }

    public boolean update(LibraryReader reader) throws SQLException {
        if (!isValidAccountCard(reader.getCardId(), reader.getReaderType())) {
            throw new SQLException("cardId 未在对应的学生或教师表中找到");
        }
        String sql = "UPDATE tbl_book_reader SET cardId = ?, readerType = ?, borrowingBlockedUntil = ? WHERE readerId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            fillStatement(statement, reader, true);
            return statement.executeUpdate() == 1;
        }
    }

    public boolean canBorrow(String readerId, java.time.LocalDate borrowDate) throws SQLException {
        LibraryReader reader = findByCardId(readerId);
        return reader != null && !reader.isBorrowingBlocked(borrowDate);
    }

    public boolean setBlockedUntil(String readerId, java.time.LocalDate blockedUntil) throws SQLException {
        String sql = "UPDATE tbl_book_reader SET borrowingBlockedUntil = ? WHERE cardId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            if (blockedUntil == null) {
                statement.setNull(1, java.sql.Types.DATE);
            } else {
                statement.setDate(1, Date.valueOf(blockedUntil));
            }
            statement.setString(2, readerId);
            return statement.executeUpdate() == 1;
        }
    }

    private void fillStatement(PreparedStatement statement, LibraryReader reader, boolean update) throws SQLException {
        if (update) {
            statement.setString(1, reader.getCardId());
            statement.setString(2, reader.getReaderType());
            if (reader.getBorrowingBlockedUntil() == null) {
                statement.setNull(3, java.sql.Types.DATE);
            } else {
                statement.setDate(3, Date.valueOf(reader.getBorrowingBlockedUntil()));
            }
            statement.setString(4, reader.getReaderId());
        } else {
            statement.setString(1, reader.getReaderId());
            statement.setString(2, reader.getCardId());
            statement.setString(3, reader.getReaderType());
            if (reader.getBorrowingBlockedUntil() == null) {
                statement.setNull(4, java.sql.Types.DATE);
            } else {
                statement.setDate(4, Date.valueOf(reader.getBorrowingBlockedUntil()));
            }
        }
    }

    /**
     * 供学生、教师新增流程调用：在同一数据库事务中确保校园卡已开通图书馆权限。
     * 已存在读者记录时不覆盖禁借截止日期。
     */
    public boolean ensureReader(Connection connection, String cardId, String readerType) throws SQLException {
        if (connection == null || cardId == null || cardId.trim().isEmpty()) {
            throw new SQLException("无法创建图书馆读者：校园卡号为空");
        }
        String card = cardId.trim();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT readerId FROM tbl_book_reader WHERE cardId=?")) {
            query.setString(1, card);
            try (ResultSet resultSet = query.executeQuery()) {
                if (resultSet.next()) return true;
            }
        }
        String insertSql = "INSERT INTO tbl_book_reader (readerId, cardId, readerType, borrowingBlockedUntil) VALUES (?, ?, ?, ?)";
        try (PreparedStatement insert = connection.prepareStatement(insertSql)) {
            // 新建账号阶段以校园卡号作为图书馆读者编号，兼容借阅与预约表的既有设计。
            insert.setString(1, card);
            insert.setString(2, card);
            insert.setString(3, readerType);
            insert.setNull(4, java.sql.Types.DATE);
            return insert.executeUpdate() == 1;
        }
    }

    private LibraryReader mapRow(ResultSet resultSet) throws SQLException {
        LibraryReader reader = new LibraryReader();
        reader.setReaderId(resultSet.getString("readerId"));
        reader.setCardId(resultSet.getString("cardId"));
        reader.setReaderType(resultSet.getString("readerType"));
        Date blockedUntil = resultSet.getDate("borrowingBlockedUntil");
        reader.setBorrowingBlockedUntil(blockedUntil == null ? null : blockedUntil.toLocalDate());
        return reader;
    }

    /** 由 readerType 决定校验哪一张身份表，避免 cardId 错绑。 */
    private boolean isValidAccountCard(String cardId, String readerType) throws SQLException {
        if (cardId == null || cardId.trim().isEmpty()) return false;
        String sql;
        if (LibraryReader.TYPE_STUDENT.equals(readerType)) {
            sql = "SELECT COUNT(*) FROM tbl_student WHERE sCard=?";
        } else if (LibraryReader.TYPE_TEACHER.equals(readerType)) {
            sql = "SELECT COUNT(*) FROM tbl_teacher WHERE tCard=?";
        } else {
            return false;
        }
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cardId.trim());
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        }
    }
}
