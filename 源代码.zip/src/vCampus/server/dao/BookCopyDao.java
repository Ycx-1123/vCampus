package vCampus.server.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.vo.BookCopy;

/** 数据访问类：对应 tbl_book_copy，并负责同步 tbl_book 的库存统计。 */
public class BookCopyDao {

    public BookCopy findById(String copyId) throws SQLException {
        String sql = "SELECT * FROM tbl_book_copy WHERE copyId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, copyId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapRow(resultSet) : null;
            }
        }
    }

    public List<BookCopy> findByBookId(String bookId) throws SQLException {
        List<BookCopy> copies = new ArrayList<>();
        String sql = "SELECT * FROM tbl_book_copy WHERE bookId = ? ORDER BY copyId";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    copies.add(mapRow(resultSet));
                }
            }
        }
        return copies;
    }

    public boolean add(BookCopy copy) throws SQLException {
        String sql = "INSERT INTO tbl_book_copy (copyId, bookId, location, acquiredDate, status, remark, circulationType) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            connection.setAutoCommit(false);
            try {
                fillStatement(statement, copy);
                boolean added = statement.executeUpdate() == 1;
                BookDao.refreshStatistics(connection, copy.getBookId());
                connection.commit();
                return added;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    public boolean update(BookCopy copy) throws SQLException {
        BookCopy oldCopy = findById(copy.getCopyId());
        if (oldCopy == null) {
            return false;
        }
        String sql = "UPDATE tbl_book_copy SET bookId=?, location=?, acquiredDate=?, status=?, remark=?, circulationType=? WHERE copyId=?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            connection.setAutoCommit(false);
            try {
                statement.setString(1, copy.getBookId());
                statement.setString(2, copy.getLocation());
                if (copy.getAcquiredDate() == null) {
                    statement.setNull(3, java.sql.Types.DATE);
                } else {
                    statement.setDate(3, Date.valueOf(copy.getAcquiredDate()));
                }
                statement.setString(4, copy.getStatus());
                statement.setString(5, copy.getRemark());
                statement.setString(6, copy.getCirculationType() == null ? BookCopy.CIRCULATION_CIRCULATING : copy.getCirculationType());
                statement.setString(7, copy.getCopyId());
                boolean updated = statement.executeUpdate() == 1;
                BookDao.refreshStatistics(connection, oldCopy.getBookId());
                if (!oldCopy.getBookId().equals(copy.getBookId())) {
                    BookDao.refreshStatistics(connection, copy.getBookId());
                }
                connection.commit();
                return updated;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    public boolean delete(String copyId) throws SQLException {
        String findSql = "SELECT bookId, status FROM tbl_book_copy WHERE copyId = ?";
        String deleteSql = "DELETE FROM tbl_book_copy WHERE copyId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement find = connection.prepareStatement(findSql)) {
            find.setString(1, copyId);
            String bookId;
            try (ResultSet resultSet = find.executeQuery()) {
                if (!resultSet.next()) {
                    return false;
                }
                bookId = resultSet.getString("bookId");
                if (BookCopy.STATUS_BORROWED.equals(resultSet.getString("status"))) {
                    throw new SQLException("借出中的副本不能删除：" + copyId);
                }
            }
            connection.setAutoCommit(false);
            try (PreparedStatement delete = connection.prepareStatement(deleteSql)) {
                delete.setString(1, copyId);
                boolean deleted = delete.executeUpdate() == 1;
                BookDao.refreshStatistics(connection, bookId);
                connection.commit();
                return deleted;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    private void fillStatement(PreparedStatement statement, BookCopy copy) throws SQLException {
        statement.setString(1, copy.getCopyId());
        statement.setString(2, copy.getBookId());
        statement.setString(3, copy.getLocation());
        if (copy.getAcquiredDate() == null) {
            statement.setNull(4, java.sql.Types.DATE);
        } else {
            statement.setDate(4, Date.valueOf(copy.getAcquiredDate()));
        }
        statement.setString(5, copy.getStatus() == null ? BookCopy.STATUS_AVAILABLE : copy.getStatus());
        statement.setString(6, copy.getRemark());
        statement.setString(7, copy.getCirculationType() == null ? BookCopy.CIRCULATION_CIRCULATING : copy.getCirculationType());
    }

    private BookCopy mapRow(ResultSet resultSet) throws SQLException {
        BookCopy copy = new BookCopy();
        copy.setCopyId(resultSet.getString("copyId"));
        copy.setBookId(resultSet.getString("bookId"));
        copy.setLocation(resultSet.getString("location"));
        Date acquiredDate = resultSet.getDate("acquiredDate");
        copy.setAcquiredDate(acquiredDate == null ? null : acquiredDate.toLocalDate());
        copy.setStatus(resultSet.getString("status"));
        copy.setRemark(resultSet.getString("remark"));
        copy.setCirculationType(resultSet.getString("circulationType"));
        return copy;
    }
}
