package vCampus.server.dao;

import vCampus.common.vo.ProgramCourse;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgramCourseDao {

    private ProgramCourse mapRow(ResultSet rs) throws SQLException {
        ProgramCourse pc = new ProgramCourse();
        pc.setLinkId(rs.getInt("pclinkId"));
        pc.setProgramId(rs.getString("programId"));
        pc.setCourseId(rs.getString("courseId"));
        pc.setCourseType(rs.getString("courseType"));
        pc.setRecommendSemester(rs.getString("recommendSemester"));
        pc.setPrerequisite(rs.getString("prerequisite"));
        pc.setCreditWeight(rs.getInt("creditWeight"));
        return pc;
    }

    //查询

    public List<ProgramCourse> getByProgramId(String programId) throws SQLException {
        List<ProgramCourse> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_programCourse WHERE programId = ? ORDER BY courseId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    //查询某门课在培养方案中的定义（用于获取先修课程）
    public ProgramCourse getByProgramAndCourse(String programId, String courseId) throws SQLException {
        String sql = "SELECT * FROM tbl_programCourse WHERE programId = ? AND courseId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            pstmt.setString(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<ProgramCourse> getByCourseId(String courseId) throws SQLException {
        List<ProgramCourse> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_programCourse WHERE courseId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    //插入

    public void insert(ProgramCourse programCourse) throws SQLException {
        String sql = "INSERT INTO tbl_programCourse (programId, courseId, courseType, recommendSemester, prerequisite, creditWeight) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programCourse.getProgramId());
            pstmt.setString(2, programCourse.getCourseId());
            pstmt.setString(3, programCourse.getCourseType());
            pstmt.setString(4, programCourse.getRecommendSemester());
            pstmt.setString(5, programCourse.getPrerequisite());
            pstmt.setDouble(6, programCourse.getCreditWeight());
            pstmt.executeUpdate();
        }
    }

    //更新

    public void update(ProgramCourse programCourse) throws SQLException {
        String sql = "UPDATE tbl_programCourse SET courseType = ?, recommendSemester = ?, " +
                     "prerequisite = ?, creditWeight = ? WHERE linkId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programCourse.getCourseType());
            pstmt.setString(2, programCourse.getRecommendSemester());
            pstmt.setString(3, programCourse.getPrerequisite());
            pstmt.setDouble(4, programCourse.getCreditWeight());
            pstmt.setInt(5, programCourse.getLinkId());
            pstmt.executeUpdate();
        }
    }

    //删除

    public void delete(int linkId) throws SQLException {
        String sql = "DELETE FROM tbl_programCourse WHERE pclinkId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, linkId);
            pstmt.executeUpdate();
        }
    }

    public void deleteByProgramId(String programId) throws SQLException {
        String sql = "DELETE FROM tbl_programCourse WHERE programId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            pstmt.executeUpdate();
        }
    }

    public void deleteByCourseId(String courseId) throws SQLException {
        String sql = "DELETE FROM tbl_programCourse WHERE courseId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            pstmt.executeUpdate();
        }
    }
}