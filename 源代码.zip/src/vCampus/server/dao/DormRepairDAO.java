package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.RepairStatus;
import vCampus.common.vo.DormRepair;


public class DormRepairDAO {


    // 新增报修
    public boolean insert(DormRepair repair) {

        if (repair == null)
            return false;

        if (repair.getStatus() == null)
            repair.setStatus(RepairStatus.PENDING);


        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {

            conn = DBUtil.getConnection();

            String sql =
                    "INSERT INTO tbl_dorm_repair "
                    + "(sId,dormId,description,status,createTime) "
                    + "VALUES(?,?,?,?,?)";


            pstmt = conn.prepareStatement(
                    sql,
                    Statement.RETURN_GENERATED_KEYS
            );
            
            pstmt.setString(1, repair.getsId());
            pstmt.setString(2, repair.getDormId());
            pstmt.setString(3, repair.getDescription());
            pstmt.setString(4, repair.getStatus().name());


            pstmt.setTimestamp(
                    5,
                    repair.getCreateTime() == null ?
                    null :
                    new Timestamp(
                            repair.getCreateTime().getTime()
                    )
            );


            int result =
                    pstmt.executeUpdate();


            if (result > 0) {

                rs =
                        pstmt.getGeneratedKeys();

                if (rs.next()) {

                    repair.setRepairId(
                            rs.getInt(1)
                    );
                }

                return true;
            }

            return false;
            

        } catch(Exception e) {

            e.printStackTrace();
            return false;

        } finally {

            DBUtil.close(conn, pstmt, rs);

        }
    }



    // 根据编号查询
    public DormRepair findById(int repairId) {

        DormRepair repair = null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;


        try {

            conn = DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_repair "
                    + "WHERE repairId=?";


            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, repairId);


            rs = pstmt.executeQuery();


            if (rs.next())
                repair = toDormRepair(rs);


        } catch(Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(conn, pstmt, rs);

        }


        return repair;
    }


 // 查询全部报修
    public List<DormRepair> queryAll() {

        List<DormRepair> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_repair "
                    + "ORDER BY createTime DESC";

            pstmt =
                    conn.prepareStatement(sql);

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormRepair(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


    // 查询学生报修
    public List<DormRepair> queryByStudent(String sId) {

        List<DormRepair> list = new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;


        try {

            conn = DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_repair "
                    + "WHERE sId=? "
                    + "ORDER BY createTime DESC";


            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sId);


            rs = pstmt.executeQuery();


            while (rs.next())
                list.add(toDormRepair(rs));


        } catch(Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(conn, pstmt, rs);

        }


        return list;
    }





    // 查询宿舍报修
    public List<DormRepair> queryByDorm(String dormId) {

        List<DormRepair> list = new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;


        try {

            conn = DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_repair "
                    + "WHERE dormId=? "
                    + "ORDER BY createTime DESC";


            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dormId);


            rs = pstmt.executeQuery();


            while (rs.next())
                list.add(toDormRepair(rs));


        } catch(Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(conn, pstmt, rs);

        }


        return list;
    }





    // 查询待处理报修
    public List<DormRepair> queryPending() {

        List<DormRepair> list = new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;


        try {

            conn = DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_repair "
                    + "WHERE status=? "
                    + "ORDER BY createTime";


            pstmt = conn.prepareStatement(sql);


            pstmt.setString(
                    1,
                    RepairStatus.PENDING.name()
            );


            rs = pstmt.executeQuery();


            while (rs.next())
                list.add(toDormRepair(rs));


        } catch(Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(conn, pstmt, rs);

        }


        return list;
    }





    // 修改报修状态
    public boolean updateStatus(
            int repairId,
            RepairStatus status) {


        if(status == null)
            return false;


        Connection conn = null;
        PreparedStatement pstmt = null;


        try {

            conn = DBUtil.getConnection();


            String sql =
                    "UPDATE tbl_dorm_repair "
                    + "SET status=?,updateTime=? "
                    + "WHERE repairId=?";


            pstmt = conn.prepareStatement(sql);


            pstmt.setString(
                    1,
                    status.name()
            );


            pstmt.setTimestamp(
                    2,
                    new Timestamp(
                            System.currentTimeMillis()
                    )
            );


            pstmt.setInt(
                    3,
                    repairId
            );


            return pstmt.executeUpdate() > 0;


        } catch(Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(conn, pstmt, null);

        }
    }





    // ResultSet转换实体
    private DormRepair toDormRepair(ResultSet rs)
            throws SQLException {


        DormRepair repair = new DormRepair();


        repair.setRepairId(
                rs.getInt("repairId")
        );


        repair.setsId(
                rs.getString("sId")
        );


        repair.setDormId(
                rs.getString("dormId")
        );


        repair.setDescription(
                rs.getString("description")
        );


        repair.setStatus(
                RepairStatus.valueOf(
                        rs.getString("status")
                )
        );


        repair.setCreateTime(
                rs.getTimestamp("createTime")
        );


        repair.setUpdateTime(
                rs.getTimestamp("updateTime")
        );


        return repair;
    }

}