package vCampus.server.dao;

import vCampus.common.vo.SelectRound;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SelectRoundDao {

    private SelectRound mapRow(ResultSet rs) throws SQLException {
        SelectRound r = new SelectRound();
        r.setRoundId(rs.getString("roundId"));
        r.setSemester(rs.getString("semester"));
        r.setRoundName(rs.getString("roundName"));
        r.setStartTime(rs.getString("startTime"));
        r.setEndTime(rs.getString("endTime"));
        r.setStatus(rs.getString("status"));
        return r;
    }

    public List<SelectRound> getAllRounds() throws SQLException {
        List<SelectRound> list = new ArrayList<>();
        // ★ 只查需要用的字段，减少 Access 读取开销
        String sql = "SELECT roundId, semester, roundName, startTime, endTime, status " +
                     "FROM tbl_select_round ORDER BY startTime DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    public SelectRound getRoundById(String roundId) throws SQLException {
        String sql = "SELECT * FROM tbl_select_round WHERE roundId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roundId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public SelectRound getCurrentOpenRound() throws SQLException {
        String sql = "SELECT * FROM tbl_select_round WHERE status = 'open' ORDER BY startTime DESC LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    public void insertRound(SelectRound round) throws SQLException {
        String sql = "INSERT INTO tbl_select_round (roundId, semester, roundName, startTime, endTime, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, round.getRoundId());
            pstmt.setString(2, round.getSemester());
            pstmt.setString(3, round.getRoundName());
            pstmt.setString(4, round.getStartTime());
            pstmt.setString(5, round.getEndTime());
            pstmt.setString(6, round.getStatus());
            pstmt.executeUpdate();
        }
    }

    public void updateStatus(String roundId, String status) throws SQLException {
        String sql = "UPDATE tbl_select_round SET status = ? WHERE roundId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setString(2, roundId);
            pstmt.executeUpdate();
        }
    }

    public void deleteRound(String roundId) throws SQLException {
        String sql = "DELETE FROM tbl_select_round WHERE roundId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roundId);
            pstmt.executeUpdate();
        }
    }
    /**
     * 更新轮次的完整信息（名称、学期、起止时间、状态）
     */
    public void updateRound(SelectRound round) throws SQLException {
        String sql = "UPDATE tbl_select_round SET semester = ?, roundName = ?, " +
                     "startTime = ?, endTime = ?, status = ? WHERE roundId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, round.getSemester());
            pstmt.setString(2, round.getRoundName());
            pstmt.setString(3, round.getStartTime());
            pstmt.setString(4, round.getEndTime());
            pstmt.setString(5, round.getStatus());
            pstmt.setString(6, round.getRoundId());
            pstmt.executeUpdate();
        }
    }
}