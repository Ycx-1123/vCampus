
package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.shop.Product;

/**
 * 商品数据访问类
 * 负责对 tbl_Product 表进行增删改查
 */
public class ProductDAO {

    // 数据库连接配置（与你的 vCampus.accdb 路径匹配）
	private static final String DB_URL = "jdbc:ucanaccess://./vCampus.accdb;ignoreCase=true;newDatabaseVersion=V2019";

    /**
     * 查询所有商品
     */
    public List<Product> queryAll() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM tblProduct";
        
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setStock(rs.getInt("stock"));
                p.setCategory(rs.getString("category")); // 如果有分类字段
                p.setDescription(rs.getString("description"));
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    // 新增：根据ID查询单个商品
    public Product findById(int productId) {
        String sql = "SELECT * FROM tblProduct WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setStock(rs.getInt("stock"));
                p.setCategory(rs.getString("category"));
                p.setDescription(rs.getString("description"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Product findById(Connection conn, int productId) throws SQLException {
        String sql = "SELECT * FROM tblProduct WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setStock(rs.getInt("stock"));
                p.setCategory(rs.getString("category"));
                p.setDescription(rs.getString("description"));
                return p;
            }
        }
        return null;
    }

    // ★ 新增：支持事务的库存扣减方法
    public boolean updateStock(Connection conn, int productId, int quantity) throws SQLException {
        String sql = "UPDATE tblProduct SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        }
    }
    /**
     * 更新库存（事务中调用）
     */
    public boolean updateStock(int productId, int quantity) {
        String sql = "UPDATE tblProduct SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);

            int rows = pstmt.executeUpdate();
            return rows > 0; // 影响行数大于0说明更新成功
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 插入新商品（上架）
     * @param p 商品对象（id 会自动生成，无需设置）
     * @return true 表示插入成功
     */
    public boolean insert(Product p) {
        String sql = "INSERT INTO tblProduct (name, category, price, stock, description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, p.getName());
            pstmt.setString(2, p.getCategory());
            pstmt.setDouble(3, p.getPrice());
            pstmt.setInt(4, p.getStock());
            pstmt.setString(5, p.getDescription());

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                // 获取自动生成的主键 id
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        p.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 增加库存（管理员补货）
     * @param id 商品ID
     * @param amount 增加的数量（正数）
     * @return true 表示更新成功
     */
    public boolean addStock(int id, int amount) {
        if (amount <= 0) {
            System.err.println("增加库存数量必须大于0");
            return false;
        }
        String sql = "UPDATE tblProduct SET stock = stock + ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, amount);
            pstmt.setInt(2, id);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据ID删除商品（下架）
     * @param id 商品ID
     * @return true 表示删除成功
     */
    public boolean deleteById(int id) {
        String sql = "DELETE FROM tblProduct WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
}
 