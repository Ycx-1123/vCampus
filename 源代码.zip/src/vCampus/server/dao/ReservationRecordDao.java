package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.vo.BookRecommendation;
import vCampus.common.vo.ReservationRecord;

/** 数据访问类：对应 tbl_book_reservation_record。 */
public class ReservationRecordDao {
    /** 预约到馆后保留 7 天，逾期未借自动失效。 */
    private static final int READY_HOLD_DAYS = 7;
    /** 单个读者同时处于排队中或已到馆状态的预约上限。 */
    private static final int MAX_ACTIVE_RESERVATIONS_PER_READER = 3;
    /** 有效预约达到该人数后，进入热门采购参考。 */
    public static final int HOT_RESERVATION_THRESHOLD = 3;
    private static final Object RESERVATION_LOCK = new Object();

    public boolean reserve(String bookId, String readerId, LocalDateTime reservationTime) throws SQLException {
        synchronized (RESERVATION_LOCK) {
            return reserveLocked(bookId, readerId, reservationTime);
        }
    }

    private boolean reserveLocked(String bookId, String readerId, LocalDateTime reservationTime) throws SQLException {
        String duplicateSql = "SELECT COUNT(*) FROM tbl_book_reservation_record "
                + "WHERE bookId = ? AND readerId = ? AND status IN ('WAITING', 'READY')";
        String activeLimitSql = "SELECT COUNT(*) FROM tbl_book_reservation_record "
                + "WHERE readerId = ? AND status IN ('WAITING', 'READY')";
        String queueSql = "SELECT MAX(queueNumber) FROM tbl_book_reservation_record WHERE bookId = ? "
                + "AND status IN ('WAITING', 'READY')";
        String insertSql = "INSERT INTO tbl_book_reservation_record "
                + "(reservationId, bookId, readerId, reservationTime, queueNumber, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBUtil.getConnection();
                PreparedStatement duplicate = connection.prepareStatement(duplicateSql);
                PreparedStatement activeLimit = connection.prepareStatement(activeLimitSql);
                PreparedStatement queue = connection.prepareStatement(queueSql);
                PreparedStatement insert = connection.prepareStatement(insertSql)) {
            expireReadyReservations(connection, LocalDateTime.now());
            renumberActiveReservations(connection, bookId);
            duplicate.setString(1, bookId);
            duplicate.setString(2, readerId);
            try (ResultSet resultSet = duplicate.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    throw new SQLException("该读者已在本书预约队列中");
                }
            }
            activeLimit.setString(1, readerId);
            try (ResultSet resultSet = activeLimit.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) >= MAX_ACTIVE_RESERVATIONS_PER_READER) {
                    throw new SQLException("你当前已有 " + MAX_ACTIVE_RESERVATIONS_PER_READER
                            + " 个有效预约，请先取消或完成其中一个预约后再预约新书");
                }
            }
            if (hasAvailableCopy(connection, bookId)) {
                throw new SQLException("该书目前仍有可借副本，无需预约；请直接办理借阅");
            }
            queue.setString(1, bookId);
            int queueNumber = 1;
            try (ResultSet resultSet = queue.executeQuery()) {
                if (resultSet.next() && resultSet.getObject(1) != null) {
                    queueNumber = resultSet.getInt(1) + 1;
                }
            }
            insert.setString(1, nextReservationId(connection));
            insert.setString(2, bookId);
            insert.setString(3, readerId);
            insert.setTimestamp(4, Timestamp.valueOf(reservationTime == null ? LocalDateTime.now() : reservationTime));
            insert.setInt(5, queueNumber);
            insert.setString(6, ReservationRecord.STATUS_WAITING);
            return insert.executeUpdate() == 1;
        }
    }

    public boolean cancel(String reservationId) throws SQLException {
        synchronized (RESERVATION_LOCK) {
            return cancelLocked(reservationId);
        }
    }

    private boolean cancelLocked(String reservationId) throws SQLException {
        String findSql = "SELECT bookId FROM tbl_book_reservation_record WHERE reservationId=? "
                + "AND status IN ('WAITING', 'READY')";
        String updateSql = "UPDATE tbl_book_reservation_record SET status='CANCELLED' WHERE reservationId=?";
        try (Connection connection = DBUtil.getConnection()) {
            connection.setAutoCommit(false);
            try {
                String bookId = null;
                try (PreparedStatement find = connection.prepareStatement(findSql)) {
                    find.setString(1, reservationId);
                    try (ResultSet resultSet = find.executeQuery()) {
                        if (resultSet.next()) bookId = resultSet.getString("bookId");
                    }
                }
                if (bookId == null) { connection.commit(); return false; }
                try (PreparedStatement update = connection.prepareStatement(updateSql)) {
                    update.setString(1, reservationId);
                    if (update.executeUpdate() != 1) { connection.commit(); return false; }
                }
                renumberActiveReservations(connection, bookId);
                connection.commit();
                return true;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    public List<ReservationRecord> findByReaderId(String readerId) throws SQLException {
        expireReadyReservations(LocalDateTime.now());
        List<ReservationRecord> records = new ArrayList<>();
        String sql = "SELECT rr.*, b.bName AS bookName FROM tbl_book_reservation_record rr "
                + "INNER JOIN tbl_book b ON rr.bookId=b.bId WHERE rr.readerId = ? ORDER BY rr.reservationTime DESC";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, readerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    records.add(mapRow(resultSet));
                }
            }
        }
        return records;
    }

    public List<ReservationRecord> findWaitingByBookId(String bookId) throws SQLException {
        expireReadyReservations(LocalDateTime.now());
        List<ReservationRecord> records = new ArrayList<>();
        String sql = "SELECT rr.*, b.bName AS bookName FROM tbl_book_reservation_record rr "
                + "INNER JOIN tbl_book b ON rr.bookId=b.bId WHERE rr.bookId = ? "
                + "AND rr.status IN ('WAITING', 'READY') ORDER BY rr.queueNumber";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    records.add(mapRow(resultSet));
                }
            }
        }
        return records;
    }

    public ReservationRecord findFirstActiveByBookId(String bookId) throws SQLException {
        List<ReservationRecord> records = findWaitingByBookId(bookId);
        return records.isEmpty() ? null : records.get(0);
    }

    /** 返回同名馆藏当前的有效预约数，供荐书采购评分使用。 */
    public int countActiveReservationsByBookName(String bookName) throws SQLException {
        expireReadyReservations(LocalDateTime.now());
        String sql = "SELECT COUNT(*) FROM tbl_book_reservation_record rr "
                + "INNER JOIN tbl_book b ON rr.bookId=b.bId "
                + "WHERE b.bName=? AND rr.status IN ('WAITING', 'READY')";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookName);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt(1) : 0;
            }
        }
    }

    /** 失效已超过 7 天的 READY 预约，并让下一位排队者获得取书资格。 */
    public void expireReadyReservations(LocalDateTime currentTime) throws SQLException {
        try (Connection connection = DBUtil.getConnection()) {
            connection.setAutoCommit(false);
            try {
                expireReadyReservations(connection, currentTime == null ? LocalDateTime.now() : currentTime);
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    /** 供借阅事务在同一连接中调用，避免读到已经过期的 READY 预约。 */
    void expireReadyReservations(Connection connection, LocalDateTime currentTime) throws SQLException {
        List<String> bookIds = new ArrayList<>();
        String findSql = "SELECT DISTINCT bookId FROM tbl_book_reservation_record "
                + "WHERE status='READY' AND readyTime IS NOT NULL AND readyTime <= ?";
        try (PreparedStatement find = connection.prepareStatement(findSql)) {
            find.setTimestamp(1, Timestamp.valueOf(currentTime.minusDays(READY_HOLD_DAYS)));
            try (ResultSet resultSet = find.executeQuery()) {
                while (resultSet.next()) bookIds.add(resultSet.getString("bookId"));
            }
        }
        if (bookIds.isEmpty()) return;
        try (PreparedStatement expire = connection.prepareStatement(
                "UPDATE tbl_book_reservation_record SET status='EXPIRED' "
                + "WHERE status='READY' AND readyTime IS NOT NULL AND readyTime <= ?")) {
            expire.setTimestamp(1, Timestamp.valueOf(currentTime.minusDays(READY_HOLD_DAYS)));
            expire.executeUpdate();
        }
        for (String bookId : bookIds) {
            renumberActiveReservations(connection, bookId);
            if (hasAvailableCopy(connection, bookId)) markFirstWaitingReservationReady(connection, bookId, currentTime);
        }
    }

    /** 返回有效预约不少于 3 人的现有馆藏，供管理员直接判断是否应补充副本。 */
    public List<BookRecommendation> findHotBookProcurementReferences() throws SQLException {
        expireReadyReservations(LocalDateTime.now());
        List<BookRecommendation> results = new ArrayList<>();
        String sql = "SELECT b.bName, b.bAuthor, b.bPublisher, b.categoryId, COUNT(rr.reservationId) AS reservationCount "
                + "FROM tbl_book b INNER JOIN tbl_book_reservation_record rr ON b.bId=rr.bookId "
                + "WHERE rr.status IN ('WAITING', 'READY') "
                + "GROUP BY b.bName, b.bAuthor, b.bPublisher, b.categoryId "
                + "HAVING COUNT(rr.reservationId) >= ? ORDER BY COUNT(rr.reservationId) DESC";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, HOT_RESERVATION_THRESHOLD);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    BookRecommendation item = new BookRecommendation();
                    item.setBookName(resultSet.getString("bName"));
                    item.setAuthor(resultSet.getString("bAuthor"));
                    item.setPublisher(resultSet.getString("bPublisher"));
                    item.setCategoryId(resultSet.getString("categoryId"));
                    item.setActiveReservationCount(resultSet.getInt("reservationCount"));
                    results.add(item);
                }
            }
        }
        return results;
    }

    /** 同一连接内计算有效预约数，供借阅事务判断热门书借期。 */
    int countActiveReservations(Connection connection, String bookId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT COUNT(*) FROM tbl_book_reservation_record WHERE bookId=? AND status IN ('WAITING', 'READY')")) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt(1) : 0;
            }
        }
    }

    /** 只对仍有效的预约重新从 1 开始编号；已完成、取消和过期记录保留原编号作历史记录。 */
    void renumberActiveReservations(Connection connection, String bookId) throws SQLException {
        List<String> reservationIds = new ArrayList<>();
        String findSql = "SELECT reservationId FROM tbl_book_reservation_record WHERE bookId=? "
                + "AND status IN ('WAITING', 'READY') ORDER BY queueNumber, reservationTime, reservationId";
        try (PreparedStatement find = connection.prepareStatement(findSql)) {
            find.setString(1, bookId);
            try (ResultSet resultSet = find.executeQuery()) {
                while (resultSet.next()) reservationIds.add(resultSet.getString("reservationId"));
            }
        }
        try (PreparedStatement update = connection.prepareStatement(
                "UPDATE tbl_book_reservation_record SET queueNumber=? WHERE reservationId=?")) {
            for (int i = 0; i < reservationIds.size(); i++) {
                update.setInt(1, i + 1);
                update.setString(2, reservationIds.get(i));
                update.addBatch();
            }
            if (!reservationIds.isEmpty()) update.executeBatch();
        }
    }

    private void markFirstWaitingReservationReady(Connection connection, String bookId, LocalDateTime readyTime) throws SQLException {
        String findSql = "SELECT reservationId FROM tbl_book_reservation_record WHERE bookId=? "
                + "AND status='WAITING' ORDER BY queueNumber";
        try (PreparedStatement find = connection.prepareStatement(findSql)) {
            find.setString(1, bookId);
            try (ResultSet resultSet = find.executeQuery()) {
                if (!resultSet.next()) return;
                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE tbl_book_reservation_record SET status='READY', readyTime=? WHERE reservationId=?")) {
                    update.setTimestamp(1, Timestamp.valueOf(readyTime));
                    update.setString(2, resultSet.getString("reservationId"));
                    update.executeUpdate();
                }
            }
        }
    }

    private ReservationRecord mapRow(ResultSet resultSet) throws SQLException {
        ReservationRecord record = new ReservationRecord();
        record.setReservationId(resultSet.getString("reservationId"));
        record.setBookId(resultSet.getString("bookId"));
        record.setBookName(resultSet.getString("bookName"));
        record.setReaderId(resultSet.getString("readerId"));
        Timestamp reservationTime = resultSet.getTimestamp("reservationTime");
        record.setReservationTime(reservationTime == null ? null : reservationTime.toLocalDateTime());
        Timestamp readyTime = resultSet.getTimestamp("readyTime");
        record.setReadyTime(readyTime == null ? null : readyTime.toLocalDateTime());
        record.setQueueNumber(resultSet.getInt("queueNumber"));
        record.setStatus(resultSet.getString("status"));
        return record;
    }

    private boolean hasAvailableCopy(Connection connection, String bookId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_book_copy WHERE bookId=? AND status='AVAILABLE' "
                + "AND (circulationType='CIRCULATING' OR circulationType IS NULL OR circulationType='')";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        }
    }

    /** 用 RS0001 形式的业务编号替代 UUID，便于读者和老师查看。 */
    private String nextReservationId(Connection connection) throws SQLException {
        int max = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT reservationId FROM tbl_book_reservation_record");
                ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String id = resultSet.getString(1);
                if (id != null && id.matches("RS\\d+")) {
                    max = Math.max(max, Integer.parseInt(id.substring(2)));
                }
            }
        }
        return String.format("RS%04d", max + 1);
    }
}
