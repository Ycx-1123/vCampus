package vCampus.server.dao;

import vCampus.common.vo.CourseOffering;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseOfferingDao {

    private CourseOffering mapRowToOffering(ResultSet rs) throws SQLException {
        CourseOffering o = new CourseOffering();
        o.setOfferingId(rs.getString("offeringId"));
        o.setCourseId(rs.getString("courseId"));
        o.setTeacherId(rs.getString("teacherId"));
        o.setTeacherName(rs.getString("teacherName"));
        o.setSemester(rs.getString("COsemester"));
        o.setCapacity(rs.getInt("COcapacity"));
        o.setEnrolledCount(rs.getInt("COenrolledCount"));
        o.setSchedule(rs.getString("COschedule"));
        o.setClassroom(rs.getString("COclassroom"));
        o.setStatus(rs.getString("COstatus"));
        o.setVersion(rs.getInt("version"));
        try { o.setCampus(rs.getString("campus")); } catch (SQLException e) { o.setCampus("九龙湖"); }
        try { o.setRoundId(rs.getString("roundId")); } catch (SQLException e) { o.setRoundId(null); }
        // ★ roomCapacity 兼容旧数据
        try {
            int rc = rs.getInt("roomCapacity");
            if (rs.wasNull() || rc <= 0) rc = o.getCapacity();
            o.setRoomCapacity(rc);
        } catch (SQLException e) {
            o.setRoomCapacity(o.getCapacity());
        }
        return o;
    }

    private static final String COLS =
        "offeringId, courseId, teacherId, teacherName, COsemester, COcapacity, " +
        "COenrolledCount, COschedule, COclassroom, COstatus, version, campus, roundId, roomCapacity";

    public List<CourseOffering> getAllOfferings() throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRowToOffering(rs));
        }
        return list;
    }

    public CourseOffering getOfferingById(String offeringId) throws SQLException {
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRowToOffering(rs);
            }
        }
        return null;
    }

    public List<CourseOffering> getOfferingsByCourseId(String courseId) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE courseId = ? ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsBySemester(String semester) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE COsemester = ? ORDER BY courseId, offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, semester);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByTeacherId(String teacherId) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE teacherId = ? ORDER BY COsemester, offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByStatus(String status) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE COstatus = ? ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOpenOfferings() throws SQLException {
        return getOfferingsByStatus("open");
    }

    public List<CourseOffering> getOpenOfferingsByCourseId(String courseId) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE courseId = ? AND COstatus = 'open' ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByTeacherAndSemester(String teacherId, String semester) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE teacherId = ? AND COsemester = ? ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, teacherId);
            pstmt.setString(2, semester);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> searchOfferings(String keyword) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE " +
                "teacherName LIKE ? OR COsemester LIKE ? OR COclassroom LIKE ? OR courseId LIKE ? " +
                "ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            pstmt.setString(4, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByIds(List<String> offeringIds) throws SQLException {
        if (offeringIds == null || offeringIds.isEmpty()) return new ArrayList<>();
        StringBuilder ph = new StringBuilder();
        for (int i = 0; i < offeringIds.size(); i++) {
            if (i > 0) ph.append(",");
            ph.append("?");
        }
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE offeringId IN (" + ph + ")";
        List<CourseOffering> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (int i = 0; i < offeringIds.size(); i++) pstmt.setString(i + 1, offeringIds.get(i));
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByRoundId(String roundId) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE roundId = ? ORDER BY courseId, offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roundId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    public List<CourseOffering> getOfferingsByCourseIdAndRound(String courseId, String roundId) throws SQLException {
        List<CourseOffering> list = new ArrayList<>();
        String sql = "SELECT " + COLS + " FROM tbl_courseOffering WHERE courseId = ? AND roundId = ? ORDER BY offeringId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            pstmt.setString(2, roundId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRowToOffering(rs));
            }
        }
        return list;
    }

    // ============================================================
    // 插入 / 更新
    // ============================================================

    public void insertOffering(CourseOffering offering) throws SQLException {
        String sql = "INSERT INTO tbl_courseOffering " +
                "(offeringId, courseId, teacherId, teacherName, COsemester, COcapacity, " +
                "COenrolledCount, COschedule, COclassroom, COstatus, version, campus, roundId, roomCapacity) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offering.getOfferingId());
            pstmt.setString(2, offering.getCourseId());
            pstmt.setString(3, offering.getTeacherId());
            pstmt.setString(4, offering.getTeacherName());
            pstmt.setString(5, offering.getSemester());
            pstmt.setInt(6, offering.getCapacity());
            pstmt.setInt(7, offering.getEnrolledCount());
            pstmt.setString(8, offering.getSchedule());
            pstmt.setString(9, offering.getClassroom());
            pstmt.setString(10, offering.getStatus());
            pstmt.setInt(11, 0);
            pstmt.setString(12, offering.getCampus());
            pstmt.setString(13, offering.getRoundId());
            int rc = offering.getRoomCapacity() > 0 ? offering.getRoomCapacity() : offering.getCapacity();
            pstmt.setInt(14, rc);
            pstmt.executeUpdate();
        }
    }

    public void updateOffering(CourseOffering offering) throws SQLException {
        String sql = "UPDATE tbl_courseOffering SET courseId = ?, teacherId = ?, teacherName = ?, " +
                "COsemester = ?, COcapacity = ?, COenrolledCount = ?, COschedule = ?, " +
                "COclassroom = ?, COstatus = ?, campus = ?, roomCapacity = ? WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offering.getCourseId());
            pstmt.setString(2, offering.getTeacherId());
            pstmt.setString(3, offering.getTeacherName());
            pstmt.setString(4, offering.getSemester());
            pstmt.setInt(5, offering.getCapacity());
            pstmt.setInt(6, offering.getEnrolledCount());
            pstmt.setString(7, offering.getSchedule());
            pstmt.setString(8, offering.getClassroom());
            pstmt.setString(9, offering.getStatus());
            pstmt.setString(10, offering.getCampus());
            pstmt.setInt(11, offering.getRoomCapacity());
            pstmt.setString(12, offering.getOfferingId());
            pstmt.executeUpdate();
        }
    }

    public void updateEnrolledCount(String offeringId, int delta) throws SQLException {
        String sql = "UPDATE tbl_courseOffering SET " +
                "COenrolledCount = COenrolledCount + ?, " +
                "COstatus = CASE WHEN COenrolledCount + ? >= COcapacity THEN 'full' ELSE 'open' END, " +
                "version = version + 1 " +
                "WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, delta);
            pstmt.setInt(2, delta);
            pstmt.setString(3, offeringId);
            pstmt.executeUpdate();
        }
    }
    /**
     * 根据 tbl_select 中 selectStatus='selected' 的实际记录数，
     * 重算 tbl_courseOffering 的 COenrolledCount 和 COstatus。
     *
     * 用于替代"手动 ±1"的做法，保证 enrolledCount 永远等于实际选课人数。
     */
    public void recalcEnrolledCount(String offeringId) throws SQLException {
        // 1. 查实际选课人数
        String countSql = "SELECT COUNT(*) FROM tbl_select " +
                          "WHERE offeringId = ? AND selectStatus = 'selected'";
        int count = 0;
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(countSql)) {
            pstmt.setString(1, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) count = rs.getInt(1);
            }
        }

        // 2. 更新 enrolledCount 和 status
        String updateSql = "UPDATE tbl_courseOffering SET " +
                           "COenrolledCount = ?, " +
                           "COstatus = CASE WHEN ? >= COcapacity THEN 'full' ELSE 'open' END, " +
                           "version = version + 1 " +
                           "WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(updateSql)) {
            pstmt.setInt(1, count);
            pstmt.setInt(2, count);
            pstmt.setString(3, offeringId);
            pstmt.executeUpdate();
        }
    }
    public void updateStatus(String offeringId, String status) throws SQLException {
        String sql = "UPDATE tbl_courseOffering SET COstatus = ? WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setString(2, offeringId);
            pstmt.executeUpdate();
        }
    }

    public void updateCapacity(String offeringId, int newCapacity) throws SQLException {
        String sql = "UPDATE tbl_courseOffering SET " +
                "COcapacity = ?, " +
                "COstatus = CASE WHEN COenrolledCount >= ? THEN 'full' ELSE 'open' END, " +
                "version = version + 1 " +
                "WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newCapacity);
            pstmt.setInt(2, newCapacity);
            pstmt.setString(3, offeringId);
            pstmt.executeUpdate();
        }
    }

    public void deleteOffering(String offeringId) throws SQLException {
        String sql = "DELETE FROM tbl_courseOffering WHERE offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offeringId);
            pstmt.executeUpdate();
        }
    }

    public int deleteOfferingsByCourseId(String courseId) throws SQLException {
        String sql = "DELETE FROM tbl_courseOffering WHERE courseId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            return pstmt.executeUpdate();
        }
    }

    public boolean decrementCapacity(String offeringId, int version) throws SQLException {
        String sql = "UPDATE tbl_courseOffering SET " +
                "COenrolledCount = COenrolledCount + 1, " +
                "version = version + 1 " +
                "WHERE offeringId = ? AND COenrolledCount < COcapacity AND version = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offeringId);
            pstmt.setInt(2, version);
            return pstmt.executeUpdate() > 0;
        }
    }
}