package vCampus.server.dao;

import vCampus.common.vo.Category;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDao {
    
    public List<Category> getAllCategories() throws SQLException {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT categoryId, categoryName, categoryCode, categoryDescription, sortOrder " +
                     "FROM tbl_category ORDER BY sortOrder";
        
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Category category = new Category();
                category.setCategoryId(rs.getString("categoryId"));
                category.setCategoryName(rs.getString("categoryName"));
                category.setCategoryCode(rs.getString("categoryCode"));
                category.setDescription(rs.getString("categoryDescription"));
                category.setSortOrder(rs.getInt("sortOrder"));
                list.add(category);
            }
        }
        return list;
    }
    
    public Category getCategoryById(String categoryId) throws SQLException {
        String sql = "SELECT categoryId, categoryName, categoryCode, categoryDescription, sortOrder " +
                     "FROM tbl_category WHERE categoryId = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, categoryId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Category category = new Category();
                    category.setCategoryId(rs.getString("categoryId"));
                    category.setCategoryName(rs.getString("categoryName"));
                    category.setCategoryCode(rs.getString("categoryCode"));
                    category.setDescription(rs.getString("categoryDescription"));
                    category.setSortOrder(rs.getInt("sortOrder"));
                    return category;
                }
            }
        }
        return null;
    }
    
    public Category getCategoryByName(String categoryName) throws SQLException {
        String sql = "SELECT categoryId, categoryName, categoryCode, categoryDescription, sortOrder " +
                     "FROM tbl_category WHERE categoryName = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, categoryName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Category category = new Category();
                    category.setCategoryId(rs.getString("categoryId"));
                    category.setCategoryName(rs.getString("categoryName"));
                    category.setCategoryCode(rs.getString("categoryCode"));
                    category.setDescription(rs.getString("categoryDescription"));
                    category.setSortOrder(rs.getInt("sortOrder"));
                    return category;
                }
            }
        }
        return null;
    }
}