package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import vCampus.common.vo.BankAccount;
import vCampus.common.vo.BankTransaction;

/**
 * 校园银行 DAO：负责银行卡账户、流水及一卡通余额的持久化。
 */
public class BankDao {
	public boolean hasBankPermission(String adminCard) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c
						.prepareStatement("SELECT manageBank FROM tbl_admin WHERE acard=? AND astatus=0")) {
			ps.setString(1, adminCard);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() && rs.getInt(1) == 1;
			}
		}
	}

	public boolean existsBankCard(String bankCardId) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM tbl_bank_account WHERE bankCardId=?")) {
			ps.setString(1, bankCardId);
			try (ResultSet rs = ps.executeQuery()) {
				rs.next();
				return rs.getInt(1) > 0;
			}
		}
	}

	public BankAccount findByHolderCard(String holderCard) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c
						.prepareStatement("SELECT bankCardId,holderCard,holderName,balance,status,createTime,bankPIN "
								+ "FROM tbl_bank_account WHERE holderCard=?")) {
			ps.setString(1, holderCard);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? account(rs) : null;
			}
		}
	}

	public BankAccount findByBankCardId(String bankCardId) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c
						.prepareStatement("SELECT bankCardId,holderCard,holderName,balance,status,createTime,bankPIN "
								+ "FROM tbl_bank_account WHERE bankCardId=?")) {
			ps.setString(1, bankCardId);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? account(rs) : null;
			}
		}
	}

	public List<BankAccount> findAll() throws SQLException {
		List<BankAccount> list = new ArrayList<BankAccount>();
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c
						.prepareStatement("SELECT bankCardId,holderCard,holderName,balance,status,createTime,bankPIN "
								+ "FROM tbl_bank_account ORDER BY bankCardId");
				ResultSet rs = ps.executeQuery()) {
			while (rs.next())
				list.add(account(rs));
		}
		return list;
	}

	public List<BankTransaction> findTransactions(String bankCardId) throws SQLException {
		List<BankTransaction> list = new ArrayList<BankTransaction>();
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c
						.prepareStatement("SELECT transactionId,bankCardId,transactionType,amount,targetId,"
								+ "balanceAfter,transactionTime,description FROM tbl_bank_transaction "
								+ "WHERE bankCardId=? ORDER BY transactionTime DESC, transactionId DESC")) {
			ps.setString(1, bankCardId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next())
					list.add(transaction(rs));
			}
		}
		return list;
	}

	public boolean insertAccount(BankAccount a) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(
						"INSERT INTO tbl_bank_account(bankCardId,holderCard,holderName,balance,status,createTime,bankPIN) "
								+ "VALUES(?,?,?,?,?,?,?)")) {
			ps.setString(1, a.getBankCardId());
			ps.setString(2, a.getHolderCard());
			ps.setString(3, a.getHolderName());
			ps.setDouble(4, a.getBalance());
			ps.setInt(5, a.getStatus());
			ps.setTimestamp(6, new Timestamp(a.getCreateTime().getTime()));
			ps.setString(7, a.getBankPIN());
			return ps.executeUpdate() == 1;
		}
	}

	public boolean setStatus(String bankCardId, int status) throws SQLException {
		try (Connection c = DBUtil.getConnection();
				PreparedStatement ps = c.prepareStatement("UPDATE tbl_bank_account SET status=? WHERE bankCardId=?")) {
			ps.setInt(1, status);
			ps.setString(2, bankCardId);
			return ps.executeUpdate() == 1;
		}
	}

	public boolean deposit(String bankCardId, double amount, String type, String desc) throws SQLException {
		return changeBalance(bankCardId, amount, type, null, desc);
	}

	public boolean withdraw(String bankCardId, double amount, String type, String desc) throws SQLException {
		return changeBalance(bankCardId, -amount, type, null, desc);
	}

	public boolean transfer(String from, String to, double amount) throws SQLException {
		Connection c = DBUtil.getConnection();
		try {
			c.setAutoCommit(false);
			BankAccount fromA = accountForUpdate(c, from);
			BankAccount toA = accountForUpdate(c, to);
			if (fromA == null || toA == null || fromA.getStatus() != 1 || toA.getStatus() != 1
					|| fromA.getBalance() < amount) {
				c.rollback();
				return false;
			}
			updateBalance(c, from, -amount);
			updateBalance(c, to, amount);
			insertTx(c, from, "TRANSFER_OUT", amount, to, fromA.getBalance() - amount, "转账至 " + to);
			insertTx(c, to, "TRANSFER_IN", amount, from, toA.getBalance() + amount, "收到来自 " + from);
			c.commit();
			return true;
		} catch (SQLException e) {
			try {
				c.rollback();
			} catch (SQLException ignored) {
			}
			throw e;
		} finally {
			try {
				c.setAutoCommit(true);
			} catch (SQLException ignored) {
			}
			c.close();
		}
	}

	public boolean rechargeCampus(String bankCardId, String holderCard, double amount) throws SQLException {
		Connection c = DBUtil.getConnection();
		try {
			c.setAutoCommit(false);
			BankAccount a = accountForUpdate(c, bankCardId);
			if (a == null || a.getStatus() != 1 || !holderCard.equals(a.getHolderCard()) || a.getBalance() < amount) {
				c.rollback();
				return false;
			}
			int changed = updateCampus(c, "tbl_student", "sbalance", "sCard", holderCard, amount);
			if (changed != 1) {
				changed = updateCampus(c, "tbl_teacher", "tbalance", "tcard", holderCard, amount);
			}
			if (changed != 1) {
				c.rollback();
				return false;
			}
			updateBalance(c, bankCardId, -amount);
			insertTx(c, bankCardId, "CAMPUS_RECHARGE", amount, holderCard, a.getBalance() - amount, "一卡通充值");
			c.commit();
			return true;
		} catch (SQLException e) {
			try {
				c.rollback();
			} catch (SQLException ignored) {
			}
			throw e;
		} finally {
			try {
				c.setAutoCommit(true);
			} catch (SQLException ignored) {
			}
			c.close();
		}
	}

	public boolean shopPayment(Connection c, String holderCard, double amount, String orderId) throws SQLException {
		if (holderCard == null || holderCard.trim().isEmpty() || amount <= 0) {
			return false;
		}
		BankAccount a = accountForUpdateByHolderCard(c, holderCard.trim());
		if (a == null || a.getStatus() != 1 || a.getBalance() < amount) {
			return false;
		}
		updateBalance(c, a.getBankCardId(), -amount);
		insertTx(c, a.getBankCardId(), "SHOP_PAYMENT", amount, orderId, a.getBalance() - amount, "校园商店购物支付");
		return true;
	}

	public boolean dormPayment(String holderCard, double amount, String billId) throws SQLException {

		if (holderCard == null || holderCard.trim().isEmpty() || amount <= 0) {
			return false;
		}

		Connection c = DBUtil.getConnection();

		try {
			c.setAutoCommit(false);

			BankAccount a = accountForUpdateByHolderCard(c, holderCard.trim());

			if (a == null || a.getStatus() != 1 || a.getBalance() < amount) {

				c.rollback();
				return false;
			}

			updateBalance(c, a.getBankCardId(), -amount);

			insertTx(c, a.getBankCardId(), "DORM_PAYMENT", amount, billId, a.getBalance() - amount, "宿舍缴费");

			c.commit();

			return true;

		} catch (SQLException e) {

			try {
				c.rollback();
			} catch (SQLException ignored) {
			}

			throw e;

		} finally {

			try {
				c.setAutoCommit(true);
			} catch (SQLException ignored) {
			}

			c.close();
		}
	}

	private BankAccount accountForUpdateByHolderCard(Connection c, String holderCard) throws SQLException {
		try (PreparedStatement ps = c
				.prepareStatement("SELECT bankCardId,holderCard,holderName,balance,status,createTime,bankPIN "
						+ "FROM tbl_bank_account " + "WHERE holderCard=? AND status=1")) {

			ps.setString(1, holderCard);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? account(rs) : null;
			}
		}
	}

	private boolean changeBalance(String card, double delta, String type, String related, String desc)
			throws SQLException {
		Connection c = DBUtil.getConnection();
		try {
			c.setAutoCommit(false);
			BankAccount a = accountForUpdate(c, card);
			if (a == null || a.getStatus() != 1 || a.getBalance() + delta < -0.000001) {
				c.rollback();
				return false;
			}
			updateBalance(c, card, delta);
			double after = a.getBalance() + delta;
			insertTx(c, card, type, Math.abs(delta), related, after, desc);
			c.commit();
			return true;
		} catch (SQLException e) {
			try {
				c.rollback();
			} catch (SQLException ignored) {
			}
			throw e;
		} finally {
			try {
				c.setAutoCommit(true);
			} catch (SQLException ignored) {
			}
			c.close();
		}
	}

	private BankAccount accountForUpdate(Connection c, String card) throws SQLException {
		try (PreparedStatement ps = c
				.prepareStatement("SELECT bankCardId,holderCard,holderName,balance,status,createTime,bankPIN "
						+ "FROM tbl_bank_account WHERE bankCardId=?")) {
			ps.setString(1, card);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? account(rs) : null;
			}
		}
	}

	private void updateBalance(Connection c, String card, double delta) throws SQLException {
		try (PreparedStatement ps = c
				.prepareStatement("UPDATE tbl_bank_account SET balance=balance+? WHERE bankCardId=?")) {
			ps.setDouble(1, delta);
			ps.setString(2, card);
			ps.executeUpdate();
		}
	}

	private int updateCampus(Connection c, String table, String balance, String key, String card, double amount)
			throws SQLException {
		String sql = "UPDATE " + table + " SET " + balance + "=" + balance + "+? WHERE " + key + "=?";
		try (PreparedStatement ps = c.prepareStatement(sql)) {
			ps.setDouble(1, amount);
			ps.setString(2, card);
			return ps.executeUpdate();
		}
	}

	private void insertTx(Connection c, String card, String type, double amount, String related, double after,
			String desc) throws SQLException {
		try (PreparedStatement ps = c
				.prepareStatement("INSERT INTO tbl_bank_transaction(bankCardId,transactionType,amount,targetId,"
						+ "balanceAfter,transactionTime,description) VALUES(?,?,?,?,?,?,?)")) {
			ps.setString(1, card);
			ps.setString(2, type);
			ps.setDouble(3, amount);
			ps.setString(4, related);
			ps.setDouble(5, after);
			ps.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			ps.setString(7, desc);
			ps.executeUpdate();
		}
	}

	private BankAccount account(ResultSet rs) throws SQLException {
		BankAccount a = new BankAccount();
		a.setBankCardId(rs.getString(1));
		a.setHolderCard(rs.getString(2));
		a.setHolderName(rs.getString(3));
		a.setBalance(rs.getDouble(4));
		a.setStatus(rs.getInt(5));
		Timestamp ts = rs.getTimestamp(6);
		a.setCreateTime(ts == null ? null : new java.util.Date(ts.getTime()));
		a.setBankPIN(rs.getString(7));
		return a;
	}

	private BankTransaction transaction(ResultSet rs) throws SQLException {
		BankTransaction t = new BankTransaction();
		t.setTransactionId(rs.getInt(1));
		t.setBankCardId(rs.getString(2));
		t.setTransactionType(rs.getString(3));
		t.setAmount(rs.getDouble(4));
		t.setTargetId(rs.getString(5));
		t.setBalanceAfter(rs.getDouble(6));
		Timestamp ts = rs.getTimestamp(7);
		t.setTransactionTime(ts == null ? null : new java.util.Date(ts.getTime()));
		t.setDescription(rs.getString(8));
		return t;
	}
}
