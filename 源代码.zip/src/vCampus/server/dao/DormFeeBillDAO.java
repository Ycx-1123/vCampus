package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.FeeStatus;
import vCampus.common.vo.DormFeeBill;


public class DormFeeBillDAO {


    // 新增账单
    public boolean insert(DormFeeBill bill) {

        if (bill == null)
            return false;

        if (bill.getStatus() == null)
            bill.setStatus(FeeStatus.UNPAID);


        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();


            String sql =
                    "INSERT INTO tbl_dorm_fee_bill "
                    + "(sId,accommodationId,academicYear,"
                    + "semester,amount,paidAmount,"
                    + "dueDate,status,createTime)"
                    + " VALUES(?,?,?,?,?,?,?,?,?)";


            pstmt = conn.prepareStatement(
                    sql,
                    Statement.RETURN_GENERATED_KEYS
            );
            
            pstmt.setString(
                    1,
                    bill.getsId()
            );

            pstmt.setInt(
                    2,
                    bill.getAccommodationId()
            );

            pstmt.setString(
                    3,
                    bill.getAcademicYear()
            );

            pstmt.setString(
                    4,
                    bill.getSemester()
            );

            pstmt.setDouble(
                    5,
                    bill.getAmount()
            );

            pstmt.setDouble(
                    6,
                    bill.getPaidAmount()
            );

            pstmt.setDate(
                    7,
                    bill.getDueDate() == null ?
                    null :
                    new java.sql.Date(
                            bill.getDueDate().getTime()
                    )
            );

            pstmt.setString(
                    8,
                    bill.getStatus().name()
            );

            pstmt.setTimestamp(
                    9,
                    bill.getCreateTime() == null ?
                    null :
                    new Timestamp(
                            bill.getCreateTime().getTime()
                    )
            );


            int result =
                    pstmt.executeUpdate();

            if (result > 0) {

                rs =
                        pstmt.getGeneratedKeys();

                if (rs.next()) {

                    bill.setBillId(
                            rs.getInt(1)
                    );
                }

                return true;
            }

            return false;

        } catch(Exception e) {

            e.printStackTrace();
            return false;


        } finally {

            DBUtil.close(conn,pstmt,rs);
        }
    }





    // 根据编号查询
    public DormFeeBill findById(int billId) {


        DormFeeBill bill = null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;


        try {


            conn = DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_fee_bill "
                    + "WHERE billId=?";


            pstmt = conn.prepareStatement(sql);

            pstmt.setInt(
                    1,
                    billId
            );


            rs = pstmt.executeQuery();


            if(rs.next())
                bill = toDormFeeBill(rs);


        } catch(Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(conn,pstmt,rs);
        }


        return bill;
    }



    public boolean existsBill(
            int accommodationId,
            String academicYear,
            String semester) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT billId "
                    + "FROM tbl_dorm_fee_bill "
                    + "WHERE accommodationId=? "
                    + "AND academicYear=? "
                    + "AND semester=? "
                    + "AND status<>?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setInt(
                    1,
                    accommodationId
            );

            pstmt.setString(
                    2,
                    academicYear
            );

            pstmt.setString(
                    3,
                    semester
            );

            pstmt.setString(
                    4,
                    FeeStatus.CANCELLED.name()
            );

            rs =
                    pstmt.executeQuery();

            return rs.next();

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }
    }
    
    
 // 查询学生账单
    public List<DormFeeBill> queryByStudent(
            String sId) {

        List<DormFeeBill> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_fee_bill "
                    + "WHERE sId=? "
                    + "ORDER BY createTime DESC";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    sId
            );

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormFeeBill(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }

 // 查询指定学生尚未缴清的账单
    public List<DormFeeBill> queryUnpaidByStudent(
            String sId) {

        List<DormFeeBill> list =
                new ArrayList<>();

        if (sId == null
                || sId.trim().isEmpty()) {

            return list;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_fee_bill "
                    + "WHERE sId=? "
                    + "AND status IN (?,?,?) "
                    + "ORDER BY dueDate";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    sId.trim()
            );

            pstmt.setString(
                    2,
                    FeeStatus.UNPAID.name()
            );

            pstmt.setString(
                    3,
                    FeeStatus.PARTIALLY_PAID.name()
            );

            pstmt.setString(
                    4,
                    FeeStatus.OVERDUE.name()
            );

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormFeeBill(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


 // 查询全部住宿费账单
    public List<DormFeeBill> queryAll() {

        List<DormFeeBill> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_fee_bill "
                    + "ORDER BY createTime DESC";

            pstmt =
                    conn.prepareStatement(sql);

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormFeeBill(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


    // 根据住宿记录查询账单
    public List<DormFeeBill> queryByAccommodation(
            int accommodationId) {


        List<DormFeeBill> list =
                new ArrayList<>();


        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_fee_bill "
                    + "WHERE accommodationId=?";


            pstmt=conn.prepareStatement(sql);

            pstmt.setInt(
                    1,
                    accommodationId
            );


            rs=pstmt.executeQuery();


            while(rs.next())
                list.add(toDormFeeBill(rs));


        } catch(Exception e){

            e.printStackTrace();

        } finally {

            DBUtil.close(conn,pstmt,rs);
        }


        return list;
    }






    public List<DormFeeBill> queryUnpaid() {

        List<DormFeeBill> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT * "
                    + "FROM tbl_dorm_fee_bill "
                    + "WHERE status IN (?,?,?) "
                    + "ORDER BY dueDate";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    FeeStatus.UNPAID.name()
            );

            pstmt.setString(
                    2,
                    FeeStatus.PARTIALLY_PAID.name()
            );

            pstmt.setString(
                    3,
                    FeeStatus.OVERDUE.name()
            );

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toDormFeeBill(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


 // 修改账单应缴金额
    public boolean updateAmount(
            int billId,
            double amount) {

        if (billId <= 0
                || amount <= 0) {

            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "UPDATE tbl_dorm_fee_bill "
                    + "SET amount=? "
                    + "WHERE billId=?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setDouble(
                    1,
                    amount
            );

            pstmt.setInt(
                    2,
                    billId
            );

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    null
            );
        }
    }
    
 // 修改账单状态
    public boolean updateStatus(
            int billId,
            FeeStatus status) {

        if (billId <= 0
                || status == null) {

            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "UPDATE tbl_dorm_fee_bill "
                    + "SET status=? "
                    + "WHERE billId=?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    status.name()
            );

            pstmt.setInt(
                    2,
                    billId
            );

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    null
            );
        }
    }
    
    

    // 更新缴费信息
    public boolean updatePayment(
            int billId,
            double paidAmount,
            FeeStatus status) {


    	if (billId <= 0
    	        || paidAmount < 0
    	        || status == null) {

    	    return false;
    	}

        Connection conn=null;
        PreparedStatement pstmt=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "UPDATE tbl_dorm_fee_bill "
                    + "SET paidAmount=?,status=? "
                    + "WHERE billId=?";


            pstmt=conn.prepareStatement(sql);


            pstmt.setDouble(
                    1,
                    paidAmount
            );


            pstmt.setString(
                    2,
                    status.name()
            );


            pstmt.setInt(
                    3,
                    billId
            );


            return pstmt.executeUpdate()>0;


        } catch(Exception e){

            e.printStackTrace();

            return false;


        } finally {

            DBUtil.close(conn,pstmt,null);
        }
    }





    // ResultSet转换实体
    private DormFeeBill toDormFeeBill(ResultSet rs)
            throws SQLException {


        DormFeeBill bill =
                new DormFeeBill();


        bill.setBillId(
                rs.getInt("billId")
        );


        bill.setsId(
                rs.getString("sId")
        );


        bill.setAccommodationId(
                rs.getInt("accommodationId")
        );


        bill.setAcademicYear(
                rs.getString("academicYear")
        );


        bill.setSemester(
                rs.getString("semester")
        );


        bill.setAmount(
                rs.getDouble("amount")
        );


        bill.setPaidAmount(
                rs.getDouble("paidAmount")
        );


        bill.setDueDate(
                rs.getDate("dueDate")
        );


        bill.setStatus(
                FeeStatus.valueOf(
                        rs.getString("status")
                )
        );


        bill.setCreateTime(
                rs.getTimestamp("createTime")
        );


        return bill;
    }

}