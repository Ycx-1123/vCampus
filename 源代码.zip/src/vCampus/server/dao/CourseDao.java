package vCampus.server.dao;

import vCampus.common.vo.Course;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CourseDao {
    //查询
    //获取所有课程列表
	public List<Course> getAllCourses() throws SQLException {
	    List<Course> list = new ArrayList<>();
	    String sql = "SELECT c.courseId, c.courseName, c.courseCredit, c.courseHours, " +
	                 "c.categoryId, cat.categoryName, c.courseDescription " +
	                 "FROM tbl_course c " +
	                 "LEFT JOIN tbl_category cat ON c.categoryId = cat.categoryId " +
	                 "ORDER BY c.courseId";

	    try (Connection conn = DBUtil.getConnection();
	         Statement stmt = conn.createStatement();
	         ResultSet rs = stmt.executeQuery(sql)) {
	        while (rs.next()) {
	            Course course = new Course();
	            course.setCourseId(rs.getString("courseId"));
	            course.setCourseName(rs.getString("courseName"));
	            course.setCredit(rs.getDouble("courseCredit"));
	            course.setHours(rs.getInt("courseHours"));
	            course.setCategoryId(rs.getString("categoryId"));
	            course.setCategoryName(rs.getString("categoryName"));
	            course.setDescription(rs.getString("courseDescription"));
	            list.add(course);
	        }
	    }
	    return list;
	}

    //根据课程ID查询单门课程
    public Course getCourseById(String courseId) throws SQLException {
        String sql = "SELECT c.courseId, c.courseName, c.courseCredit, c.courseHours, " +
                     "c.categoryId, cat.categoryName, c.courseDescription " +
                     "FROM tbl_course c " +
                     "LEFT JOIN tbl_category cat ON c.categoryId = cat.categoryId " +
                     "WHERE c.courseId = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getString("courseId"));
                    course.setCourseName(rs.getString("courseName"));
                    course.setCredit(rs.getDouble("courseCredit"));
                    course.setHours(rs.getInt("courseHours"));
                    course.setCategoryId(rs.getString("categoryId"));
                    course.setCategoryName(rs.getString("categoryName"));
                    course.setDescription(rs.getString("courseDescription"));
                    return course;
                }
            }
        }
        return null;
    }

    //根据分类Id查询课程
    public List<Course> getCourseByCategory(String categoryId) throws SQLException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_course WHERE categoryId = ? ORDER BY courseId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, categoryId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRowToCourse(rs));
                }
            }
        }
        return list;
    }

    //模糊搜索
    public List<Course> searchCourses(String keyword) throws SQLException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_course WHERE courseName LIKE ? OR courseId LIKE ? ORDER BY courseId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);  // 修复：之前两个都是索引1
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRowToCourse(rs));
                }
            }
        }
        return list;
    }

    //批量查询
    public List<Course> getCoursesByIds(List<String> courseIds) throws SQLException {
        if (courseIds == null || courseIds.isEmpty()) {
            return new ArrayList<>();
        }

        // 构建 IN 占位符：?, ?, ?, ...
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < courseIds.size(); i++) {
            if (i > 0) placeholders.append(",");
            placeholders.append("?");
        }

        String sql = "SELECT * FROM tbl_course WHERE courseId IN (" + placeholders.toString() + ")";

        List<Course> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (int i = 0; i < courseIds.size(); i++) {
                pstmt.setString(i + 1, courseIds.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRowToCourse(rs));
                }
            }
        }
        return list;
    }

    //插入新课程
    public void insertCourse(Course course) throws SQLException {
        String sql = "INSERT INTO tbl_course (courseId, courseName, courseCredit, courseHours, categoryId, courseDescription) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, course.getCourseId());
            pstmt.setString(2, course.getCourseName());
            pstmt.setDouble(3, course.getCredit());
            pstmt.setInt(4, course.getHours());
            pstmt.setString(5, course.getCategoryId());
            pstmt.setString(6, course.getDescription());

            pstmt.executeUpdate();
        }
    }

    //批量插入课程
    public void insertCourses(List<Course> courses) throws SQLException {
        String sql = "INSERT INTO tbl_course (courseId, courseName, courseCredit, courseHours, categoryId, courseDescription) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (Course course : courses) {
                pstmt.setString(1, course.getCourseId());
                pstmt.setString(2, course.getCourseName());
                pstmt.setDouble(3, course.getCredit());
                pstmt.setInt(4, course.getHours());
                pstmt.setString(5, course.getCategoryId());
                pstmt.setString(6, course.getDescription());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }

    //更新
    public void updateCourse(Course course) throws SQLException {
        String sql = "UPDATE tbl_course SET courseName = ?, courseCredit = ?, courseHours = ?, " +
                     "categoryId = ?, courseDescription = ? WHERE courseId = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, course.getCourseName());
            pstmt.setDouble(2, course.getCredit());
            pstmt.setInt(3, course.getHours());
            pstmt.setString(4, course.getCategoryId());
            pstmt.setString(5, course.getDescription());
            pstmt.setString(6, course.getCourseId());

            pstmt.executeUpdate();
        }
    }

    //删除方法
    /**
     * 删除课程（级联删除所有关联的开课班级）
     */
    public void deleteCourse(String courseId) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            // 先删除所有关联的开课班级
            String deleteOfferingSql = "DELETE FROM tbl_courseOffering WHERE courseId = ?";
            pstmt = conn.prepareStatement(deleteOfferingSql);
            pstmt.setString(1, courseId);
            int deletedOfferings = pstmt.executeUpdate();
            if (deletedOfferings > 0) {
                System.out.println("已删除 " + deletedOfferings + " 个关联的开课班级");
            }
            pstmt.close();

            // 删除课程模板
            String deleteSql = "DELETE FROM tbl_course WHERE courseId = ?";
            pstmt = conn.prepareStatement(deleteSql);
            pstmt.setString(1, courseId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("删除失败，课程ID不存在：" + courseId);
            }

            conn.commit();
            System.out.println("课程删除成功，课程ID：" + courseId);

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            throw e;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //统计课程总数
    public int countCourses() throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_course";

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        }
    }

    //统计某分类下的课程模板总数量
    public int countCoursesByCategory(String categoryId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_course WHERE categoryId = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, categoryId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
                return 0;
            }
        }
    }

    //检查某课程是否存在
    public boolean existsCourse(String courseId) throws SQLException {
        String sql = "SELECT 1 FROM tbl_course WHERE courseId = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // 将 ResultSet 映射到 Course 对象
    private Course mapRowToCourse(ResultSet rs) throws SQLException {
        Course c = new Course();
        c.setCourseId(rs.getString("courseId"));
        c.setCourseName(rs.getString("courseName"));
        c.setCredit(rs.getDouble("courseCredit"));      // 改为 courseCredit
        c.setHours(rs.getInt("courseHours"));           // 改为 courseHours
        c.setCategoryId(rs.getString("categoryId"));
        c.setDescription(rs.getString("courseDescription"));  // 改为 courseDescription
        return c;
    }

    public static void main(String[] args) {
        CourseDao dao = new CourseDao();

        try {
            // ==========================================
            // 测试 1：查询所有课程
            // ==========================================
            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  测试 1：查询所有课程                ║");
            System.out.println("╚══════════════════════════════════════╝");
            List<Course> all = dao.getAllCourses();
            System.out.println("共查询到 " + all.size() + " 门课程：");
            for (Course c : all) {
                System.out.println("  " + c.getCourseId() + " | " + c.getCourseName() + " | " + c.getCredit() + "学分");
            }
            System.out.println();

            // ==========================================
            // 测试 2：根据 ID 查询单门课程
            // ==========================================
            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  测试 2：根据 ID 查询课程            ║");
            System.out.println("╚══════════════════════════════════════╝");
            String testId = "CS101";
            Course c = dao.getCourseById(testId);
            if (c != null) {
                System.out.println("  查询 " + testId + " 成功：");
                System.out.println("    课程名：" + c.getCourseName());
                System.out.println("    学分：" + c.getCredit());
                System.out.println("    学时：" + c.getHours());
                System.out.println("    分类ID：" + c.getCategoryId());
                System.out.println("    描述：" + c.getDescription());
            } else {
                System.out.println("  ❌ 课程 " + testId + " 不存在！");
            }
            System.out.println();

            // ==========================================
            // 测试 3：模糊搜索
            // ==========================================
            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  测试 3：模糊搜索（关键词：数据）    ║");
            System.out.println("╚══════════════════════════════════════╝");
            List<Course> searched = dao.searchCourses("数据");
            System.out.println("  搜索到 " + searched.size() + " 门课程：");
            for (Course course : searched) {
                System.out.println("    " + course.getCourseId() + " | " + course.getCourseName());
            }
            System.out.println();

            // ==========================================
            // 测试 4：统计课程总数
            // ==========================================
            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  测试 4：统计课程总数                ║");
            System.out.println("╚══════════════════════════════════════╝");
            int count = dao.countCourses();
            System.out.println("  课程总数：" + count);
            System.out.println();

            // ==========================================
            // 测试 5：存在性检查
            // ==========================================
            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  测试 5：存在性检查                  ║");
            System.out.println("╚══════════════════════════════════════╝");
            boolean exists = dao.existsCourse("CS101");
            System.out.println("  CS101 是否存在：" + (exists ? "✅ 是" : "❌ 否"));
            exists = dao.existsCourse("CS999");
            System.out.println("  CS999 是否存在：" + (exists ? "✅ 是" : "❌ 否"));
            System.out.println();

            // ==========================================
            // 测试 6：插入新课程（可选，慎用）
            // ==========================================
            // System.out.println("╔══════════════════════════════════════╗");
            // System.out.println("║  测试 6：插入新课程                  ║");
            // System.out.println("╚══════════════════════════════════════╝");
            // Course newCourse = new Course("CS999", "测试课程", 1.0, 16, "C001", "仅供测试使用");
            // dao.insertCourse(newCourse);
            // System.out.println("  ✅ 插入成功！");
            // // 验证是否插入成功
            // Course inserted = dao.getCourseById("CS999");
            // System.out.println("  验证查询：" + (inserted != null ? inserted.getCourseName() : "❌ 未找到"));

            System.out.println("╔══════════════════════════════════════╗");
            System.out.println("║  ✅ 所有测试执行完毕！               ║");
            System.out.println("╚══════════════════════════════════════╝");

        } catch (SQLException e) {
            System.err.println("❌ 测试失败！错误信息：");
            e.printStackTrace();
        }
    }
}