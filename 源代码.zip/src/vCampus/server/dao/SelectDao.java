package vCampus.server.dao;

import vCampus.common.vo.SelectRecord;
import vCampus.common.vo.StudentScoreDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;
public class SelectDao {

    // ============================================================
    // 一、私有映射方法
    // ============================================================

    private SelectRecord mapRow(ResultSet rs) throws SQLException {
        SelectRecord sr = new SelectRecord();
        sr.setSelectId(rs.getInt("selectId"));
        sr.setStudentId(rs.getString("sCard"));
        sr.setOfferingId(rs.getString("offeringId"));
        sr.setSelectTime(rs.getTimestamp("selectTime"));
        sr.setScore(rs.getDouble("score"));
        if (rs.wasNull()) sr.setScore(null);
        sr.setStatus(rs.getString("selectStatus"));
        sr.setSelectType(rs.getString("selectType"));
        return sr;
    }

    // ============================================================
    // 二、查询方法
    // ============================================================

    public List<SelectRecord> getByStudentId(String studentId) throws SQLException {
        List<SelectRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_select WHERE sCard = ? ORDER BY selectId DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public List<SelectRecord> getByOfferingId(String offeringId) throws SQLException {
        List<SelectRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_select WHERE offeringId = ? ORDER BY selectId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public SelectRecord getByStudentAndOffering(String studentId, String offeringId) throws SQLException {
        String sql = "SELECT * FROM tbl_select WHERE sCard = ? AND offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public boolean existsSelectRecord(String studentId, String offeringId) throws SQLException {
        String sql = "SELECT 1 FROM tbl_select WHERE sCard = ? AND offeringId = ? AND selectStatus = 'selected'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    public SelectRecord getSelectRecord(int selectId) throws SQLException {
        String sql = "SELECT * FROM tbl_select WHERE selectId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, selectId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    // ============================================================
    // 三、统计方法（首修/重修判断）
    // ============================================================

    public int countHistorySelectRecords(String studentId, String courseId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? AND o.courseId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    public boolean hasPassedCourse(String studentId, String courseId) throws SQLException {
        String sql = "SELECT 1 FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? AND o.courseId = ? AND s.score >= 60";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ============================================================
    // 三之补充：重修相关新增方法
    // ============================================================

    /**
     * 查询学生某课程的最新一次成绩（用于判断是否不及格）
     * 按 selectTime 倒序取第一条
     */
    public Double getLatestScore(String studentId, String courseId) throws SQLException {
        String sql = "SELECT s.score FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? AND o.courseId = ? " +
                     "ORDER BY s.selectTime DESC LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double v = rs.getDouble(1);
                    if (rs.wasNull()) return null;
                    return v;
                }
            }
        }
        return null;
    }

    /**
     * 查询学生所有不及格的课程ID（重修待选课程）
     * 规则：该课程存在 score < 60 的历史记录
     */
    public Set<String> getFailedCourseIds(String studentId, String currentSemester) throws SQLException {
        Set<String> result = new HashSet<>();
        String sql = "SELECT DISTINCT o.courseId FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? AND s.score IS NOT NULL AND s.score < 60 " +
                     "AND o.COsemester <> ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, currentSemester);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) result.add(rs.getString(1));
            }
        }
        return result;
    }

    /**
     * 判断学生某课程是否不及格（存在 < 60 分记录）
     */
    public boolean hasFailedCourse(String studentId, String courseId, String currentSemester) throws SQLException {
        String sql = "SELECT 1 FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? AND o.courseId = ? " +
                     "AND s.score IS NOT NULL AND s.score < 60 " +
                     "AND o.COsemester <> ? LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, courseId);
            pstmt.setString(3, currentSemester);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ============================================================
    // 四、教师端专用查询（返回StudentScoreDTO）
    // ============================================================

    /**
     * 根据开课班级ID获取学生选课详情（含学生姓名、班级等信息）
     */
    public List<StudentScoreDTO> getStudentsByOfferingId(String offeringId) throws SQLException {
        List<StudentScoreDTO> list = new ArrayList<>();
        String sql = 
            "SELECT s.selectId, s.sCard, s.selectTime, s.score, s.selectStatus, s.selectType, " +
            "       st.sname, st.sgender, st.clazzid, st.enrollyear, " +
            "       m.majorname AS majorName " +
            "FROM tbl_select s " +
            "LEFT JOIN tbl_student st ON s.sCard = st.scard " +
            "LEFT JOIN tbl_clazz c ON st.clazzid = c.clazzid " +
            "LEFT JOIN tbl_major m ON c.majorid = m.majorid " +
            "WHERE s.offeringId = ? " +
            "ORDER BY s.selectId";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, offeringId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    StudentScoreDTO dto = new StudentScoreDTO();
                    dto.setSelectId(rs.getInt("selectId"));
                    dto.setStudentId(rs.getString("sCard"));
                    dto.setStudentName(rs.getString("sname"));
                    dto.setGender(rs.getString("sgender"));
                    dto.setClassName(rs.getString("clazzid"));
                    dto.setMajor(rs.getString("majorName"));
                    dto.setSelectType(rs.getString("selectType"));
                    Double score = rs.getDouble("score");
                    if (rs.wasNull()) {
                        dto.setScore(null);
                    } else {
                        dto.setScore(score);
                    }
                    dto.setStatus(rs.getString("selectStatus"));
                    list.add(dto);
                }
            }
        }
        return list;
    }

    /**
     * 根据开课班级ID和关键词搜索学生（按姓名或学号）
     */
    public List<StudentScoreDTO> searchStudentsByOfferingId(String offeringId, String keyword) throws SQLException {
        List<StudentScoreDTO> list = new ArrayList<>();
        String sql = 
            "SELECT s.selectId, s.sCard, s.selectTime, s.score, s.selectStatus, s.selectType, " +
            "       st.sname, st.sgender, st.clazzid, st.enrollyear, " +
            "       m.majorname AS majorName " +
            "FROM tbl_select s " +
            "LEFT JOIN tbl_student st ON s.sCard = st.scard " +
            "LEFT JOIN tbl_clazz c ON st.clazzid = c.clazzid " +
            "LEFT JOIN tbl_major m ON c.majorid = m.majorid " +
            "WHERE s.offeringId = ? " +
            "AND (st.sname LIKE ? OR s.sCard LIKE ?) " +
            "ORDER BY s.selectId";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            pstmt.setString(1, offeringId);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    StudentScoreDTO dto = new StudentScoreDTO();
                    dto.setSelectId(rs.getInt("selectId"));
                    dto.setStudentId(rs.getString("sCard"));
                    dto.setStudentName(rs.getString("sname"));
                    dto.setGender(rs.getString("sgender"));
                    dto.setClassName(rs.getString("clazzid"));
                    dto.setMajor(rs.getString("majorName"));
                    dto.setSelectType(rs.getString("selectType"));
                    Double score = rs.getDouble("score");
                    if (rs.wasNull()) {
                        dto.setScore(null);
                    } else {
                        dto.setScore(score);
                    }
                    dto.setStatus(rs.getString("selectStatus"));
                    list.add(dto);
                }
            }
        }
        return list;
    }

    // ============================================================
    // 五、插入方法
    // ============================================================

    public void insertSelectRecord(SelectRecord record) throws SQLException {
        String sql = "INSERT INTO tbl_select (sCard, offeringId, selectTime, selectStatus, selectType) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, record.getStudentId());
            pstmt.setString(2, record.getOfferingId());
            pstmt.setTimestamp(3, new Timestamp(record.getSelectTime().getTime()));
            pstmt.setString(4, record.getStatus());
            pstmt.setString(5, record.getSelectType());
            pstmt.executeUpdate();
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) record.setSelectId(rs.getInt(1));
            }
        }
    }

    // ============================================================
    // 六、更新方法
    // ============================================================

    public void updateStatus(int selectId, String status) throws SQLException {
        String sql = "UPDATE tbl_select SET selectStatus = ? WHERE selectId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, selectId);
            pstmt.executeUpdate();
        }
    }

    public void updateScore(int selectId, double score) throws SQLException {
        String sql = "UPDATE tbl_select SET score = ? WHERE selectId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, score);
            pstmt.setInt(2, selectId);
            pstmt.executeUpdate();
        }
    }

    // ============================================================
    // 七、删除方法
    // ============================================================

    public void deleteSelectRecord(int selectId) throws SQLException {
        String sql = "DELETE FROM tbl_select WHERE selectId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, selectId);
            pstmt.executeUpdate();
        }
    }

    public void deleteSelectRecord(String studentId, String offeringId) throws SQLException {
        String sql = "DELETE FROM tbl_select WHERE sCard = ? AND offeringId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, offeringId);
            pstmt.executeUpdate();
        }
    }
    /**
     * 查询学生在非当前学期已修（及格）的课程 ID + 成绩
     * 返回 Map<courseId, 最高成绩>
     */
    public Map<String, Double> getPassedCoursesWithScore(String studentId, String currentSemester) throws SQLException {
        Map<String, Double> result = new HashMap<>();
        String sql = "SELECT o.courseId, MAX(s.score) AS maxScore " +
                     "FROM tbl_select s " +
                     "JOIN tbl_courseOffering o ON s.offeringId = o.offeringId " +
                     "WHERE s.sCard = ? " +
                     "AND s.score IS NOT NULL " +
                     "AND s.score >= 60 " +
                     "AND o.COsemester <> ? " +
                     "GROUP BY o.courseId";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            pstmt.setString(2, currentSemester);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    result.put(rs.getString("courseId"), rs.getDouble("maxScore"));
                }
            }
        }
        return result;
    }
}