package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.vo.Book;

/** 数据访问类：对应 tbl_book。 */
public class BookDao {

    public List<Book> findAll() throws SQLException {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM tbl_book ORDER BY bId";
        try (Connection connection = DBUtil.getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                books.add(mapRow(resultSet));
            }
        }
        return books;
    }

    public List<Book> search(String keyword) throws SQLException {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM tbl_book WHERE bId LIKE ? OR bName LIKE ? OR bAuthor LIKE ? "
                + "ORDER BY bId";
        String pattern = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, pattern);
            statement.setString(2, pattern);
            statement.setString(3, pattern);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    books.add(mapRow(resultSet));
                }
            }
        }
        return books;
    }

    public Book findById(String bookId) throws SQLException {
        String sql = "SELECT * FROM tbl_book WHERE bId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapRow(resultSet) : null;
            }
        }
    }

    public boolean add(Book book) throws SQLException {
        String sql = "INSERT INTO tbl_book (bId, bName, bAuthor, bPublisher, categoryId, publishYear, bTotal, bAvailable) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, book.getBookId());
            statement.setString(2, book.getBookName());
            statement.setString(3, book.getbAuthor());
            statement.setString(4, book.getbPublisher());
            statement.setString(5, book.getCategoryId());
            if (book.getPublishYear() == null) {
                statement.setNull(6, java.sql.Types.INTEGER);
            } else {
                statement.setInt(6, book.getPublishYear());
            }
            statement.setInt(7, book.getbTotal());
            statement.setInt(8, book.getbAvailable());
            return statement.executeUpdate() == 1;
        }
    }

    public boolean update(Book book) throws SQLException {
        String sql = "UPDATE tbl_book SET bName=?, bAuthor=?, bPublisher=?, categoryId=?, publishYear=? WHERE bId=?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, book.getBookName());
            statement.setString(2, book.getbAuthor());
            statement.setString(3, book.getbPublisher());
            statement.setString(4, book.getCategoryId());
            if (book.getPublishYear() == null) {
                statement.setNull(5, java.sql.Types.INTEGER);
            } else {
                statement.setInt(5, book.getPublishYear());
            }
            statement.setString(6, book.getBookId());
            return statement.executeUpdate() == 1;
        }
    }

    public boolean delete(String bookId) throws SQLException {
        String checkSql = "SELECT COUNT(*) FROM tbl_book_copy WHERE bookId = ?";
        String deleteSql = "DELETE FROM tbl_book WHERE bId = ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement check = connection.prepareStatement(checkSql)) {
            check.setString(1, bookId);
            try (ResultSet resultSet = check.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    throw new SQLException("该书目仍有馆藏副本，不能删除：" + bookId);
                }
            }
            try (PreparedStatement delete = connection.prepareStatement(deleteSql)) {
                delete.setString(1, bookId);
                return delete.executeUpdate() == 1;
            }
        }
    }

    /** 在同一事务中同步书目的总副本数和可借副本数。 */
    static void refreshStatistics(Connection connection, String bookId) throws SQLException {
        int total = countCopies(connection, bookId, false);
        int available = countCopies(connection, bookId, true);
        String sql = "UPDATE tbl_book SET bTotal = ?, bAvailable = ? WHERE bId = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, total);
            statement.setInt(2, available);
            statement.setString(3, bookId);
            statement.executeUpdate();
        }
    }

    private static int countCopies(Connection connection, String bookId, boolean onlyAvailable) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tbl_book_copy WHERE bookId = ?"
                + (onlyAvailable ? " AND status = 'AVAILABLE'" : "");
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt(1) : 0;
            }
        }
    }

    private Book mapRow(ResultSet resultSet) throws SQLException {
        Book book = new Book();
        book.setBookId(resultSet.getString("bId"));
        book.setBookName(resultSet.getString("bName"));
        book.setbAuthor(resultSet.getString("bAuthor"));
        book.setbPublisher(resultSet.getString("bPublisher"));
        book.setCategoryId(resultSet.getString("categoryId"));
        Object publishYear = resultSet.getObject("publishYear");
        book.setPublishYear(publishYear == null ? null : resultSet.getInt("publishYear"));
        book.setbTotal(resultSet.getInt("bTotal"));
        book.setbAvailable(resultSet.getInt("bAvailable"));
        return book;
    }
}
