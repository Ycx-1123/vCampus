package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import vCampus.common.vo.Student;
import vCampus.common.vo.LibraryReader;

public class StudentDao {

    // 查询所有学生记录
    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            stmt = conn.createStatement();
            //加入 sphone, semail, saddress
            String sql = "SELECT sid, sname, sgender, clazzid, enrollyear, scard, islocked, finishedcredit, requiredcredit, sphone, semail, saddress FROM tbl_student";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Student s = new Student();
                s.setSId(rs.getString("sid"));
                s.setSname(rs.getString("sname"));
                s.setSgender(rs.getString("sgender"));
                s.setClazzid(rs.getString("clazzid"));
                s.setEnrollYear(rs.getString("enrollyear"));
                s.setSCard(rs.getString("scard"));
                s.setLocked(rs.getBoolean("islocked"));
                s.setFinishedCredit((Double) rs.getObject("finishedcredit"));
                s.setRequiredCredit((Double) rs.getObject("requiredcredit"));
                //读取新增字段
                s.setSphone(rs.getString("sphone"));
                s.setSemail(rs.getString("semail"));
                s.setSaddress(rs.getString("saddress"));
                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, stmt, rs);
        }
        return list;
    }

    // 根据一卡通查询单条记录
    public Student findBySCard(String sCard) {
        Student s = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            System.out.println("===当前JDBC连接地址："+conn.getMetaData().getURL());
            
            if(sCard != null){
                sCard = sCard.trim();
            }
            String sql = "SELECT sid, sname, sgender, clazzid, enrollyear, scard, islocked, finishedcredit, requiredcredit, sphone, semail, saddress, sbalance FROM tbl_student WHERE Trim(scard) = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sCard);
            rs = pstmt.executeQuery();

            System.out.println("DAO将要查询的一卡通号=["+sCard+"]");

            if (rs.next()) {
                s = new Student();
                String sid = rs.getString("sid");
                String sname = rs.getString("sname");
                String sgender = rs.getString("sgender");
                String clazzid = rs.getString("clazzid");
                String enrollyear = rs.getString("enrollyear");
                String scardVal = rs.getString("scard");
                Boolean isLocked = rs.getBoolean("islocked");

                Double finished = (Double) rs.getObject("finishedcredit");
                Double required = (Double) rs.getObject("requiredcredit");

                String sphone = rs.getString("sphone");
                String semail = rs.getString("semail");
                String saddress = rs.getString("saddress");
                Double sbalance = rs.getDouble("sbalance");

                //读完ResultSet，立刻赋值给VO
                s.setSId(sid);
                s.setSname(sname);
                s.setSgender(sgender);
                s.setClazzid(clazzid);
                s.setEnrollYear(enrollyear);
                s.setSCard(scardVal);
                s.setLocked(isLocked);
                s.setFinishedCredit(finished);
                s.setRequiredCredit(required);
                s.setSphone(sphone);
                s.setSemail(semail);
                s.setSaddress(saddress);
                s.setSbalance(sbalance);

                System.out.println("DAO成功查到学生！sCard = "+s.getSCard());
            }else{
                System.out.println("ResultSet没有任何一行匹配！");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return s;
    }


    public List<Student> findStudentByClazzId(String clazzid){
        List<Student> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT sid, sname, sgender, clazzid, enrollyear, scard, islocked, finishedcredit, requiredcredit, sphone, semail, saddress FROM tbl_student WHERE Trim(clazzid) = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, clazzid);
            rs = pstmt.executeQuery();

            while(rs.next()) {
                Student s = new Student();
                s.setSId(rs.getString("sid"));
                s.setSname(rs.getString("sname"));
                s.setSgender(rs.getString("sgender"));
                s.setClazzid(rs.getString("clazzid"));
                s.setEnrollYear(rs.getString("enrollyear"));
                s.setSCard(rs.getString("scard"));
                s.setLocked(rs.getBoolean("islocked"));
                s.setFinishedCredit((Double) rs.getObject("finishedcredit"));
                s.setRequiredCredit((Double) rs.getObject("requiredcredit"));
                s.setSphone(rs.getString("sphone"));
                s.setSemail(rs.getString("semail"));
                s.setSaddress(rs.getString("saddress"));
                list.add(s);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            DBUtil.close(conn,pstmt,rs);
        }
        return list;
    }


 // 添加学生记录
    public boolean add(Student student) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);
            String sql = "INSERT INTO tbl_student(sid, sname, sgender, clazzid, enrollyear, scard, spassword, islocked, finishedcredit, requiredcredit, sphone, semail, saddress) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, student.getSId());
            pstmt.setString(2, student.getSname());
            pstmt.setString(3, student.getSgender());
            pstmt.setString(4, student.getClazzid());
            pstmt.setString(5, student.getEnrollYear());
            pstmt.setString(6, student.getSCard());
            pstmt.setString(7, student.getSpassword());
            pstmt.setBoolean(8, student.isLocked() != null && student.isLocked());
            if (student.getFinishedCredit() != null) {
                pstmt.setDouble(9, student.getFinishedCredit());
            } else {
                pstmt.setNull(9, java.sql.Types.DOUBLE);
            }
            if (student.getRequiredCredit() != null) {
                pstmt.setDouble(10, student.getRequiredCredit());
            } else {
                pstmt.setNull(10, java.sql.Types.DOUBLE);
            }
            pstmt.setString(11, student.getSphone());
            pstmt.setString(12, student.getSemail());
            pstmt.setString(13, student.getSaddress());
            
            int rows = pstmt.executeUpdate();
            if (rows != 1) {
                conn.rollback();
                return false;
            }
            conn.commit();
            return true;
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) { }
            }
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }

    // 更新学生记录 —— 保存修改按钮最终调用这个！
    public boolean update(Student student) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();
            //SET子句加入 sphone,semail,saddress
            String sql = "UPDATE tbl_student SET sname=?, sgender=?, clazzid=?, enrollyear=?, sid=?, islocked=?, finishedcredit=?, requiredcredit=?, sphone=?, semail=?, saddress=? WHERE scard=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, student.getSname());
            pstmt.setString(2, student.getSgender());
            pstmt.setString(3, student.getClazzid());
            pstmt.setString(4, student.getEnrollYear());
            pstmt.setString(5, student.getSId());
            pstmt.setBoolean(6, student.isLocked() != null && student.isLocked());

            if (student.getFinishedCredit() != null) {
                pstmt.setDouble(7, student.getFinishedCredit());
            } else {
                pstmt.setNull(7, java.sql.Types.DOUBLE);
            }

            if (student.getRequiredCredit() != null) {
                pstmt.setDouble(8, student.getRequiredCredit());
            } else {
                pstmt.setNull(8, java.sql.Types.DOUBLE);
            }
            //可编辑字段
            pstmt.setString(9, student.getSphone());
            pstmt.setString(10, student.getSemail());
            pstmt.setString(11, student.getSaddress());
            //where条件一卡通号，第12个位置
            pstmt.setString(12, student.getSCard());

            int rows = pstmt.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }

    // 根据一卡通删除记录
    public boolean delete(String sCard) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "DELETE FROM tbl_student WHERE Trim(scard)=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sCard);

            int rows = pstmt.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }

    public boolean lockStudent(String sCard) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE tbl_student SET islocked = -1 WHERE Trim(scard)=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sCard);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }


    public boolean unlockStudent(String sCard) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE tbl_student SET islocked = 0 WHERE Trim(scard)=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sCard);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.close(conn, pstmt, null);
        }
    }
    /**
     * 按关键词模糊搜索学生（支持学号、姓名、班级）
     */
    public List<Student> searchStudents(String keyword) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT sid, sname, sgender, clazzid, enrollyear, scard, islocked, " +
                     "finishedcredit, requiredcredit, sphone, semail, saddress " +
                     "FROM tbl_student " +
                     "WHERE Trim(scard) LIKE ? OR sname LIKE ? OR Trim(clazzid) LIKE ? OR sid LIKE ? " +
                     "ORDER BY scard";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            String pattern = "%" + keyword.trim() + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            pstmt.setString(4, pattern);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Student s = new Student();
                s.setSId(rs.getString("sid"));
                s.setSname(rs.getString("sname"));
                s.setSgender(rs.getString("sgender"));
                s.setClazzid(rs.getString("clazzid"));
                s.setEnrollYear(rs.getString("enrollyear"));
                s.setSCard(rs.getString("scard"));
                s.setLocked(rs.getBoolean("islocked"));
                s.setFinishedCredit((Double) rs.getObject("finishedcredit"));
                s.setRequiredCredit((Double) rs.getObject("requiredcredit"));
                s.setSphone(rs.getString("sphone"));
                s.setSemail(rs.getString("semail"));
                s.setSaddress(rs.getString("saddress"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("搜索学生失败：" + e.getMessage());
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return list;
    }
}
