package vCampus.server.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.PaymentMethod;
import vCampus.common.enums.PaymentStatus;
import vCampus.common.vo.DormPaymentRecord;


public class DormPaymentRecordDAO {


    // 新增支付记录
	public boolean insert(
	        DormPaymentRecord record) {

	    if (record == null) {
	        return false;
	    }

	    if (record.getPaymentStatus() == null) {

	        record.setPaymentStatus(
	                PaymentStatus.PENDING
	        );
	    }

	    if (record.getPaymentMethod() == null) {
	        return false;
	    }


	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;


	    try {

	        conn = DBUtil.getConnection();


	        String sql =
	                "INSERT INTO tbl_dorm_payment_record "
	                + "(billId,sId,amount,paymentMethod,"
	                + "paymentStatus,transactionNumber,paymentTime)"
	                + " VALUES(?,?,?,?,?,?,?)";


	        pstmt =
	                conn.prepareStatement(
	                        sql,
	                        Statement.RETURN_GENERATED_KEYS
	                );


	        pstmt.setInt(
	                1,
	                record.getBillId()
	        );


	        pstmt.setString(
	                2,
	                record.getsId()
	        );


	        pstmt.setDouble(
	                3,
	                record.getAmount()
	        );


	        pstmt.setString(
	                4,
	                record.getPaymentMethod().name()
	        );


	        pstmt.setString(
	                5,
	                record.getPaymentStatus().name()
	        );


	        pstmt.setString(
	                6,
	                record.getTransactionNumber()
	        );


	        pstmt.setTimestamp(
	                7,
	                record.getPaymentTime() == null
	                        ? null
	                        : new Timestamp(
	                                record.getPaymentTime()
	                                        .getTime()
	                        )
	        );


	        int result =
	                pstmt.executeUpdate();


	        if (result > 0) {

	            rs =
	                    pstmt.getGeneratedKeys();


	            if (rs.next()) {

	                record.setPaymentId(
	                        rs.getInt(1)
	                );
	            }


	            return true;
	        }


	        return false;


	    } catch (Exception e) {

	        e.printStackTrace();

	        return false;


	    } finally {

	        DBUtil.close(
	                conn,
	                pstmt,
	                rs
	        );
	    }
	}




    // 根据编号查询
    public DormPaymentRecord findById(int paymentId) {


        DormPaymentRecord record = null;


        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_payment_record "
                    + "WHERE paymentId=?";


            pstmt=conn.prepareStatement(sql);


            pstmt.setInt(
                    1,
                    paymentId
            );


            rs=pstmt.executeQuery();


            if(rs.next())
                record=toPaymentRecord(rs);



        }catch(Exception e){

            e.printStackTrace();


        }finally{

            DBUtil.close(conn,pstmt,rs);

        }


        return record;
    }





    // 查询账单支付记录
    public List<DormPaymentRecord> queryByBill(
            int billId) {


        List<DormPaymentRecord> list =
                new ArrayList<>();


        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_payment_record "
                    + "WHERE billId=? "
                    + "ORDER BY paymentTime DESC";


            pstmt=conn.prepareStatement(sql);


            pstmt.setInt(
                    1,
                    billId
            );


            rs=pstmt.executeQuery();


            while(rs.next())
                list.add(toPaymentRecord(rs));


        }catch(Exception e){

            e.printStackTrace();


        }finally{

            DBUtil.close(conn,pstmt,rs);

        }


        return list;
    }





    // 查询学生支付记录
    public List<DormPaymentRecord> queryByStudent(
            String sId) {


        List<DormPaymentRecord> list =
                new ArrayList<>();


        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "SELECT * FROM tbl_dorm_payment_record "
                    + "WHERE sId=? "
                    + "ORDER BY paymentTime DESC";


            pstmt=conn.prepareStatement(sql);


            pstmt.setString(
                    1,
                    sId
            );


            rs=pstmt.executeQuery();


            while(rs.next())
                list.add(toPaymentRecord(rs));


        }catch(Exception e){

            e.printStackTrace();


        }finally{

            DBUtil.close(conn,pstmt,rs);

        }


        return list;
    }





    // 修改支付状态
    public boolean updateStatus(
            int paymentId,
            PaymentStatus status) {


        if(status==null)
            return false;


        Connection conn=null;
        PreparedStatement pstmt=null;


        try {


            conn=DBUtil.getConnection();


            String sql =
                    "UPDATE tbl_dorm_payment_record "
                    + "SET paymentStatus=? "
                    + "WHERE paymentId=?";


            pstmt=conn.prepareStatement(sql);


            pstmt.setString(
                    1,
                    status.name()
            );


            pstmt.setInt(
                    2,
                    paymentId
            );


            return pstmt.executeUpdate()>0;



        }catch(Exception e){

            e.printStackTrace();

            return false;


        }finally{

            DBUtil.close(conn,pstmt,null);

        }

    }





    // ResultSet转换实体
    private DormPaymentRecord toPaymentRecord(
            ResultSet rs)
            throws SQLException {


        DormPaymentRecord record =
                new DormPaymentRecord();


        record.setPaymentId(
                rs.getInt("paymentId")
        );


        record.setBillId(
                rs.getInt("billId")
        );


        record.setsId(
                rs.getString("sId")
        );


        record.setAmount(
                rs.getDouble("amount")
        );


        record.setPaymentMethod(
                PaymentMethod.valueOf(
                        rs.getString("paymentMethod")
                )
        );


        record.setPaymentStatus(
                PaymentStatus.valueOf(
                        rs.getString("paymentStatus")
                )
        );


        record.setTransactionNumber(
                rs.getString("transactionNumber")
        );


        record.setPaymentTime(
                rs.getTimestamp("paymentTime")
        );


        return record;
    }

}