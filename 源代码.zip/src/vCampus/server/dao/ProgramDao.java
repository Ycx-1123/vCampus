package vCampus.server.dao;

import vCampus.common.vo.Program;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgramDao {

    private Program mapRow(ResultSet rs) throws SQLException {
        Program p = new Program();
        p.setProgramId(rs.getString("programId"));
        p.setProgramName(rs.getString("programName"));
        p.setMajor(rs.getString("major"));
        p.setGrade(rs.getString("grade"));
        p.setTotalCreditsRequired(rs.getInt("totalCreditsRequired"));
        p.setSemester(rs.getString("programSemester"));
        p.setStatus(rs.getString("programStatus"));
        p.setDescription(rs.getString("programDescription"));
        return p;
    }

    //查询

    public List<Program> getAllPrograms() throws SQLException {
        List<Program> list = new ArrayList<>();
        String sql = "SELECT * FROM tbl_program ORDER BY programId";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Program getProgramById(String programId) throws SQLException {
        String sql = "SELECT * FROM tbl_program WHERE programId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    //根据专业和年级匹配培养方案（学生选课时用来获取先修课程规则）
    public Program getProgramByMajorAndGrade(String major, String grade) throws SQLException {
        String sql = "SELECT * FROM tbl_program WHERE major = ? AND grade = ? AND programStatus = 'active'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, major);
            pstmt.setString(2, grade);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    //插入

    public void insertProgram(Program program) throws SQLException {
        String sql = "INSERT INTO tbl_program (programId, programName, major, grade, totalCreditsRequired, programSemester, programStatus, programDescription) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, program.getProgramId());
            pstmt.setString(2, program.getProgramName());
            pstmt.setString(3, program.getMajor());
            pstmt.setString(4, program.getGrade());
            pstmt.setInt(5, program.getTotalCreditsRequired());
            pstmt.setString(6, program.getSemester());
            pstmt.setString(7, program.getStatus());
            pstmt.setString(8, program.getDescription());
            pstmt.executeUpdate();
        }
    }

    //更新

    public void updateProgram(Program program) throws SQLException {
        String sql = "UPDATE tbl_program SET programName = ?, major = ?, grade = ?, " +
                     "totalCreditsRequired = ?, programSemester = ?, programStatus = ?, programDescription = ? WHERE programId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, program.getProgramName());
            pstmt.setString(2, program.getMajor());
            pstmt.setString(3, program.getGrade());
            pstmt.setInt(4, program.getTotalCreditsRequired());
            pstmt.setString(5, program.getSemester());
            pstmt.setString(6, program.getStatus());
            pstmt.setString(7, program.getDescription());
            pstmt.setString(8, program.getProgramId());
            pstmt.executeUpdate();
        }
    }

    //删除

    public void deleteProgram(String programId) throws SQLException {
        String sql = "DELETE FROM tbl_program WHERE programId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            pstmt.executeUpdate();
        }
    }

    public boolean existsProgram(String programId) throws SQLException {
        String sql = "SELECT 1 FROM tbl_program WHERE programId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, programId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
}