package vCampus.server.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.vo.BookCopy;
import vCampus.common.vo.BorrowRecord;
import vCampus.common.vo.ReservationRecord;

/**
 * 数据访问类：对应 tbl_book_borrow_record。
 * 借书、还书和续借均在同一数据库事务中同步副本状态与库存数量。
 */
public class BorrowRecordDao {
    /**
     * Access 数据库对同一行的并发锁能力有限；借书和还书统一串行化，
     * 保证两个客户端同时操作同一副本时，只有事务先完成的一方成功。
     */
    private static final Object CIRCULATION_LOCK = new Object();
    /** 同一读者同时在借的图书上限。规则页与服务端使用同一个值。 */
    private static final int MAX_ACTIVE_BORROWS = 3;
    private static final int NORMAL_LOAN_DAYS = 30;
    private static final int HOT_BOOK_LOAN_DAYS = 14;
    /** 逾期占用费：每册每天 0.10 元，从校园一卡通余额扣除。 */
    private static final double OVERDUE_FINE_PER_DAY = 0.10D;
    /** 项目统一采用固定损坏处理费；图书表当前没有书价字段，避免虚构“实际书价”。 */
    private static final double DAMAGE_FINE = 20.00D;
    private final UserAccountDao userAccountDao = new UserAccountDao();
    private final ReservationRecordDao reservationDao = new ReservationRecordDao();

    /**
     * 借阅具体实体副本。读者被禁借、实体书不可借或预约队列首位不是当前读者时，抛出 SQLException。
     */
    public boolean borrow(String copyId, String readerId, LocalDate borrowDate, LocalDate dueDate) throws SQLException {
        synchronized (CIRCULATION_LOCK) {
            return borrowLocked(copyId, readerId, borrowDate, dueDate);
        }
    }

    private boolean borrowLocked(String copyId, String readerId, LocalDate borrowDate, LocalDate dueDate) throws SQLException {
        if (borrowDate == null) {
            throw new SQLException("借阅日期不能为空");
        }
        try (Connection connection = DBUtil.getConnection()) {
            connection.setAutoCommit(false);
            try {
                checkReaderCanBorrow(connection, readerId, borrowDate);
                checkBorrowLimit(connection, readerId);
                reservationDao.expireReadyReservations(connection, LocalDateTime.now());
                String bookId = findBorrowableBookId(connection, copyId);
                ReservationRecord firstReservation = findFirstActiveReservation(connection, bookId);
                int activeReservationCount = reservationDao.countActiveReservations(connection, bookId);
                int loanDays = activeReservationCount >= ReservationRecordDao.HOT_RESERVATION_THRESHOLD
                        ? HOT_BOOK_LOAN_DAYS : NORMAL_LOAN_DAYS;
                LocalDate calculatedDueDate = borrowDate.plusDays(loanDays);
                if (firstReservation != null && !readerId.equals(firstReservation.getReaderId())) {
                    throw new SQLException("该图书已有预约排队，只有队首读者可以借阅");
                }

                String insertSql = "INSERT INTO tbl_book_borrow_record "
                        + "(recordId, copyId, readerId, borrowDate, dueDate, returnDate, renewCount, overdueDays, status) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement insert = connection.prepareStatement(insertSql)) {
                    insert.setString(1, nextRecordId(connection));
                    insert.setString(2, copyId);
                    insert.setString(3, readerId);
                    insert.setDate(4, Date.valueOf(borrowDate));
                    insert.setDate(5, Date.valueOf(calculatedDueDate));
                    insert.setNull(6, java.sql.Types.DATE);
                    insert.setInt(7, 0);
                    insert.setInt(8, 0);
                    insert.setString(9, BorrowRecord.STATUS_BORROWED);
                    insert.executeUpdate();
                }

                updateCopyStatus(connection, copyId, BookCopy.STATUS_BORROWED);
                if (firstReservation != null) {
                    updateReservationStatus(connection, firstReservation.getReservationId(), ReservationRecord.STATUS_COMPLETED);
                    reservationDao.renumberActiveReservations(connection, bookId);
                }
                BookDao.refreshStatistics(connection, bookId);
                connection.commit();
                return true;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    /** 正常归还图书；若逾期，系统从校园一卡通余额扣除逾期占用费。 */
    public boolean returnBook(String recordId, LocalDate returnDate) throws SQLException {
        return returnBook(recordId, returnDate, false);
    }

    /** 归还时登记损坏：副本停止外借，扣除固定处理费，读者自归还日起禁借 7 天。 */
    public boolean returnDamagedBook(String recordId, LocalDate returnDate) throws SQLException {
        return returnBook(recordId, returnDate, true);
    }

    private boolean returnBook(String recordId, LocalDate returnDate, boolean damaged) throws SQLException {
        return returnBook(recordId, returnDate, damaged, null);
    }

    /** 代还时在归还事务中核验记录归属，防止为错误用户还书。 */
    public boolean returnForReader(String recordId, String readerId, LocalDate date) throws SQLException {
        if (readerId == null || readerId.trim().isEmpty()) throw new SQLException("请填写用户 ID（一卡通号）");
        return returnBook(recordId, date, false, readerId.trim());
    }

    private boolean returnBook(String recordId, LocalDate returnDate, boolean damaged, String expectedReader) throws SQLException {
        synchronized (CIRCULATION_LOCK) {
            return returnBookLocked(recordId, returnDate, damaged, expectedReader);
        }
    }

    private boolean returnBookLocked(String recordId, LocalDate returnDate, boolean damaged, String expectedReader) throws SQLException {
        if (returnDate == null) {
            throw new SQLException("归还日期不能为空");
        }
        try (Connection connection = DBUtil.getConnection()) {
            connection.setAutoCommit(false);
            try {
                ActiveRecord activeRecord = findActiveRecord(connection, recordId);
                if (activeRecord == null) {
                    throw new SQLException("未找到可归还的在借记录");
                }
                if (expectedReader != null && !expectedReader.equals(activeRecord.readerId)) {
                    throw new SQLException("所选借阅记录不属于填写的用户，请核对用户 ID");
                }
                int overdueDays = returnDate.isAfter(activeRecord.dueDate)
                        ? (int) ChronoUnit.DAYS.between(activeRecord.dueDate, returnDate) : 0;
                if (overdueDays > 0) {
                    double fine = overdueDays * OVERDUE_FINE_PER_DAY;
                    if (!userAccountDao.deductBalance(connection, activeRecord.readerId, "CARD", fine)) {
                        throw new SQLException("一卡通余额不足，无法在线自助归还。请前往管理员处办理还书并处理 "
                                + String.format("%.2f", fine) + " 元逾期欠费；系统不会自动转账");
                    }
                }
                if (damaged && !userAccountDao.deductBalance(connection, activeRecord.readerId, "CARD", DAMAGE_FINE)) {
                    throw new SQLException("一卡通余额不足，无法在线完成损坏归还。请前往管理员处办理还书并处理 "
                            + String.format("%.2f", DAMAGE_FINE) + " 元损坏费用；系统不会自动转账");
                }
                String updateSql = "UPDATE tbl_book_borrow_record SET returnDate=?, overdueDays=?, status=? WHERE recordId=?";
                try (PreparedStatement update = connection.prepareStatement(updateSql)) {
                    update.setDate(1, Date.valueOf(returnDate));
                    update.setInt(2, overdueDays);
                    update.setString(3, BorrowRecord.STATUS_RETURNED);
                    update.setString(4, recordId);
                    update.executeUpdate();
                }
                updateCopyStatus(connection, activeRecord.copyId, damaged ? BookCopy.STATUS_DAMAGED : BookCopy.STATUS_AVAILABLE);
                BookDao.refreshStatistics(connection, activeRecord.bookId);
                if (damaged) {
                    applyDamagePenalty(connection, activeRecord.readerId, returnDate);
                } else {
                    markFirstWaitingReservationReady(connection, activeRecord.bookId);
                }
                connection.commit();
                return true;
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    /** 有等待或已就绪预约时，拒绝续借。 */
    public boolean renew(String recordId, LocalDate currentDate) throws SQLException {
        try (Connection connection = DBUtil.getConnection()) {
            connection.setAutoCommit(false);
            try {
                ActiveRecord activeRecord = findActiveRecord(connection, recordId);
                if (activeRecord == null) {
                    throw new SQLException("未找到可续借的在借记录");
                }
                // 热门书在借出时已被固定为 14 天借期；不依赖当前队列是否仍有人，始终不可续借。
                if (activeRecord.isHotLoan()) {
                    throw new SQLException("该书为热门图书，借期固定为 14 天且不可续借；请于 "
                            + activeRecord.dueDate + " 前归还");
                }
                if (findFirstActiveReservation(connection, activeRecord.bookId) != null) {
                    throw new SQLException("该书已有预约排队，为保障后续读者使用，不能续借");
                }
                if (currentDate == null || currentDate.isAfter(activeRecord.dueDate)) {
                    throw new SQLException("图书已逾期，不能续借；请先归还后再办理借阅");
                }
                if (currentDate.isBefore(activeRecord.dueDate.minusDays(10))) {
                    throw new SQLException("续借仅可在应还日前 10 天内办理；本书应还日期为 " + activeRecord.dueDate);
                }
                if (activeRecord.renewCount >= 2) {
                    throw new SQLException("本书已达到 2 次续借上限，请按期归还");
                }
                String sql = "UPDATE tbl_book_borrow_record SET dueDate=?, renewCount=renewCount+1 WHERE recordId=?";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setDate(1, Date.valueOf(activeRecord.dueDate.plusDays(30)));
                    statement.setString(2, recordId);
                    boolean renewed = statement.executeUpdate() == 1;
                    connection.commit();
                    return renewed;
                }
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    /** 将尚未归还且已超过应还日期的记录标为 OVERDUE。 */
    public int markOverdueRecords(LocalDate currentDate) throws SQLException {
        String sql = "UPDATE tbl_book_borrow_record SET status='OVERDUE' "
                + "WHERE status='BORROWED' AND dueDate < ?";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setDate(1, Date.valueOf(currentDate));
            return statement.executeUpdate();
        }
    }

    public List<BorrowRecord> findByReaderId(String readerId) throws SQLException {
        List<BorrowRecord> records = new ArrayList<>();
        String sql = "SELECT br.*, bc.bookId, b.bName AS bookName FROM tbl_book_borrow_record br "
                + "INNER JOIN tbl_book_copy bc ON br.copyId = bc.copyId "
                + "INNER JOIN tbl_book b ON bc.bookId = b.bId "
                + "WHERE br.readerId=? ORDER BY br.borrowDate DESC";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, readerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    records.add(mapRow(resultSet));
                }
            }
        }
        return records;
    }

    public List<BorrowRecord> findActive() throws SQLException {
        List<BorrowRecord> records = new ArrayList<>();
        String sql = "SELECT br.*, bc.bookId, b.bName AS bookName FROM tbl_book_borrow_record br "
                + "INNER JOIN tbl_book_copy bc ON br.copyId = bc.copyId "
                + "INNER JOIN tbl_book b ON bc.bookId = b.bId "
                + "WHERE br.status IN ('BORROWED', 'OVERDUE') ORDER BY br.dueDate";
        try (Connection connection = DBUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                records.add(mapRow(resultSet));
            }
        }
        return records;
    }

    /** 查询所有状态的记录，包括已归还历史；日期范围按借阅日期且包含起止当天。 */
    public List<BorrowRecord> searchAll(String readerId, String bookName, LocalDate from, LocalDate to) throws SQLException {
        if (from != null && to != null && from.isAfter(to)) throw new SQLException("开始日期不能晚于结束日期");
        StringBuilder sql = new StringBuilder("SELECT br.*, bc.bookId, b.bName AS bookName FROM tbl_book_borrow_record br "
                + "LEFT JOIN tbl_book_copy bc ON br.copyId=bc.copyId "
                + "LEFT JOIN tbl_book b ON bc.bookId=b.bId WHERE 1=1");
        List<Object> args = new ArrayList<>();
        if (readerId != null && !readerId.trim().isEmpty()) { sql.append(" AND br.readerId=?"); args.add(readerId.trim()); }
        if (bookName != null && !bookName.trim().isEmpty()) {
            sql.append(" AND LOWER(b.bName) LIKE ? ESCAPE '!'");
            args.add("%" + bookName.trim().toLowerCase(java.util.Locale.ROOT).replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%");
        }
        // 使用 [开始日 00:00, 结束日次日 00:00) 的半开区间：只匹配输入日期范围内的借阅记录，
        // 同时兼容 Access 字段中可能存在的时分秒，结束当天不会被遗漏。
        if (from != null) { sql.append(" AND br.borrowDate>=?"); args.add(Date.valueOf(from)); }
        if (to != null) { sql.append(" AND br.borrowDate<?"); args.add(Date.valueOf(to.plusDays(1))); }
        sql.append(" ORDER BY br.borrowDate DESC, br.recordId DESC");
        List<BorrowRecord> records = new ArrayList<>();
        try (Connection connection = DBUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            // UCanAccess 对日期使用 setDate 才能稳定按日期（而非字符串）比较。
            for (int i = 0; i < args.size(); i++) {
                Object argument = args.get(i);
                if (argument instanceof Date) statement.setDate(i + 1, (Date) argument);
                else statement.setObject(i + 1, argument);
            }
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) records.add(mapRow(result));
            }
        }
        return records;
    }

    private void checkReaderCanBorrow(Connection connection, String readerId, LocalDate borrowDate) throws SQLException {
        String sql = "SELECT borrowingBlockedUntil FROM tbl_book_reader WHERE readerId=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, readerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("该读者未开通图书馆权限：" + readerId);
                }
                Date blockedUntil = resultSet.getDate("borrowingBlockedUntil");
                if (blockedUntil != null && !borrowDate.isAfter(blockedUntil.toLocalDate())) {
                    throw new SQLException("当前处于禁借期：曾逾期归还图书，禁止借阅至 "
                            + blockedUntil + "，到期后系统会自动恢复借阅资格");
                }
            }
        }
    }

    private void checkBorrowLimit(Connection connection, String readerId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT COUNT(*) FROM tbl_book_borrow_record WHERE readerId=? AND status IN ('BORROWED', 'OVERDUE')")) {
            statement.setString(1, readerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next() && resultSet.getInt(1) >= MAX_ACTIVE_BORROWS) {
                    throw new SQLException("已达到同时借阅 " + MAX_ACTIVE_BORROWS + " 册图书的上限，请先归还后再借阅");
                }
            }
        }
    }

    private String findBorrowableBookId(Connection connection, String copyId) throws SQLException {
        String sql = "SELECT bookId, status, circulationType FROM tbl_book_copy WHERE copyId=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, copyId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("找不到图书副本：" + copyId);
                }
                if (!BookCopy.STATUS_AVAILABLE.equals(resultSet.getString("status"))) {
                    throw new SQLException("该图书副本当前不可借：" + copyId);
                }
                if (BookCopy.CIRCULATION_IN_LIBRARY_ONLY.equals(resultSet.getString("circulationType"))) {
                    throw new SQLException("该副本仅限馆内阅览，不能办理外借：" + copyId);
                }
                return resultSet.getString("bookId");
            }
        }
    }

    private ActiveRecord findActiveRecord(Connection connection, String recordId) throws SQLException {
        String sql = "SELECT br.copyId, br.readerId, br.borrowDate, br.dueDate, br.renewCount, bc.bookId FROM tbl_book_borrow_record br "
                + "INNER JOIN tbl_book_copy bc ON br.copyId=bc.copyId "
                + "WHERE br.recordId=? AND br.status IN ('BORROWED', 'OVERDUE')";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, recordId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                return new ActiveRecord(resultSet.getString("copyId"), resultSet.getString("readerId"),
                        resultSet.getString("bookId"), resultSet.getDate("borrowDate").toLocalDate(), resultSet.getDate("dueDate").toLocalDate(),
                        resultSet.getInt("renewCount"));
            }
        }
    }

    private ReservationRecord findFirstActiveReservation(Connection connection, String bookId) throws SQLException {
        String sql = "SELECT * FROM tbl_book_reservation_record WHERE bookId=? "
                + "AND status IN ('WAITING', 'READY') ORDER BY queueNumber";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }
                ReservationRecord record = new ReservationRecord();
                record.setReservationId(resultSet.getString("reservationId"));
                record.setReaderId(resultSet.getString("readerId"));
                return record;
            }
        }
    }

    private void updateCopyStatus(Connection connection, String copyId, String status) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "UPDATE tbl_book_copy SET status=? WHERE copyId=?")) {
            statement.setString(1, status);
            statement.setString(2, copyId);
            statement.executeUpdate();
        }
    }

    private void updateReservationStatus(Connection connection, String reservationId, String status) throws SQLException {
        String sql = ReservationRecord.STATUS_READY.equals(status)
                ? "UPDATE tbl_book_reservation_record SET status=?, readyTime=? WHERE reservationId=?"
                : "UPDATE tbl_book_reservation_record SET status=? WHERE reservationId=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            if (ReservationRecord.STATUS_READY.equals(status)) {
                statement.setTimestamp(2, java.sql.Timestamp.valueOf(LocalDateTime.now()));
                statement.setString(3, reservationId);
            } else {
                statement.setString(2, reservationId);
            }
            statement.executeUpdate();
        }
    }

    private void markFirstWaitingReservationReady(Connection connection, String bookId) throws SQLException {
        String findSql = "SELECT reservationId FROM tbl_book_reservation_record WHERE bookId=? "
                + "AND status='WAITING' ORDER BY queueNumber";
        try (PreparedStatement find = connection.prepareStatement(findSql)) {
            find.setString(1, bookId);
            try (ResultSet resultSet = find.executeQuery()) {
                if (resultSet.next()) {
                    updateReservationStatus(connection, resultSet.getString("reservationId"), ReservationRecord.STATUS_READY);
                }
            }
        }
    }

    private void applyDamagePenalty(Connection connection, String readerId, LocalDate returnDate) throws SQLException {
        LocalDate penaltyUntil = returnDate.plusDays(7);
        String querySql = "SELECT borrowingBlockedUntil FROM tbl_book_reader WHERE readerId=?";
        LocalDate currentBlockedUntil = null;
        try (PreparedStatement query = connection.prepareStatement(querySql)) {
            query.setString(1, readerId);
            try (ResultSet resultSet = query.executeQuery()) {
                if (resultSet.next() && resultSet.getDate("borrowingBlockedUntil") != null) {
                    currentBlockedUntil = resultSet.getDate("borrowingBlockedUntil").toLocalDate();
                }
            }
        }
        if (currentBlockedUntil != null && currentBlockedUntil.isAfter(penaltyUntil)) {
            penaltyUntil = currentBlockedUntil;
        }
        try (PreparedStatement update = connection.prepareStatement(
                "UPDATE tbl_book_reader SET borrowingBlockedUntil=? WHERE readerId=?")) {
            update.setDate(1, Date.valueOf(penaltyUntil));
            update.setString(2, readerId);
            update.executeUpdate();
        }
    }

    private BorrowRecord mapRow(ResultSet resultSet) throws SQLException {
        BorrowRecord record = new BorrowRecord();
        record.setRecordId(resultSet.getString("recordId"));
        record.setCopyId(resultSet.getString("copyId"));
        record.setBookId(resultSet.getString("bookId"));
        record.setBookName(resultSet.getString("bookName"));
        record.setReaderId(resultSet.getString("readerId"));
        Date borrowDate = resultSet.getDate("borrowDate");
        Date dueDate = resultSet.getDate("dueDate");
        Date returnDate = resultSet.getDate("returnDate");
        record.setBorrowDate(borrowDate == null ? null : borrowDate.toLocalDate());
        record.setDueDate(dueDate == null ? null : dueDate.toLocalDate());
        record.setReturnDate(returnDate == null ? null : returnDate.toLocalDate());
        record.setRenewCount(resultSet.getInt("renewCount"));
        record.setOverdueDays(resultSet.getInt("overdueDays"));
        record.setStatus(resultSet.getString("status"));
        return record;
    }

    /** 用 BR0001 形式的业务编号替代 UUID，便于读者和老师查看。 */
    private String nextRecordId(Connection connection) throws SQLException {
        int max = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT recordId FROM tbl_book_borrow_record");
                ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String id = resultSet.getString(1);
                if (id != null && id.matches("BR\\d+")) {
                    max = Math.max(max, Integer.parseInt(id.substring(2)));
                }
            }
        }
        return String.format("BR%04d", max + 1);
    }

    private static class ActiveRecord {
        private final String copyId;
        private final String readerId;
        private final String bookId;
        private final LocalDate borrowDate;
        private final LocalDate dueDate;
        private final int renewCount;

        ActiveRecord(String copyId, String readerId, String bookId, LocalDate borrowDate, LocalDate dueDate, int renewCount) {
            this.copyId = copyId;
            this.readerId = readerId;
            this.bookId = bookId;
            this.borrowDate = borrowDate;
            this.dueDate = dueDate;
            this.renewCount = renewCount;
        }

        boolean isHotLoan() {
            return borrowDate != null && dueDate != null
                    && ChronoUnit.DAYS.between(borrowDate, dueDate) == HOT_BOOK_LOAN_DAYS;
        }
    }
}
