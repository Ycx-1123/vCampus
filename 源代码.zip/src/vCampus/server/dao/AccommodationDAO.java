package vCampus.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import vCampus.common.enums.StayStatus;
import vCampus.common.vo.Accommodation;


/**
 * 住宿记录数据访问类。
 *
 * 负责 tbl_accommodation 表的数据访问操作。
 *
 * 功能：
 * 1. 查询学生住宿记录
 * 2. 查询全部住宿历史
 * 3. 查询当前住宿
 * 4. 判断床位占用
 * 5. 新增住宿记录
 * 6. 办理退宿
 * 7. 按住宿记录编号办理退宿
 */
public class AccommodationDAO {


    // =====================================================
    // 根据学生编号查询全部住宿记录
    // =====================================================

    /**
     * 根据学生编号查询全部住宿记录。
     *
     * 包括：
     * 当前入住(IN)
     * 历史退宿(OUT)
     *
     * @param sId 学生编号
     * @return 住宿记录列表
     */
    public List<Accommodation> findByStudentId(
            String sId) {

        List<Accommodation> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT recordId,sId,dormId,"
                    + "bedNumber,checkInTime,"
                    + "checkOutTime,status "
                    + "FROM tbl_accommodation "
                    + "WHERE sId=? "
                    + "ORDER BY recordId DESC";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    sId
            );

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toAccommodation(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


    // =====================================================
    // 查询全部住宿历史
    // =====================================================

    /**
     * 查询所有学生的全部住宿记录。
     *
     * 包括：
     * 当前入住(IN)
     * 历史退宿(OUT)
     *
     * @return 所有住宿记录
     */
    public List<Accommodation> findAll() {

        List<Accommodation> list =
                new ArrayList<>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT recordId,sId,dormId,"
                    + "bedNumber,checkInTime,"
                    + "checkOutTime,status "
                    + "FROM tbl_accommodation "
                    + "ORDER BY recordId DESC";

            pstmt =
                    conn.prepareStatement(sql);

            rs =
                    pstmt.executeQuery();

            while (rs.next()) {

                list.add(
                        toAccommodation(rs)
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return list;
    }


    // =====================================================
    // 根据学生编号查询当前住宿
    // =====================================================

    /**
     * 根据学生编号查询当前住宿记录。
     *
     * 当前住宿状态必须为 IN。
     *
     * @param sId 学生编号
     * @return 当前住宿记录，不存在返回 null
     */
    public Accommodation findCurrentByStudentId(
            String sId) {

        Accommodation accommodation =
                null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT recordId,sId,dormId,"
                    + "bedNumber,checkInTime,"
                    + "checkOutTime,status "
                    + "FROM tbl_accommodation "
                    + "WHERE sId=? "
                    + "AND status=? "
                    + "ORDER BY recordId DESC";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    sId
            );

            pstmt.setString(
                    2,
                    StayStatus.IN.name()
            );

            rs =
                    pstmt.executeQuery();

            if (rs.next()) {

                accommodation =
                        toAccommodation(rs);
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return accommodation;
    }

    /**
     * 根据学生编号查询最近一次住宿记录。
     *
     * 包括：
     * 当前入住(IN)
     * 最近退宿(OUT)
     *
     * @param sId 学生编号
     * @return 最近一次住宿记录，不存在返回null
     */
    public Accommodation findLatestByStudentId(
            String sId) {

        Accommodation accommodation = null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT recordId,sId,dormId,"
                    + "bedNumber,checkInTime,"
                    + "checkOutTime,status "
                    + "FROM tbl_accommodation "
                    + "WHERE sId=? "
                    + "ORDER BY recordId DESC";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    sId
            );

            rs =
                    pstmt.executeQuery();

            if (rs.next()) {

                accommodation =
                        toAccommodation(rs);
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return accommodation;
    }

    // =====================================================
    // 判断床位是否已经被占用
    // =====================================================

    /**
     * 判断指定宿舍的指定床位是否已经被占用。
     *
     * 只有当前状态为 IN 的记录才算占用。
     *
     * @param dormId 宿舍号
     * @param bedNumber 床位号
     * @return true 表示已占用
     */
    public boolean isBedOccupied(
            String dormId,
            String bedNumber) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "SELECT COUNT(*) "
                    + "FROM tbl_accommodation "
                    + "WHERE dormId=? "
                    + "AND bedNumber=? "
                    + "AND status=?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    dormId
            );

            pstmt.setString(
                    2,
                    bedNumber
            );

            pstmt.setString(
                    3,
                    StayStatus.IN.name()
            );

            rs =
                    pstmt.executeQuery();

            if (rs.next()) {

                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }

        return false;
    }
    
 // =====================================================
 // 查询指定宿舍可用床位
 // =====================================================

 /**
  * 查询指定宿舍当前可用床位。
  *
  * 床位编号按照 1 ~ capacity 生成，
  * 已经存在 IN 状态住宿记录的床位不返回。
  *
  * @param dormId 宿舍编号
  * @param capacity 宿舍容量
  * @return 可用床位编号列表
  */
 public List<String> queryAvailableBeds(
         String dormId,
         int capacity) {

     List<String> beds =
             new ArrayList<>();

     if (dormId == null
             || dormId.trim().isEmpty()
             || capacity <= 0) {

         return beds;
     }

     List<String> occupiedBeds =
             new ArrayList<>();

     Connection conn = null;
     PreparedStatement pstmt = null;
     ResultSet rs = null;

     try {

         conn = DBUtil.getConnection();

         String sql =
                 "SELECT bedNumber "
                 + "FROM tbl_accommodation "
                 + "WHERE dormId=? "
                 + "AND status=?";

         pstmt =
                 conn.prepareStatement(sql);

         pstmt.setString(
                 1,
                 dormId
         );

         pstmt.setString(
                 2,
                 StayStatus.IN.name()
         );

         rs =
                 pstmt.executeQuery();

         while (rs.next()) {

             occupiedBeds.add(
                     rs.getString(
                             "bedNumber"
                     )
             );
         }

     } catch (Exception e) {

         e.printStackTrace();

         return beds;

     } finally {

         DBUtil.close(
                 conn,
                 pstmt,
                 rs
         );
     }


     for (int i = 1;
          i <= capacity;
          i++) {

         String bedNumber =
                 String.valueOf(i);

         if (!occupiedBeds.contains(
                 bedNumber)) {

             beds.add(
                     bedNumber
             );
         }
     }

     return beds;
 }


    // =====================================================
    // 新增住宿记录
    // =====================================================

    /**
     * 新增住宿记录。
     *
     * @param accommodation 住宿记录
     * @return 是否成功
     */
    public boolean insert(
            Accommodation accommodation) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "INSERT INTO tbl_accommodation "
                    + "(sId,dormId,bedNumber,"
                    + "checkInTime,checkOutTime,status)"
                    + " VALUES(?,?,?,?,?,?)";

            pstmt =
                    conn.prepareStatement(
                            sql,
                            PreparedStatement.RETURN_GENERATED_KEYS
                    );

            pstmt.setString(
                    1,
                    accommodation.getsId()
            );

            pstmt.setString(
                    2,
                    accommodation.getDormId()
            );

            pstmt.setString(
                    3,
                    accommodation.getBedNumber()
            );


            if (accommodation.getCheckInTime()
                    != null) {

                pstmt.setDate(
                        4,
                        new java.sql.Date(
                                accommodation
                                        .getCheckInTime()
                                        .getTime()
                        )
                );

            } else {

                pstmt.setDate(
                        4,
                        null
                );
            }


            if (accommodation.getCheckOutTime()
                    != null) {

                pstmt.setDate(
                        5,
                        new java.sql.Date(
                                accommodation
                                        .getCheckOutTime()
                                        .getTime()
                        )
                );

            } else {

                pstmt.setDate(
                        5,
                        null
                );
            }


            pstmt.setString(
                    6,
                    accommodation
                            .getStatus()
                            .name()
            );


            int result =
                    pstmt.executeUpdate();

            if (result <= 0) {

                return false;
            }


            rs =
                    pstmt.getGeneratedKeys();

            if (rs.next()) {

                accommodation.setRecordId(
                        rs.getInt(1)
                );
            }


            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    rs
            );
        }
    }


    // =====================================================
    // 办理退宿
    // =====================================================

    /**
     * 根据学生编号办理退宿。
     *
     * 不删除历史记录，
     * 只修改当前 IN 记录的状态。
     *
     * @param sId 学生编号
     * @return 是否成功
     */
    public boolean checkOut(
            String sId) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "UPDATE tbl_accommodation "
                    + "SET status=?,"
                    + "checkOutTime=? "
                    + "WHERE sId=? "
                    + "AND status=?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    StayStatus.OUT.name()
            );

            pstmt.setDate(
                    2,
                    new java.sql.Date(
                            System.currentTimeMillis()
                    )
            );

            pstmt.setString(
                    3,
                    sId
            );

            pstmt.setString(
                    4,
                    StayStatus.IN.name()
            );

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    null
            );
        }
    }


    // =====================================================
    // 根据住宿记录编号办理退宿
    // =====================================================

    /**
     * 根据住宿记录编号办理退宿。
     *
     * 主要用于：
     * 1. 调宿过程中的回滚
     * 2. 指定住宿记录的状态修改
     *
     * @param recordId 住宿记录编号
     * @return 是否成功
     */
    public boolean checkOut(
            int recordId) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = DBUtil.getConnection();

            String sql =
                    "UPDATE tbl_accommodation "
                    + "SET status=?,"
                    + "checkOutTime=? "
                    + "WHERE recordId=? "
                    + "AND status=?";

            pstmt =
                    conn.prepareStatement(sql);

            pstmt.setString(
                    1,
                    StayStatus.OUT.name()
            );

            pstmt.setDate(
                    2,
                    new java.sql.Date(
                            System.currentTimeMillis()
                    )
            );

            pstmt.setInt(
                    3,
                    recordId
            );

            pstmt.setString(
                    4,
                    StayStatus.IN.name()
            );

            return pstmt.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;

        } finally {

            DBUtil.close(
                    conn,
                    pstmt,
                    null
            );
        }
    }


    // =====================================================
    // ResultSet 转 Accommodation
    // =====================================================

    /**
     * ResultSet转换为Accommodation对象。
     *
     * @param rs 查询结果
     * @return Accommodation对象
     */
    private Accommodation toAccommodation(
            ResultSet rs)
            throws Exception {

        Accommodation accommodation =
                new Accommodation();


        accommodation.setRecordId(
                rs.getInt("recordId")
        );


        accommodation.setsId(
                rs.getString("sId")
        );


        accommodation.setDormId(
                rs.getString("dormId")
        );


        accommodation.setBedNumber(
                rs.getString("bedNumber")
        );


        accommodation.setCheckInTime(
                rs.getDate("checkInTime")
        );


        accommodation.setCheckOutTime(
                rs.getDate("checkOutTime")
        );


        accommodation.setStatus(
                StayStatus.valueOf(
                        rs.getString("status")
                )
        );


        return accommodation;
    }

}