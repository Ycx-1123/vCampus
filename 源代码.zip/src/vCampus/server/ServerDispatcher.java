package vCampus.server;

import java.util.logging.*;

import vCampus.common.Message;
import vCampus.common.consts.MsgConst;
import vCampus.server.handler.DepartmentHandler;
import vCampus.server.handler.MajorHandler;
import vCampus.server.handler.ClazzHandler;
import vCampus.server.handler.StudentHandler;

// 引入相关的类 (Import necessary classes)
import vCampus.server.dao.UserDao;
import vCampus.common.vo.Student;

public class ServerDispatcher {

	// ===== 新增：初始化日志记录器 (Initialize Logger) =====
	private static final Logger logger = Logger.getLogger(ServerDispatcher.class.getName());
	static {
		try {
			// true 表示追加写入模式，日志文件会自动创建在项目根目录下
			FileHandler fileHandler = new FileHandler("server_operations.log", true);
			fileHandler.setFormatter(new SimpleFormatter());
			logger.addHandler(fileHandler);
		} catch (Exception e) {
			System.err.println("日志文件初始化失败 (Failed to initialize log file): " + e.getMessage());
		}
	}
	// ===================================================

	private DepartmentHandler deptHandler = new DepartmentHandler();
	private MajorHandler majorHandler = new MajorHandler();
	private ClazzHandler clazzHandler = new ClazzHandler();
	private StudentHandler studentHandler = new StudentHandler();

	public Message dispatch(Message msg) {
		// 防空指针校验 (Check null message)
		if (msg == null) {
			Message resp = new Message();
			resp.setSuccess(false);
			resp.setResponseMsg("Dispatcher：请求消息为空 (Message is null)");
			return resp;
		}

		String type = msg.getType();

		// ===== 新增：记录全局联网操作日志 (Log all incoming client requests) =====
		logger.info("收到请求 (Received Request) -> 操作类型 (Type): " + type);
		// ===================================================================

		// 防空指针校验 (Null pointer check to ensure type exists)
		if (type == null) {
			Message resp = new Message();
			resp.setSuccess(false);
			resp.setResponseMsg("Dispatcher：请求类型为空 (Type is null)");
			return resp;
		}

		// -------------------- 密码重置 Reset Password --------------------
		// 拦截客户端发来的重置密码请求 (Intercept the reset password request from client)
		if (type.equals("RESET_PASSWORD")) {
			Student inputStu = (Student) msg.getData();
			UserDao userDao = new UserDao();
			
			// 调用数据库层进行验证和更新 (Call DAO to verify and update)
			boolean isSuccess = userDao.autoVerifyAndResetPassword(
					inputStu.getSCard(), 
					inputStu.getSphone(), 
					inputStu.getSpassword()
			);
			
			Message resp = new Message();
			resp.setType(type);
			resp.setSuccess(isSuccess);
			resp.setResponseMsg(isSuccess ? "Password reset successful" : "Mismatch or not found");
			return resp;
		}

		// -------------------- 院系 Department --------------------
		else if (type.equals(MsgConst.QUERY_ALL_DEPT)
				|| type.equals(MsgConst.QUERY_DEPT_BY_DEPTID)
				|| type.equals(MsgConst.ADD_DEPT)
				|| type.equals(MsgConst.UPDATE_DEPT)
				|| type.equals(MsgConst.DELETE_DEPT)) {
			return deptHandler.handle(msg);
		}

		// -------------------- 专业 Major --------------------
		else if (type.equals(MsgConst.QUERY_MAJOR_BY_MAJORID)
				|| type.equals(MsgConst.QUERY_MAJOR_BY_DEPTID)
				|| type.equals(MsgConst.QUERY_ALL_MAJOR)
				|| type.equals(MsgConst.ADD_MAJOR)
				|| type.equals(MsgConst.UPDATE_MAJOR)
				|| type.equals(MsgConst.DELETE_MAJOR)) {
			return majorHandler.handle(msg);
		}

		// -------------------- 班级 Clazz --------------------
		else if (type.equals(MsgConst.QUERY_CLAZZ_BY_CLAZZID)
				|| type.equals(MsgConst.QUERY_CLAZZ_BY_MAJORID)
				|| type.equals(MsgConst.QUERY_ALL_CLAZZ)
				|| type.equals(MsgConst.ADD_CLAZZ)
				|| type.equals(MsgConst.UPDATE_CLAZZ)
				|| type.equals(MsgConst.DELETE_CLAZZ)) {
			return clazzHandler.handle(msg);
		}

		// -------------------- 学生 Student --------------------
		else if (type.equals(MsgConst.QUERY_STUDENT_BY_CID)
				|| type.equals(MsgConst.QUERY_STUDENT_BY_SCARD)
				|| type.equals(MsgConst.QUERY_ALL_STUDENT)
				|| type.equals(MsgConst.ADD_STUDENT)
				|| type.equals(MsgConst.UPDATE_STUDENT)
				|| type.equals(MsgConst.DELETE_STUDENT)
				|| type.equals(MsgConst.LOCK_STUDENT)
				|| type.equals(MsgConst.UNLOCK_STUDENT)) {
			return studentHandler.handle(msg);
		}
		
		// 找不到处理器 (Handler not found fallback)
		else {
			Message resp = new Message();
			resp.setSuccess(false);
			resp.setResponseMsg("Dispatcher：未知请求类型 -> " + type);
			return resp;
		}
	}
}