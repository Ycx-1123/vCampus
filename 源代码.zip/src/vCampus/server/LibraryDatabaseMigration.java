package vCampus.server;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import vCampus.server.dao.DBUtil;

/**
 * 图书馆数据库的非破坏性升级工具。
 * <p>关闭 Server 与 Access 后，以 Java Application 方式运行一次即可。</p>
 */
public final class LibraryDatabaseMigration {
    private LibraryDatabaseMigration() { }

    public static void main(String[] args) {
        try {
            upgrade();
            System.out.println("图书馆数据库升级完成：已准备读者荐书表与图书分类号字段。");
        } catch (SQLException e) {
            System.err.println("图书馆数据库升级失败：" + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void upgrade() throws SQLException {
        try (Connection connection = DBUtil.getConnection(); Statement statement = connection.createStatement()) {
            if (!hasColumn(connection, "tbl_book_reader", "cardId")) {
                statement.executeUpdate("ALTER TABLE tbl_book_reader ADD COLUMN cardId TEXT(50)");
            }
            statement.executeUpdate("UPDATE tbl_book_reader SET cardId=readerId WHERE cardId IS NULL OR cardId='' ");
            if (!hasTable(connection, "tbl_book_recommendation")) {
                statement.executeUpdate("CREATE TABLE tbl_book_recommendation ("
                        + "id COUNTER PRIMARY KEY, recommendationId TEXT(20), readerId TEXT(50) NOT NULL, "
                        + "recommenderType TEXT(20), bookName TEXT(255) NOT NULL, author TEXT(100), publisher TEXT(150), categoryId TEXT(20), "
                        + "recommendReason TEXT(255), recommendTime DATETIME, status TEXT(20))");
            } else {
                if (!hasColumn(connection, "tbl_book_recommendation", "readerId")) {
                    statement.executeUpdate("ALTER TABLE tbl_book_recommendation ADD COLUMN readerId TEXT(50)");
                    if (hasColumn(connection, "tbl_book_recommendation", "teacherCardId")) {
                        statement.executeUpdate("UPDATE tbl_book_recommendation SET readerId=teacherCardId WHERE readerId IS NULL OR readerId='' ");
                    }
                }
                if (!hasColumn(connection, "tbl_book_recommendation", "categoryId")) {
                    statement.executeUpdate("ALTER TABLE tbl_book_recommendation ADD COLUMN categoryId TEXT(20)");
                }
                if (!hasColumn(connection, "tbl_book_recommendation", "recommenderType")) {
                    statement.executeUpdate("ALTER TABLE tbl_book_recommendation ADD COLUMN recommenderType TEXT(20)");
                }
            }
        }
    }

    private static boolean hasTable(Connection connection, String table) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        try (ResultSet resultSet = metaData.getTables(null, null, table, new String[] { "TABLE" })) {
            return resultSet.next();
        }
    }

    private static boolean hasColumn(Connection connection, String table, String column) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        try (ResultSet resultSet = metaData.getColumns(null, null, table, column)) {
            return resultSet.next();
        }
    }
}
