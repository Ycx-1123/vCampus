
package vCampus.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vCampus.common.shop.Order;
import vCampus.common.shop.OrderItem;
import vCampus.common.shop.OrderStatus;
import vCampus.common.shop.Product;
import vCampus.server.dao.OrderDAO;
import vCampus.server.dao.ProductDAO;
import vCampus.server.dao.UserAccountDao;
import vCampus.server.dao.BankDao;

/**
 * 商店模块服务器端业务逻辑实现 负责处理下单、库存管理、订单查询等核心业务
 */
public class ShopServerSrvImpl implements IShopServerSrv {

	private ProductDAO productDAO = new ProductDAO();
	private OrderDAO orderDAO = new OrderDAO();
	private UserAccountDao accountDao = new UserAccountDao();
	private BankDao bankDao = new BankDao();

	// 数据库连接URL（与DAO保持一致）
	private static final String DB_URL = "jdbc:ucanaccess://./vCampus.accdb;ignoreCase=true;newDatabaseVersion=V2019";

	@Override
	public List<Product> getAllProducts() {
		try {
			return productDAO.queryAll();
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public boolean addProduct(Product product) {
		try {
			return productDAO.insert(product);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateStock(int productId, int additionalStock) {
		try {
			return productDAO.addStock(productId, additionalStock);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteProduct(int productId) {
		try {
			return productDAO.deleteById(productId);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Order submitOrder(String userId, List<OrderItem> items) {
		return submitOrderInternal(userId, items, null);
	}

	@Override
	public List<Order> getOrdersByUser(String userId) {
		if (userId == null || userId.isEmpty()) {
			return new ArrayList<>();
		}
		try {
			return orderDAO.queryByUser(userId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public double getBalance(String userId, String payMethod) {
		if (userId == null || userId.trim().isEmpty()) {
			return -1;
		}
		try {
			return accountDao.getBalance(userId, payMethod);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	/**
	 * 带支付方式的下单（含余额检查和扣款）
	 */
	public Order submitOrderWithPayment(String userId, List<OrderItem> items, String payMethod, double totalAmount,
			String bankPIN) {

		return submitOrderInternal(userId, items, payMethod, totalAmount, bankPIN);
	}

	private Order submitOrderInternal(String userId, List<OrderItem> items, String payMethod) {

		return submitOrderInternal(userId, items, payMethod, -1, null);
	}

	private Order submitOrderInternal(String userId, List<OrderItem> items, String payMethod, double paidAmount,
			String bankPIN) {
		if (userId == null || userId.trim().isEmpty() || items == null || items.isEmpty()) {
			System.err.println("下单失败：用户ID或购物车为空");
			return null;
		}

		Connection conn = null;
		try {
			conn = DriverManager.getConnection(DB_URL);
			conn.setAutoCommit(false);

			double totalAmount = 0;
			for (OrderItem item : items) {
				if (item == null || item.getQuantity() <= 0) {
					conn.rollback();
					System.err.println("下单失败：订单明细为空或数量无效");
					return null;
				}

				Product product = productDAO.findById(conn, item.getProductId());
				if (product == null) {
					conn.rollback();
					System.err.println("下单失败：商品不存在，productId=" + item.getProductId());
					return null;
				}
				if (product.getStock() < item.getQuantity()) {
					conn.rollback();
					System.err.println("下单失败：库存不足，商品=" + product.getName());
					return null;
				}

				item.setUnitPrice(product.getPrice());
				totalAmount += item.calcSubtotal();
			}

			double finalAmount = paidAmount >= 0 ? Math.min(paidAmount, totalAmount) : totalAmount;

			// 支付处理
			if (payMethod != null && !payMethod.trim().isEmpty() && finalAmount > 0) {

				if ("BANK".equalsIgnoreCase(payMethod)) {
				} else {
					double balance = accountDao.getBalance(conn, userId, payMethod);

					if (balance < finalAmount) {
						conn.rollback();
						System.err.println("余额不足：" + balance + " < " + finalAmount);
						return null;
					}

					if (!accountDao.deductBalance(conn, userId, payMethod, finalAmount)) {

						conn.rollback();
						System.err.println("扣款失败");
						return null;
					}
				}
			}

			for (OrderItem item : items) {
				boolean success = productDAO.updateStock(conn, item.getProductId(), item.getQuantity());
				if (!success) {
					conn.rollback();
					System.err.println("下单失败：扣减库存失败，productId=" + item.getProductId());
					return null;
				}
			}

			Order order = new Order();
			order.setUserId(userId);
			order.setTotalAmount(finalAmount);
			order.setStatus(OrderStatus.PAID);
			order.setCreateTime(new Date());

			long orderId = orderDAO.insertOrder(conn, order);
			if (orderId <= 0) {
				conn.rollback();
				System.err.println("下单失败：插入订单主表失败");
				return null;
			}
			order.setId(orderId);

			if ("BANK".equalsIgnoreCase(payMethod) && finalAmount > 0) {

				if (!bankDao.shopPayment(conn, userId, finalAmount, String.valueOf(orderId))) {

					conn.rollback();
					System.err.println("银行卡支付失败");
					return null;
				}
			}

			for (OrderItem item : items) {
				item.setOrderId(orderId);
				if (!orderDAO.insertOrderItem(conn, item)) {
					conn.rollback();
					System.err.println("下单失败：插入订单明细失败，productId=" + item.getProductId());
					return null;
				}
			}

			conn.commit();
			System.out.println("下单成功：订单号=" + orderId + "，用户=" + userId + "，应付金额=" + finalAmount);
			return order;
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				if (conn != null)
					conn.rollback();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return null;
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
