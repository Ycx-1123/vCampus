package vCampus.server;

import vCampus.common.vo.Student;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

public class StudentExcelImporter {

    /**
     * 解析学生Excel（仅支持 .xlsx 格式）
     * 表头固定顺序：一卡通号 | 姓名 | 性别 | 学号 | 班级编号 | 入学年份 | 电话 | 邮箱 | 地址 | 已修学分 | 所需学分
     * 第1行为表头，从第2行开始读取数据
     */
    public static List<Student> parse(byte[] fileBytes) throws Exception {
        List<Student> studentList = new ArrayList<>();

        try (Workbook workbook = new XSSFWorkbook(new ByteArrayInputStream(fileBytes))) {
            Sheet sheet = workbook.getSheetAt(0);
            // 跳过表头，从第2行（索引1）开始读取
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue;

                String scard = getCellStringValue(row.getCell(0));
                String name = getCellStringValue(row.getCell(1));
                // 空行自动跳过
                if (scard.isEmpty() && name.isEmpty()) continue;

                Student student = new Student();
                student.setSCard(scard);
                student.setSname(name);
                student.setSgender(getCellStringValue(row.getCell(2)));
                student.setSId(getCellStringValue(row.getCell(3)));
                student.setClazzid(getCellStringValue(row.getCell(4)));
                student.setEnrollYear(getCellStringValue(row.getCell(5)));
                student.setSphone(getCellStringValue(row.getCell(6)));
                student.setSemail(getCellStringValue(row.getCell(7)));
                student.setSaddress(getCellStringValue(row.getCell(8)));

                // 学分空值默认0
                double finished = parseDoubleSafe(getCellStringValue(row.getCell(9)));
                double required = parseDoubleSafe(getCellStringValue(row.getCell(10)));
                student.setFinishedCredit(finished);
                student.setRequiredCredit(required);

                studentList.add(student);
            }
        }
        return studentList;
    }

    /**
     * 统一单元格值转字符串，兼容数字、公式、布尔等类型
     */
    private static String getCellStringValue(Cell cell) {
        if (cell == null) return "";

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                double num = cell.getNumericCellValue();
                // 整数去除小数点，避免学号/一卡通号变成 1001.0
                if (num == Math.floor(num) && !Double.isInfinite(num)) {
                    return String.valueOf((long) num);
                }
                return String.valueOf(num);
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                try {
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return String.valueOf(cell.getNumericCellValue());
                }
            default:
                return "";
        }
    }

    /**
     * 安全解析double，异常或空返回0
     */
    private static double parseDoubleSafe(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try {
            return Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}