
package vCampus.server;

import java.util.List;

import vCampus.common.shop.Order;
import vCampus.common.shop.OrderItem;
import vCampus.common.shop.Product;

/**
 * 商店模块服务器端业务接口
 * 定义了服务器端需要提供的所有业务方法
 */
public interface IShopServerSrv {

    /**
     * 获取所有商品列表
     */
    List<Product> getAllProducts();

    /**
     * 提交订单（包含库存扣减、订单生成）
     * @param userId 用户ID
     * @param items 购物车明细列表
     * @return 生成的订单对象，失败返回null
     */
    Order submitOrder(String userId, List<OrderItem> items);

    /**
     * 获取用户历史订单
     * @param userId 用户ID
     * @return 订单列表
     */
    List<Order> getOrdersByUser(String userId);

    /**
     * 查询用户校园账户余额
     * @param userId 用户一卡通号
     * @param payMethod 支付方式
     * @return 余额，查询失败返回 -1
     */
    double getBalance(String userId, String payMethod);
    
 // 管理员专用
    boolean addProduct(Product product);
    boolean updateStock(int productId, int additionalStock);
    boolean deleteProduct(int productId);
}
